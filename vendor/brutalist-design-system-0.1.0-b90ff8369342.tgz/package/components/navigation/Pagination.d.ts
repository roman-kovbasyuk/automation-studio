export type PaginationProps = {
    page: number;
    pageCount: number;
    onPageChange: (page: number) => void;
    className?: string;
};
/** Small-page navigator for bounded result sets. */
export declare function Pagination({ page, pageCount, onPageChange, className }: PaginationProps): import("react").JSX.Element;
