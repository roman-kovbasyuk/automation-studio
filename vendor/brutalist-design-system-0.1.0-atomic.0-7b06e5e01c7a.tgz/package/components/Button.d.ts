import type { ButtonHTMLAttributes, ReactNode, Ref } from 'react';
import { type IconName } from '../atoms';

type Content = {
    iconOnly: true;
    icon: IconName;
    'aria-label': string;
    children?: never;
} | {
    iconOnly?: false;
    icon?: IconName;
    children: ReactNode;
};
export type ButtonProps = Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'children'> & Content & {
    ref?: Ref<HTMLButtonElement>;
    variant?: 'primary' | 'secondary' | 'danger' | 'quiet';
    size?: 'default' | 'compact';
    iconPosition?: 'start' | 'end';
    busy?: boolean;
};
export declare function Button({ children, icon, iconOnly, iconPosition, variant, size, busy, disabled, type, className, ...props }: ButtonProps): import("react").JSX.Element;
export {};
