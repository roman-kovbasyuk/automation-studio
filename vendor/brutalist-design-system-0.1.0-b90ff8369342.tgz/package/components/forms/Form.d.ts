import { type ComponentProps, type ReactNode } from 'react';
export type FormProps = ComponentProps<'form'>;
/** Semantic form shell; the consumer owns validation, state, and submission. */
export declare function Form({ className, ...props }: FormProps): import("react").JSX.Element;
export type FormSectionProps = ComponentProps<'fieldset'> & {
    title: string;
    description?: ReactNode;
    elevated?: boolean;
    unstyled?: boolean;
};
/** An accessible group of related fields with shared panel styling. */
export declare function FormSection({ title, description, children, elevated, unstyled, className, ...props }: FormSectionProps): import("react").JSX.Element;
export type FormActionsProps = ComponentProps<'footer'>;
/** Wrapping action layout shared by forms at every viewport size. */
export declare function FormActions({ children, className, ...props }: FormActionsProps): import("react").JSX.Element;
