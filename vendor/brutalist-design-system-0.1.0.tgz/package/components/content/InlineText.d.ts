export type InlineTextProps = {
    label: string;
    value?: string;
    onSave: (value: string) => void | Promise<void>;
    readOnly?: boolean;
    multiline?: boolean;
    required?: boolean;
    maxLength?: number;
    className?: string;
};
/** A small, keyboard-friendly text editor for a single value. */
export declare function InlineText({ label, value, onSave, readOnly, multiline, required, maxLength, className }: InlineTextProps): import("react").JSX.Element;
