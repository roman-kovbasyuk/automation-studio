import type { ReactNode, TextareaHTMLAttributes } from 'react';
export type TextAreaProps = Omit<TextareaHTMLAttributes<HTMLTextAreaElement>, 'id' | 'aria-describedby' | 'aria-invalid'> & {
    id?: string;
    label: ReactNode;
    instructions?: ReactNode;
    error?: ReactNode;
};
/** A labelled native multiline text control with canonical helper and error wiring. */
export declare function TextArea({ id: providedId, label, instructions, error, className, ...props }: TextAreaProps): import("react").JSX.Element;
