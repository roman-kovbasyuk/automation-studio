import { type ReactNode, type SelectHTMLAttributes } from 'react';
import { type IconName } from '../atoms';



export type SelectOption = {
    value: string;
    label: string;
    disabled?: boolean;
    icon?: IconName;
};
export type SelectProps = Omit<SelectHTMLAttributes<HTMLSelectElement>, 'children' | 'multiple' | 'size' | 'value' | 'defaultValue'> & {
    label: ReactNode;
    options: readonly SelectOption[];
    placeholder?: string;
    value?: string;
    defaultValue?: string;
    instructions?: ReactNode;
    error?: ReactNode;
    onValueChange?: (value: string) => void;
    customOption?: {
        value: string;
        label: string;
        text: string;
        onTextChange: (text: string) => void;
    };
};
export declare function Select({ label, options, placeholder, value, defaultValue, instructions, error, id, className, disabled, name, required, onChange, onValueChange, customOption, 'aria-describedby': external, 'aria-invalid': invalid }: SelectProps): import("react").JSX.Element;
