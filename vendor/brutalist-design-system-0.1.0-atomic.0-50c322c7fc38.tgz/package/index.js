import { Fragment as e, jsx as t, jsxs as n } from "react/jsx-runtime";
import { ArrowDown as r, ArrowLeft as i, ArrowRight as a, ArrowUp as o, CalendarDays as s, Check as c, ChevronDown as l, ChevronRight as u, CircleAlert as d, Clock as f, Copy as p, Download as m, Ellipsis as h, ExternalLink as g, Eye as _, File as v, Folder as y, Image as b, Info as x, LoaderCircle as S, Menu as C, Minus as w, Pencil as T, Plus as E, Search as D, Settings as O, Star as k, Trash2 as ee, Upload as A, X as j, icons as te } from "lucide-react";
import { useEffect as M, useId as N, useLayoutEffect as ne, useRef as P, useState as F } from "react";
import { Dialog as I, DropdownMenu as L, Popover as R, Select as z, Tabs as B, Tooltip as V } from "radix-ui";
//#region src/atomic/atoms/tokens.ts
var re = {
	color: {
		earthy: {
			0: "#f4f4f0",
			50: "#efeee8",
			100: "#e5e3da",
			200: "#d4d0c3",
			300: "#bcb6a5",
			400: "#9f9784",
			500: "#827966",
			600: "#685f50",
			700: "#4f493d",
			800: "#38342d",
			900: "#24221e",
			950: "#151411"
		},
		gray: {
			0: "#ffffff",
			50: "#f7f7f7",
			100: "#eeeeee",
			200: "#dddddd",
			300: "#c8c8c8",
			400: "#adadad",
			500: "#919191",
			600: "#737373",
			700: "#555555",
			800: "#3b3b3b",
			900: "#252525",
			950: "#171717"
		},
		slate: {
			0: "#f8fafc",
			50: "#f1f5f9",
			100: "#e2e8f0",
			200: "#cbd5e1",
			300: "#94a3b8",
			400: "#64748b",
			500: "#475569",
			600: "#334155",
			700: "#1e293b",
			800: "#0f172a",
			900: "#020617",
			950: "#01030a"
		},
		red: {
			0: "#fff5f5",
			50: "#ffe3e3",
			100: "#ffc9c9",
			200: "#ffa8a8",
			300: "#ff8787",
			400: "#ff6b6b",
			500: "#fa5252",
			600: "#f03e3e",
			700: "#e03131",
			800: "#c92a2a",
			900: "#b91c1c",
			950: "#7f1d1d"
		},
		orange: {
			0: "#fff4e6",
			50: "#ffe8cc",
			100: "#ffd8a8",
			200: "#ffc078",
			300: "#ffa94d",
			400: "#ff922b",
			500: "#fd7e14",
			600: "#f76707",
			700: "#e8590c",
			800: "#d9480f",
			900: "#c2410c",
			950: "#7c2d12"
		},
		amber: {
			0: "#fff8e1",
			50: "#ffecb3",
			100: "#ffe082",
			200: "#ffd54f",
			300: "#ffca28",
			400: "#ffb300",
			500: "#f59f00",
			600: "#f08c00",
			700: "#e67700",
			800: "#d97706",
			900: "#b45309",
			950: "#78350f"
		},
		yellow: {
			0: "#fffde7",
			50: "#fff9c4",
			100: "#fff59d",
			200: "#fff176",
			300: "#ffee58",
			400: "#ffeb3b",
			500: "#fdd835",
			600: "#fbc02d",
			700: "#f9a825",
			800: "#f59e0b",
			900: "#ca8a04",
			950: "#713f12"
		},
		green: {
			0: "#ebfbee",
			50: "#d3f9d8",
			100: "#b2f2bb",
			200: "#8ce99a",
			300: "#69db7c",
			400: "#51cf66",
			500: "#40c057",
			600: "#37b24d",
			700: "#2f9e44",
			800: "#2b8a3e",
			900: "#237b3b",
			950: "#14532d"
		},
		teal: {
			0: "#e6fcf5",
			50: "#c3fae8",
			100: "#96f2d7",
			200: "#63e6be",
			300: "#38d9a9",
			400: "#20c997",
			500: "#12b886",
			600: "#0ca678",
			700: "#099268",
			800: "#087f5b",
			900: "#067a68",
			950: "#064e3b"
		},
		cyan: {
			0: "#e3fafc",
			50: "#c5f6fa",
			100: "#99e9f2",
			200: "#66d9e8",
			300: "#3bc9db",
			400: "#22b8cf",
			500: "#15aabf",
			600: "#1098ad",
			700: "#0c8599",
			800: "#0b7285",
			900: "#0e7490",
			950: "#164e63"
		},
		blue: {
			0: "#f5faff",
			50: "#e8f3ff",
			100: "#cfe6ff",
			200: "#a6d2ff",
			300: "#72b8ff",
			400: "#3d98f5",
			500: "#1677d2",
			600: "#0d5eac",
			700: "#0b4a86",
			800: "#0b3b69",
			900: "#0b3155",
			950: "#061d35"
		},
		indigo: {
			0: "#edf2ff",
			50: "#dbe4ff",
			100: "#bac8ff",
			200: "#91a7ff",
			300: "#748ffc",
			400: "#5c7cfa",
			500: "#4c6ef5",
			600: "#4263eb",
			700: "#3b5bdb",
			800: "#364fc7",
			900: "#3046a8",
			950: "#1e2a78"
		},
		violet: {
			0: "#f3f0ff",
			50: "#e5dbff",
			100: "#d0bfff",
			200: "#b197fc",
			300: "#9775fa",
			400: "#845ef7",
			500: "#7950f2",
			600: "#7048e8",
			700: "#6741d9",
			800: "#5f3dc4",
			900: "#5235a6",
			950: "#312e81"
		},
		purple: {
			0: "#f8f0fc",
			50: "#f3d9fa",
			100: "#eebefa",
			200: "#e599f7",
			300: "#da77f2",
			400: "#cc5de8",
			500: "#be4bdb",
			600: "#ae3ec9",
			700: "#9c36b5",
			800: "#862e9c",
			900: "#70248f",
			950: "#581c87"
		},
		pink: {
			0: "#fff0f6",
			50: "#ffdeeb",
			100: "#fcc2d7",
			200: "#faa2c1",
			300: "#f783ac",
			400: "#f06595",
			500: "#e64980",
			600: "#d6336c",
			700: "#c2255c",
			800: "#a61e4d",
			900: "#9d174d",
			950: "#701a40"
		},
		rose: {
			0: "#fff1f2",
			50: "#ffe4e6",
			100: "#fecdd3",
			200: "#fda4af",
			300: "#fb7185",
			400: "#f43f5e",
			500: "#e11d48",
			600: "#be123c",
			700: "#9f1239",
			800: "#881337",
			900: "#701a35",
			950: "#4c0519"
		},
		static: {
			black: "#000000",
			white: "#ffffff"
		},
		canvas: "#f4f4f0",
		surface: "#ffffff",
		ink: "#000000",
		secondary: "#595959",
		accent: "#79d9ff",
		success: "#23a094",
		danger: "#dc341e",
		editHighlight: "rgb(0 0 0 / 3%)",
		backdrop: "rgb(0 0 0 / 35%)"
	},
	space: {
		0: "0px",
		1: "4px",
		2: "8px",
		3: "12px",
		4: "16px",
		6: "24px",
		8: "32px",
		12: "48px",
		16: "64px"
	},
	radius: {
		none: "0px",
		small: "4px",
		large: "20px",
		pill: "999px"
	},
	border: { width: "1px" },
	size: {
		control: "48px",
		compact: "44px",
		small: "32px",
		choice: "20px",
		marker: "10px",
		switchHeight: "28px"
	},
	icon: {
		small: "16px",
		medium: "20px",
		large: "24px",
		xlarge: "32px",
		display: "48px"
	},
	shadow: {
		none: "none",
		small: "2px 2px 0 var(--a-color-ink)",
		interactive: "4px 4px 0 var(--a-color-ink)",
		floating: "8px 8px 0 var(--a-color-ink)"
	},
	motion: {
		fast: "150ms",
		disclosure: "200ms",
		ease: "cubic-bezier(0.4, 0, 0.2, 1)",
		out: "cubic-bezier(0.22, 1, 0.36, 1)",
		lift: "-2px",
		liftStrong: "-4px",
		spin: "1s"
	},
	state: { disabled: "0.45" },
	focus: {
		width: "2px",
		offset: "4px"
	},
	layer: {
		base: "0",
		popover: "20",
		modal: "40",
		toast: "60"
	},
	font: { family: "\"Avenir Next\", Avenir, Montserrat, Corbel, \"URW Gothic\", sans-serif" }
}, ie = {
	h1: {
		size: "48px",
		line: "52px",
		weight: 500
	},
	h2: {
		size: "32px",
		line: "36px",
		weight: 500
	},
	h3: {
		size: "24px",
		line: "28px",
		weight: 500
	},
	h4: {
		size: "20px",
		line: "24px",
		weight: 500
	},
	h5: {
		size: "18px",
		line: "24px",
		weight: 600
	},
	h6: {
		size: "16px",
		line: "22px",
		weight: 600
	},
	h7: {
		size: "14px",
		line: "20px",
		weight: 600
	},
	leadLarge: {
		size: "24px",
		line: "36px",
		weight: 500
	},
	leadMedium: {
		size: "20px",
		line: "28px",
		weight: 500
	},
	body: {
		size: "16px",
		line: "22px",
		weight: 400
	},
	small: {
		size: "14px",
		line: "20px",
		weight: 400
	}
}, ae = Object.fromEntries([...Object.entries(re).flatMap(([e, t]) => {
	let n = (e, t) => Object.entries(e).flatMap(([e, r]) => typeof r == "object" ? n(r, `${t}-${e}`) : [[`--a-${t}-${e}`, String(r)]]);
	return n(t, e);
}), ...Object.entries(ie).flatMap(([e, t]) => Object.entries(t).map(([t, n]) => [`--a-type-${e}-${t}`, String(n)]))]), oe = (e) => ({
	fontSize: `var(--a-type-${e}-size)`,
	lineHeight: `var(--a-type-${e}-line)`,
	fontWeight: `var(--a-type-${e}-weight)`
});
//#endregion
//#region src/atomic/atoms/typography.tsx
function H({ className: e = "", style: n, ...r }) {
	return /* @__PURE__ */ t("div", {
		...r,
		className: `atomic-root ${e}`.trim(),
		style: {
			...ae,
			...n
		}
	});
}
function U({ level: e, variant: n = `h${e}`, className: r = "", style: i, ...a }) {
	let o = `h${e}`;
	return /* @__PURE__ */ t(o, {
		...a,
		className: `a-type ${r}`.trim(),
		"data-type": n,
		style: {
			...oe(n),
			...i
		}
	});
}
function W({ as: e = "p", variant: n = "body", tone: r = "ink", className: i = "", style: a, ...o }) {
	return /* @__PURE__ */ t(e, {
		...o,
		className: `a-type ${i}`.trim(),
		"data-type": n,
		style: {
			...oe(n),
			color: r === "inherit" ? "inherit" : `var(--a-color-${r})`,
			...a
		}
	});
}
//#endregion
//#region src/atomic/atoms/Icon.tsx
var se = {
	...te,
	calendar: s,
	arrowUp: o,
	arrowDown: r,
	search: D,
	plus: E,
	minus: w,
	star: k,
	clock: f,
	check: c,
	close: j,
	arrowLeft: i,
	arrowRight: a,
	chevronDown: l,
	chevronRight: u,
	copy: p,
	download: m,
	upload: A,
	delete: ee,
	edit: T,
	settings: O,
	menu: C,
	more: h,
	eye: _,
	info: x,
	alert: d,
	loading: S,
	image: b,
	file: v,
	folder: y,
	externalLink: g
};
function G({ name: e, size: n = "medium", label: r, className: i = "" }) {
	let a = se[e];
	return /* @__PURE__ */ t(a, {
		className: `a-icon ${i}`.trim(),
		"data-icon": e,
		style: { "--icon-size": `var(--a-icon-${n})` },
		strokeWidth: 1.5,
		role: r ? "img" : void 0,
		"aria-label": r || void 0,
		"aria-hidden": !r || void 0,
		focusable: "false"
	});
}
//#endregion
//#region src/atomic/atoms/layout.tsx
var ce = (e) => ({ "--layout-gap": `var(--a-space-${e})` });
function K({ gap: e = 4, className: n = "", style: r, ...i }) {
	return /* @__PURE__ */ t("div", {
		...i,
		className: `a-stack ${n}`.trim(),
		style: {
			...ce(e),
			...r
		}
	});
}
function q({ gap: e = 2, className: n = "", style: r, ...i }) {
	return /* @__PURE__ */ t("div", {
		...i,
		className: `a-inline ${n}`.trim(),
		style: {
			...ce(e),
			...r
		}
	});
}
function le({ gap: e = 4, minItemWidth: n = "16rem", className: r = "", style: i, ...a }) {
	return /* @__PURE__ */ t("div", {
		...a,
		className: `a-grid ${r}`.trim(),
		style: {
			...ce(e),
			"--grid-min": n,
			...i
		}
	});
}
function ue({ className: e = "", style: n, maxWidth: r = "72rem", ...i }) {
	return /* @__PURE__ */ t("div", {
		...i,
		className: `a-container ${e}`.trim(),
		style: {
			maxWidth: r,
			...n
		}
	});
}
function J({ as: e = "div", padding: n = 8, radius: r = "large", elevation: i = "none", tone: a = "surface", className: o = "", style: s, ...c }) {
	return /* @__PURE__ */ t(e, {
		...c,
		className: `a-surface ${o}`.trim(),
		style: {
			padding: `var(--a-space-${n})`,
			borderRadius: `var(--a-radius-${r})`,
			"--surface-elevation": `var(--a-shadow-${i})`,
			background: `var(--a-color-${a})`,
			...s
		}
	});
}
function de(e) {
	return /* @__PURE__ */ t("hr", {
		...e,
		className: `a-divider ${e.className ?? ""}`.trim()
	});
}
function fe({ label: e, className: n = "", style: r, maxHeight: i = "16rem", ...a }) {
	return /* @__PURE__ */ t("div", {
		...a,
		className: `a-scroll ${n}`.trim(),
		style: {
			maxHeight: i,
			...r
		},
		role: "region",
		"aria-label": e,
		tabIndex: 0
	});
}
//#endregion
//#region src/atomic/components/Button.tsx
function Y({ children: e, icon: r, iconOnly: i = !1, iconPosition: a = "start", variant: o = "secondary", size: s = "default", busy: c = !1, disabled: l = !1, type: u = "button", className: d = "", ...f }) {
	let p = c ? /* @__PURE__ */ t(G, {
		name: "loading",
		className: "c-button__spinner"
	}) : r ? /* @__PURE__ */ t(G, { name: r }) : null;
	return /* @__PURE__ */ n("button", {
		...f,
		type: u,
		disabled: l || c,
		"aria-busy": c || void 0,
		className: `c-button ${d}`.trim(),
		"data-variant": o,
		"data-size": s,
		"data-icon-only": i || void 0,
		children: [
			a === "start" && p,
			!i && /* @__PURE__ */ t(W, {
				as: "span",
				variant: "h6",
				tone: "inherit",
				children: e
			}),
			a === "end" && p
		]
	});
}
//#endregion
//#region src/atomic/components/FeedbackButton.tsx
function pe({ label: e, successLabel: n, icon: r, successIcon: i, onAction: a, onError: o, resetKey: s, successAriaLabel: c, "aria-label": l, disabled: u = !1, busy: d = !1, ref: f, ...p }) {
	let [m, h] = F(!1), [g, _] = F(!1), v = P(0);
	M(() => {
		v.current += 1, h(!1), _(!1);
	}, [s]);
	async function y() {
		if (g || m) return;
		let e = ++v.current;
		_(!0);
		try {
			if (await a(), e !== v.current) return;
			h(!0);
		} catch (t) {
			e === v.current && o?.(t);
		} finally {
			e === v.current && _(!1);
		}
	}
	let b = m ? n : e;
	return /* @__PURE__ */ t(Y, {
		...p,
		ref: f,
		icon: m ? i : r,
		disabled: u || g,
		busy: d || g,
		"aria-label": m ? c ?? n : l ?? e,
		onClick: y,
		children: b
	});
}
//#endregion
//#region src/atomic/components/Panel.tsx
function me({ title: e, description: r, headingLevel: i = 3, variant: a = "default", filters: o, actions: s, density: c = "default", as: l = "section", children: u, className: d = "", ...f }) {
	let p = N(), m = /* @__PURE__ */ n(K, {
		gap: 1,
		children: [/* @__PURE__ */ t(U, {
			id: p,
			level: i,
			variant: "h4",
			children: e
		}), r != null && /* @__PURE__ */ t(W, {
			tone: "secondary",
			children: r
		})]
	}), h = s == null ? m : /* @__PURE__ */ n(q, {
		className: "c-panel__heading-row",
		gap: 3,
		children: [m, /* @__PURE__ */ t("div", {
			className: "c-panel__actions",
			children: s
		})]
	}), g = c === "compact" ? 3 : 6;
	return a === "split" ? /* @__PURE__ */ n(J, {
		...f,
		as: l,
		padding: 0,
		"data-density": c,
		className: `c-panel c-panel--split ${d}`.trim(),
		"aria-labelledby": p,
		children: [/* @__PURE__ */ t("header", {
			className: "c-panel__header",
			children: /* @__PURE__ */ n(K, {
				gap: g,
				children: [h, o]
			})
		}), u != null && /* @__PURE__ */ t("div", {
			className: "c-panel__content",
			children: /* @__PURE__ */ t(K, {
				gap: g,
				children: u
			})
		})]
	}) : /* @__PURE__ */ t(J, {
		...f,
		as: l,
		padding: c === "compact" ? 4 : 8,
		"data-density": c,
		className: `c-panel ${d}`.trim(),
		"aria-labelledby": p,
		children: /* @__PURE__ */ n(K, {
			gap: g,
			children: [
				h,
				o,
				u
			]
		})
	});
}
//#endregion
//#region src/atomic/components/FieldSupport.tsx
var X = (e) => e != null && e !== !1 && e !== "", Z = (e, t, n, r) => [
	r,
	X(t) && `${e}-hint`,
	X(n) && `${e}-error`
].filter(Boolean).join(" ") || void 0;
function Q({ id: r, instructions: i, error: a }) {
	return /* @__PURE__ */ n(e, { children: [X(i) && /* @__PURE__ */ t(W, {
		id: `${r}-hint`,
		variant: "small",
		tone: "secondary",
		children: i
	}), X(a) && /* @__PURE__ */ t(W, {
		id: `${r}-error`,
		variant: "small",
		role: "alert",
		className: "c-field-error",
		tone: "inherit",
		children: a
	})] });
}
//#endregion
//#region src/atomic/components/TextField.tsx
function he({ label: e, instructions: r, error: i, id: a, className: o = "", type: s = "text", width: c = [
	"number",
	"time",
	"date",
	"color"
].includes(s) ? "content" : "full", trailing: l, onChange: u, "aria-describedby": d, "aria-invalid": f, ...p }) {
	let m = N(), h = a ?? m, [g, _] = F(String(p.defaultValue ?? "").length), v = Math.max(s === "time" ? 10 : s === "date" ? 12 : 4, p.value == null ? g : String(p.value).length, p.placeholder?.length ?? 0);
	return /* @__PURE__ */ n(K, {
		gap: 2,
		className: `c-field${c === "content" ? " c-field--content" : ""}`,
		style: { "--field-characters": v + 2 },
		children: [
			/* @__PURE__ */ t("label", {
				htmlFor: h,
				children: /* @__PURE__ */ t(W, {
					as: "span",
					variant: "h7",
					children: e
				})
			}),
			/* @__PURE__ */ n("div", {
				className: "c-text-input-wrap",
				children: [/* @__PURE__ */ t("input", {
					...p,
					onChange: (e) => {
						_(e.target.value.length), u?.(e);
					},
					id: h,
					type: s,
					className: `c-text-input ${o}`.trim(),
					"aria-describedby": Z(h, r, i, d),
					"aria-invalid": X(i) || f || void 0
				}), l && /* @__PURE__ */ t("span", {
					className: "c-text-input__trailing",
					children: l
				})]
			}),
			/* @__PURE__ */ t(Q, {
				id: h,
				instructions: r,
				error: i
			})
		]
	});
}
//#endregion
//#region src/atomic/components/Checkbox.tsx
function ge({ label: e, instructions: r, error: i, indeterminate: a = !1, id: o, checked: s, defaultChecked: c, className: l = "", "aria-describedby": u, "aria-invalid": d, ...f }) {
	let p = N(), m = o ?? p, h = P(null);
	return M(() => {
		h.current && (h.current.indeterminate = a);
	}, [a]), /* @__PURE__ */ n(K, {
		gap: 1,
		children: [/* @__PURE__ */ n("label", {
			className: "c-choice-row",
			htmlFor: m,
			children: [/* @__PURE__ */ n("span", {
				className: "c-check-control",
				children: [/* @__PURE__ */ t("input", {
					...f,
					...s === void 0 ? { defaultChecked: c } : { checked: s },
					ref: h,
					id: m,
					type: "checkbox",
					className: `c-checkbox ${l}`.trim(),
					"aria-describedby": Z(m, r, i, u),
					"aria-invalid": X(i) || d || void 0
				}), /* @__PURE__ */ t("span", {
					className: "c-choice-mark",
					"aria-hidden": "true",
					children: /* @__PURE__ */ t(G, {
						name: "check",
						size: "small"
					})
				})]
			}), /* @__PURE__ */ t(W, {
				as: "span",
				children: e
			})]
		}), /* @__PURE__ */ t(Q, {
			id: m,
			instructions: r,
			error: i
		})]
	});
}
//#endregion
//#region src/atomic/components/RadioGroup.tsx
function _e({ id: e, name: r, label: i, instructions: a, error: o, options: s, value: c, defaultValue: l, onChange: u, disabled: d = !1, required: f, className: p = "", customOption: m }) {
	let h = N(), g = e ?? h, _ = r ?? h, [v, y] = F(l), b = c ?? v, x = m ? [...s, m] : s;
	return /* @__PURE__ */ n("fieldset", {
		id: g,
		disabled: d,
		className: `c-radio-group ${p}`.trim(),
		"aria-describedby": Z(g, a, o),
		"aria-invalid": X(o) || void 0,
		children: [/* @__PURE__ */ t("legend", { children: /* @__PURE__ */ t(W, {
			as: "span",
			variant: "h7",
			children: i
		}) }), /* @__PURE__ */ n(K, {
			gap: 2,
			children: [
				/* @__PURE__ */ t(Q, {
					id: g,
					instructions: a
				}),
				/* @__PURE__ */ t(K, {
					gap: 0,
					children: x.map((e, r) => /* @__PURE__ */ n("label", {
						className: "c-choice-row",
						htmlFor: `${g}-${r}`,
						children: [/* @__PURE__ */ t("input", {
							type: "radio",
							id: `${g}-${r}`,
							name: _,
							value: e.value,
							className: "c-radio",
							checked: b === e.value,
							disabled: e.disabled,
							required: f,
							"aria-describedby": Z(g, a, o),
							"aria-invalid": X(o) || void 0,
							onChange: () => {
								y(e.value), u?.(e.value);
							}
						}), /* @__PURE__ */ t(W, {
							as: "span",
							children: e.label
						})]
					}, e.value))
				}),
				m && /* @__PURE__ */ t(he, {
					label: `${m.label} answer`,
					name: r ? `${r}Custom` : void 0,
					value: m.text,
					onChange: (e) => m.onTextChange(e.target.value),
					placeholder: m.placeholder,
					disabled: d || b !== m.value,
					required: f && b === m.value
				}),
				/* @__PURE__ */ t(Q, {
					id: g,
					error: o
				})
			]
		})]
	});
}
//#endregion
//#region src/atomic/components/Toggle.tsx
function ve({ label: e, instructions: r, error: i, id: a, checked: o, defaultChecked: s, className: c = "", "aria-describedby": l, "aria-invalid": u, ...d }) {
	let f = N(), p = a ?? f;
	return /* @__PURE__ */ n(K, {
		gap: 1,
		children: [/* @__PURE__ */ n("label", {
			htmlFor: p,
			className: "c-choice-row",
			children: [/* @__PURE__ */ t("input", {
				...d,
				...o === void 0 ? { defaultChecked: s } : { checked: o },
				type: "checkbox",
				role: "switch",
				id: p,
				className: `c-toggle ${c}`.trim(),
				"aria-describedby": Z(p, r, i, l),
				"aria-invalid": X(i) || u || void 0
			}), /* @__PURE__ */ t(W, {
				as: "span",
				children: e
			})]
		}), /* @__PURE__ */ t(Q, {
			id: p,
			instructions: r,
			error: i
		})]
	});
}
//#endregion
//#region src/atomic/components/TextArea.tsx
function ye(e) {
	let t = getComputedStyle(e), n = (e) => parseFloat(e) || 0, r = n(t.borderTopWidth) + n(t.borderBottomWidth), i = e.rows * n(t.lineHeight) + n(t.paddingTop) + n(t.paddingBottom) + r;
	e.style.height = "0px", e.style.height = `${Math.max(i, e.scrollHeight + r)}px`;
}
function be({ label: e, embedded: r = !1, hideLabel: i = !1, instructions: a, error: o, id: s, rows: c = 3, className: l = "", onInput: u, "aria-describedby": d, "aria-invalid": f, ...p }) {
	let m = N(), h = s ?? m, g = P(null);
	return ne(() => {
		g.current && ye(g.current);
	}), ne(() => {
		let e = g.current;
		if (!e || typeof ResizeObserver > "u") return;
		let t = e.getBoundingClientRect().width, n = new ResizeObserver(() => {
			let n = e.getBoundingClientRect().width;
			n !== t && (t = n, ye(e));
		});
		return n.observe(e), () => n.disconnect();
	}, []), /* @__PURE__ */ n(K, {
		gap: 2,
		className: "c-field",
		children: [
			/* @__PURE__ */ t("label", {
				htmlFor: h,
				className: i ? "c-field-label-hidden" : void 0,
				children: /* @__PURE__ */ t(W, {
					as: "span",
					variant: "h7",
					children: e
				})
			}),
			/* @__PURE__ */ t("textarea", {
				...p,
				ref: g,
				id: h,
				rows: c,
				className: `c-text-input c-textarea ${r ? "c-textarea--embedded" : ""} ${l}`.trim(),
				"aria-describedby": Z(h, a, o, d),
				"aria-invalid": X(o) || f || void 0,
				onInput: (e) => {
					ye(e.currentTarget), u?.(e);
				}
			}),
			/* @__PURE__ */ t(Q, {
				id: h,
				instructions: a,
				error: o
			})
		]
	});
}
//#endregion
//#region src/atomic/components/Select.tsx
function xe({ label: e, options: r, placeholder: i, value: a, defaultValue: o, instructions: s, error: c, id: l, className: u = "", disabled: d, name: f, required: p, onChange: m, onValueChange: h, customOption: g, "aria-describedby": _, "aria-invalid": v }) {
	let y = N(), b = l ?? y, x = P(null), [S, C] = F(o ?? (i ? "" : r.find((e) => !e.disabled)?.value ?? "")), w = a ?? S, T = g ? [...r, g] : r, E = (e) => {
		if (C(e), h?.(e), x.current && m) {
			x.current.value = e;
			let t = new Event("change", { bubbles: !0 });
			m({
				target: x.current,
				currentTarget: x.current,
				nativeEvent: t,
				type: "change",
				bubbles: !0,
				cancelable: !1,
				defaultPrevented: !1,
				eventPhase: 3,
				isTrusted: !1,
				timeStamp: t.timeStamp,
				persist() {},
				isDefaultPrevented: () => !1,
				isPropagationStopped: () => !1,
				preventDefault: () => t.preventDefault(),
				stopPropagation: () => t.stopPropagation()
			});
		}
	};
	return /* @__PURE__ */ n(K, {
		gap: 2,
		className: "c-field",
		children: [
			/* @__PURE__ */ t("label", {
				id: `${b}-label`,
				htmlFor: b,
				children: /* @__PURE__ */ t(W, {
					as: "span",
					variant: "h7",
					children: e
				})
			}),
			/* @__PURE__ */ n(z.Root, {
				value: w,
				onValueChange: E,
				disabled: d,
				children: [/* @__PURE__ */ n(z.Trigger, {
					id: b,
					className: `c-text-input c-select-trigger ${u}`,
					"aria-labelledby": `${b}-label`,
					"aria-describedby": Z(b, s, c, _),
					"aria-invalid": X(c) || v || void 0,
					"aria-required": p,
					children: [/* @__PURE__ */ t(z.Value, { placeholder: i }), /* @__PURE__ */ t(z.Icon, {
						asChild: !0,
						children: /* @__PURE__ */ t(G, {
							name: "chevronDown",
							size: "small"
						})
					})]
				}), /* @__PURE__ */ t(z.Portal, { children: /* @__PURE__ */ t(H, {
					className: "c-overlay-root",
					children: /* @__PURE__ */ t(z.Content, {
						className: "c-dropdown-popup",
						position: "popper",
						sideOffset: 8,
						collisionPadding: 16,
						children: /* @__PURE__ */ t(z.Viewport, { children: T.map((e) => /* @__PURE__ */ n(z.Item, {
							value: e.value,
							disabled: "disabled" in e && e.disabled,
							className: "c-dropdown-option",
							children: [/* @__PURE__ */ n(q, {
								gap: 2,
								children: ["icon" in e && e.icon && /* @__PURE__ */ t(G, {
									name: e.icon,
									size: "small"
								}), /* @__PURE__ */ t(z.ItemText, { children: e.label })]
							}), /* @__PURE__ */ t(z.ItemIndicator, { children: /* @__PURE__ */ t(G, {
								name: "check",
								size: "small"
							}) })]
						}, e.value)) })
					})
				}) })]
			}),
			/* @__PURE__ */ n("select", {
				ref: x,
				name: f,
				value: w,
				onChange: (e) => E(e.target.value),
				disabled: d,
				required: p,
				tabIndex: -1,
				"aria-hidden": "true",
				className: "c-select-native",
				onInvalid: (e) => {
					e.preventDefault(), document.getElementById(b)?.focus();
				},
				children: [/* @__PURE__ */ t("option", { value: "" }), T.map((e) => /* @__PURE__ */ t("option", {
					value: e.value,
					disabled: "disabled" in e && e.disabled,
					children: e.label
				}, e.value))]
			}),
			g && w === g.value && /* @__PURE__ */ t(he, {
				label: `${g.label} answer`,
				value: g.text,
				onChange: (e) => g.onTextChange(e.target.value),
				disabled: d,
				required: p,
				name: f ? `${f}Custom` : void 0
			}),
			/* @__PURE__ */ t(Q, {
				id: b,
				instructions: s,
				error: c
			})
		]
	});
}
//#endregion
//#region src/atomic/components/Tag.tsx
function Se({ children: e, tone: r = "neutral", icon: i, status: a, onRemove: o, removeLabel: s, className: c = "", ...l }) {
	return a && (r = a === "pending" ? "accent" : a, i ??= a === "pending" ? "clock" : a === "success" ? "check" : a === "danger" ? "alert" : "info"), /* @__PURE__ */ t("span", {
		...l,
		className: `c-tag-wrap ${c}`.trim(),
		children: /* @__PURE__ */ n("span", {
			className: "c-tag",
			"data-tone": r,
			children: [
				i && /* @__PURE__ */ t(G, {
					name: i,
					size: "small"
				}),
				/* @__PURE__ */ t(W, {
					as: "span",
					variant: "small",
					tone: "inherit",
					children: e
				}),
				o && /* @__PURE__ */ t("button", {
					type: "button",
					className: "c-tag__remove",
					"aria-label": s,
					onClick: o,
					children: /* @__PURE__ */ t(G, {
						name: "close",
						size: "small"
					})
				})
			]
		})
	});
}
//#endregion
//#region src/atomic/components/SegmentedControl.tsx
function Ce({ label: e, options: r, size: i = "default", value: a, defaultValue: o, onChange: s, name: c, disabled: l = !1, className: u = "", style: d, ...f }) {
	let [p, m] = F(o ?? r.find((e) => !e.disabled)?.value), h = a === void 0 ? p : a, g = r.findIndex((e) => e.value === h), _ = r.map((e, t) => e.disabled ? -1 : t).filter((e) => e >= 0), v = _.includes(g) ? g : _[0], y = P([]);
	function b(e) {
		let t = r[e];
		l || !t || t.disabled || (a === void 0 && m(t.value), s?.(t.value));
	}
	function x(e, t) {
		if (![
			"ArrowRight",
			"ArrowLeft",
			"ArrowDown",
			"ArrowUp",
			"Home",
			"End"
		].includes(e.key) || l || !_.length) return;
		e.preventDefault();
		let n = getComputedStyle(e.currentTarget).direction === "rtl", r = e.key === "ArrowDown" || e.key === (n ? "ArrowLeft" : "ArrowRight"), i = _.indexOf(t), a = e.key === "Home" ? _[0] : e.key === "End" ? _[_.length - 1] : _[(i + (r ? 1 : -1) + _.length) % _.length];
		b(a), y.current[a]?.focus(), y.current[a]?.scrollIntoView?.({
			block: "nearest",
			inline: "nearest"
		});
	}
	return /* @__PURE__ */ t(fe, {
		label: `${e} options`,
		maxHeight: "none",
		className: "c-segmented-scroll",
		children: /* @__PURE__ */ n("div", {
			...f,
			role: "radiogroup",
			"aria-label": e,
			"aria-disabled": l || void 0,
			"data-size": i,
			className: `c-segmented ${u}`.trim(),
			style: {
				"--segment-count": Math.max(1, r.length),
				"--segment-index": g,
				...d
			},
			children: [
				g >= 0 && /* @__PURE__ */ t("span", {
					className: "c-segmented__indicator",
					"aria-hidden": "true"
				}),
				r.map((e, n) => /* @__PURE__ */ t("button", {
					ref: (e) => {
						y.current[n] = e;
					},
					type: "button",
					role: "radio",
					"aria-checked": n === g,
					disabled: l || e.disabled,
					tabIndex: !l && n === v ? 0 : -1,
					className: "c-segmented__option",
					onClick: () => b(n),
					onKeyDown: (e) => x(e, n),
					children: /* @__PURE__ */ t(W, {
						as: "span",
						variant: "h6",
						tone: "inherit",
						children: e.label
					})
				}, e.value)),
				c && g >= 0 && /* @__PURE__ */ t("input", {
					type: "hidden",
					name: c,
					value: h,
					disabled: l || r[g].disabled
				})
			]
		})
	});
}
//#endregion
//#region src/atomic/components/Breadcrumbs.tsx
function we({ items: e, label: r = "Breadcrumbs", className: i = "" }) {
	return /* @__PURE__ */ t("nav", {
		"aria-label": r,
		className: `c-breadcrumbs ${i}`.trim(),
		children: /* @__PURE__ */ t("ol", { children: e.map((r, i) => {
			let a = i === e.length - 1;
			return /* @__PURE__ */ n("li", { children: [i > 0 && /* @__PURE__ */ t(G, {
				name: "chevronRight",
				size: "small"
			}), !a && r.href ? /* @__PURE__ */ t("a", {
				className: "c-breadcrumbs__link",
				href: r.href,
				children: /* @__PURE__ */ t(W, {
					as: "span",
					variant: "small",
					children: r.label
				})
			}) : /* @__PURE__ */ t(W, {
				as: "span",
				variant: a ? "h7" : "small",
				"aria-current": a ? "page" : void 0,
				children: r.label
			})] }, i);
		}) })
	});
}
//#endregion
//#region src/atomic/components/Pagination.tsx
function Te({ page: e, pageCount: r, onPageChange: i, disabled: a = !1, label: o = "Pagination", className: s = "" }) {
	let c = Number.isFinite(r) ? Math.max(0, Math.floor(r)) : 0, l = Math.min(Math.max(1, Math.floor(e) || 1), Math.max(1, c)), u = c <= 7 ? Array.from({ length: c }, (e, t) => t + 1) : [.../* @__PURE__ */ new Set([
		1,
		...Array.from({ length: 3 }, (e, t) => Math.min(c - 3, Math.max(2, l - 1)) + t),
		c
	])].sort((e, t) => e - t);
	return /* @__PURE__ */ t("nav", {
		"aria-label": o,
		className: `c-pagination ${s}`.trim(),
		children: /* @__PURE__ */ n("ol", { children: [
			/* @__PURE__ */ t("li", { children: /* @__PURE__ */ t(Y, {
				iconOnly: !0,
				icon: "arrowLeft",
				size: "compact",
				"aria-label": "Previous page",
				disabled: a || l <= 1 || !c,
				onClick: () => i(l - 1)
			}) }),
			u.map((e, r) => /* @__PURE__ */ n("li", { children: [r > 0 && e - u[r - 1] > 1 && /* @__PURE__ */ t(W, {
				as: "span",
				"aria-hidden": "true",
				children: "…"
			}), /* @__PURE__ */ t(Y, {
				size: "compact",
				"aria-label": `Page ${e}`,
				"aria-current": e === l ? "page" : void 0,
				variant: e === l ? "primary" : "secondary",
				disabled: a,
				onClick: () => {
					e !== l && i(e);
				},
				children: e
			})] }, e)),
			/* @__PURE__ */ t("li", { children: /* @__PURE__ */ t(Y, {
				iconOnly: !0,
				icon: "arrowRight",
				size: "compact",
				"aria-label": "Next page",
				disabled: a || l >= c,
				onClick: () => i(l + 1)
			}) })
		] })
	});
}
//#endregion
//#region src/atomic/components/NumberStepper.tsx
function Ee({ label: e, value: r, onChange: i, min: a = 0, max: o = 100, step: s = 1, name: c, id: l, disabled: u = !1, instructions: d, className: f = "" }) {
	let p = N(), m = l ?? p, h = Math.max(a, o), g = s > 0 && Number.isFinite(s) ? s : 1, _ = (e) => Math.min(h, Math.max(a, Number.isFinite(e) ? e : a)), v = _(r), [y, b] = F(null), x = (e) => {
		b(null);
		let t = _(Number(e.toFixed(10)));
		t !== v && i(t);
	};
	return /* @__PURE__ */ n(K, {
		gap: 2,
		className: `c-number-stepper ${f}`.trim(),
		children: [
			/* @__PURE__ */ t("label", {
				htmlFor: m,
				children: /* @__PURE__ */ t(W, {
					as: "span",
					variant: "h7",
					children: e
				})
			}),
			/* @__PURE__ */ n(q, {
				gap: 0,
				children: [
					/* @__PURE__ */ t(Y, {
						iconOnly: !0,
						icon: "minus",
						"aria-label": `Decrease ${e}`,
						disabled: u || v <= a,
						onClick: () => x(v - g)
					}),
					/* @__PURE__ */ t("input", {
						id: m,
						name: c,
						type: "number",
						value: y ?? v,
						min: a,
						max: h,
						step: g,
						disabled: u,
						"aria-describedby": Z(m, d),
						onChange: (e) => b(e.target.value),
						onBlur: () => x(y === null || y.trim() === "" ? v : Number(y)),
						onKeyDown: (e) => {
							e.key === "Enter" && (e.preventDefault(), x(y === null || y.trim() === "" ? v : Number(y)));
						}
					}),
					/* @__PURE__ */ t(Y, {
						iconOnly: !0,
						icon: "plus",
						"aria-label": `Increase ${e}`,
						disabled: u || v >= h,
						onClick: () => x(v + g)
					})
				]
			}),
			/* @__PURE__ */ t(Q, {
				id: m,
				instructions: d
			})
		]
	});
}
//#endregion
//#region src/atomic/components/Slider.tsx
function De({ label: e, value: r, onChange: i, min: a = 0, max: o = 100, step: s = 1, name: c, id: l, disabled: u, instructions: d, formatValue: f = String, className: p = "" }) {
	let m = N(), h = l ?? m, g = Math.max(a, o), _ = Math.min(g, Math.max(a, Number.isFinite(r) ? r : a)), v = g === a ? 0 : (_ - a) / (g - a) * 100;
	return /* @__PURE__ */ n(K, {
		gap: 2,
		className: `c-slider ${p}`.trim(),
		children: [
			/* @__PURE__ */ n("div", {
				className: "c-slider__label",
				children: [/* @__PURE__ */ t("label", {
					htmlFor: h,
					children: /* @__PURE__ */ t(W, {
						as: "span",
						variant: "h7",
						children: e
					})
				}), /* @__PURE__ */ t(W, {
					as: "span",
					variant: "h6",
					"aria-hidden": "true",
					children: f(_)
				})]
			}),
			/* @__PURE__ */ t("input", {
				type: "range",
				id: h,
				name: c,
				min: a,
				max: g,
				step: s > 0 ? s : 1,
				value: _,
				disabled: u,
				"aria-valuetext": f(_),
				"aria-describedby": Z(h, d),
				style: { "--range-progress": `${v}%` },
				onChange: (e) => i(Number(e.target.value))
			}),
			/* @__PURE__ */ t(Q, {
				id: h,
				instructions: d
			})
		]
	});
}
//#endregion
//#region src/atomic/components/RangeSlider.tsx
function Oe({ label: e, value: r, onChange: i, min: a = 0, max: o = 100, names: s, lowerLabel: c = "Minimum", upperLabel: l = "Maximum", instructions: u, className: d = "", ...f }) {
	let p = Math.max(a, o), m = Math.min(p, Math.max(a, Number.isFinite(r[0]) ? r[0] : a)), h = Math.min(p, Math.max(m, Number.isFinite(r[1]) ? r[1] : p));
	return /* @__PURE__ */ n("fieldset", {
		className: `c-range-slider ${d}`.trim(),
		disabled: f.disabled,
		children: [/* @__PURE__ */ t("legend", { children: /* @__PURE__ */ t(W, {
			as: "span",
			variant: "h7",
			children: e
		}) }), /* @__PURE__ */ n(K, {
			gap: 4,
			children: [
				u && /* @__PURE__ */ t(W, {
					variant: "small",
					tone: "secondary",
					children: u
				}),
				/* @__PURE__ */ t(De, {
					...f,
					label: c,
					name: s?.[0],
					min: a,
					max: h,
					value: m,
					onChange: (e) => i([Math.min(e, h), h])
				}),
				/* @__PURE__ */ t(De, {
					...f,
					label: l,
					name: s?.[1],
					min: m,
					max: p,
					value: h,
					onChange: (e) => i([m, Math.max(e, m)])
				})
			]
		})]
	});
}
//#endregion
//#region src/atomic/components/Rating.tsx
function ke({ label: e, value: r, onChange: i, max: a = 5, name: o, disabled: s, className: c = "" }) {
	let l = N(), u = o ?? l, d = Number.isFinite(a) ? Math.max(1, Math.min(10, Math.floor(a))) : 5;
	return /* @__PURE__ */ n("fieldset", {
		className: `c-rating ${c}`.trim(),
		disabled: s,
		children: [/* @__PURE__ */ t("legend", { children: /* @__PURE__ */ t(W, {
			as: "span",
			variant: "h7",
			children: e
		}) }), /* @__PURE__ */ t("div", {
			className: "c-rating__options",
			children: Array.from({ length: d }, (e, t) => t + 1).map((e) => /* @__PURE__ */ n("label", {
				className: "c-rating__choice",
				"data-filled": e <= r || void 0,
				children: [/* @__PURE__ */ t("input", {
					type: "radio",
					name: u,
					value: e,
					checked: e === r,
					onChange: () => i(e),
					"aria-label": `${e} of ${d}`
				}), /* @__PURE__ */ t(G, {
					name: "star",
					size: "large"
				})]
			}, e))
		})]
	});
}
//#endregion
//#region src/atomic/components/progressValues.ts
function Ae(e, t) {
	let n = Number.isFinite(t) && t > 0 ? t : 100, r = Math.min(n, Math.max(0, Number.isFinite(e) ? e : 0));
	return {
		total: n,
		current: r,
		percent: Math.round(r / n * 100)
	};
}
//#endregion
//#region src/atomic/components/ProgressBar.tsx
function je({ label: e, value: r, max: i = 100, showValue: a = !0, className: o = "" }) {
	let s = N(), { current: c, total: l, percent: u } = Ae(r ?? 0, i);
	return /* @__PURE__ */ n(K, {
		gap: 2,
		className: `c-progress-bar ${o}`.trim(),
		children: [/* @__PURE__ */ n("div", {
			className: "c-progress__label",
			children: [/* @__PURE__ */ t(W, {
				id: s,
				as: "span",
				variant: "h6",
				children: e
			}), a && /* @__PURE__ */ t(W, {
				as: "span",
				variant: "small",
				tone: "secondary",
				children: r === void 0 ? "Working…" : `${u}%`
			})]
		}), /* @__PURE__ */ t("div", {
			className: "c-progress-bar__track",
			role: "progressbar",
			"aria-labelledby": s,
			"aria-valuemin": 0,
			"aria-valuemax": l,
			"aria-valuenow": r === void 0 ? void 0 : c,
			"data-indeterminate": r === void 0 || void 0,
			style: { "--progress": `${u}%` },
			children: /* @__PURE__ */ t("span", {})
		})]
	});
}
//#endregion
//#region src/atomic/components/ProgressRing.tsx
function Me({ label: e, value: r, max: i = 100, description: a, className: o = "" }) {
	let { current: s, total: c, percent: l } = Ae(r, i);
	return /* @__PURE__ */ n(q, {
		gap: 3,
		className: `c-progress-ring ${o}`.trim(),
		children: [/* @__PURE__ */ t("div", {
			className: "c-progress-ring__track",
			role: "progressbar",
			"aria-label": e,
			"aria-valuemin": 0,
			"aria-valuemax": c,
			"aria-valuenow": s,
			style: { "--progress": `${l}%` },
			children: /* @__PURE__ */ n(W, {
				as: "span",
				variant: "h6",
				children: [l, "%"]
			})
		}), /* @__PURE__ */ n(K, {
			gap: 1,
			children: [/* @__PURE__ */ t(W, {
				variant: "h6",
				children: e
			}), a && /* @__PURE__ */ t(W, {
				variant: "small",
				tone: "secondary",
				children: a
			})]
		})]
	});
}
//#endregion
//#region src/atomic/components/StatusBadge.tsx
var Ne = {
	neutral: {
		tone: "neutral",
		icon: "info"
	},
	pending: {
		tone: "accent",
		icon: "clock"
	},
	success: {
		tone: "success",
		icon: "check"
	},
	danger: {
		tone: "danger",
		icon: "alert"
	}
};
function Pe({ status: e, children: n, showIcon: r = !0, className: i = "" }) {
	let a = Ne[e];
	return /* @__PURE__ */ t(Se, {
		className: `c-status-badge ${i}`.trim(),
		tone: a.tone,
		icon: r ? a.icon : void 0,
		children: n
	});
}
//#endregion
//#region src/atomic/components/Alert.tsx
var Fe = (e) => e === "success" ? "check" : e === "danger" || e === "warning" ? "TriangleAlert" : e === "feature" ? "star" : "info";
function Ie({ title: e, description: r, tone: i = "neutral", variant: a = "stroke", size: o = "small", showIcon: s = !0, announce: c = !1, className: l = "", action: u }) {
	return /* @__PURE__ */ t(J, {
		padding: o === "large" ? 6 : 4,
		radius: o === "large" ? "large" : "small",
		className: `c-alert ${l}`.trim(),
		"data-tone": i,
		"data-variant": a,
		"data-size": o,
		role: c ? i === "danger" || i === "warning" ? "alert" : "status" : void 0,
		children: /* @__PURE__ */ n(q, {
			gap: 3,
			children: [
				s && /* @__PURE__ */ t("span", {
					className: "c-alert__icon",
					children: /* @__PURE__ */ t(G, {
						name: Fe(i),
						size: i === "danger" ? "medium" : "small"
					})
				}),
				/* @__PURE__ */ n(K, {
					gap: 1,
					className: "c-alert__copy",
					children: [/* @__PURE__ */ t(U, {
						level: 3,
						variant: "h7",
						children: e
					}), r && /* @__PURE__ */ t(W, {
						variant: "small",
						tone: "secondary",
						children: r
					})]
				}),
				u
			]
		})
	});
}
//#endregion
//#region src/atomic/components/InlineText.tsx
function Le({ label: e, value: r, variant: i = "body", sourceKey: a, readOnly: o, required: s, maxLength: c = 2e3, onSave: l, className: u = "" }) {
	let [d, f] = F(!1), [p, m] = F(r), [h, g] = F(r), [_, v] = F(!1), [y, b] = F(""), x = P(null), S = P(a), C = P(!1), w = N();
	M(() => {
		d || m(r);
	}, [r, a]);
	let T = (e) => {
		f(!1), b(""), e && requestAnimationFrame(() => x.current?.focus());
	}, E = async (t) => {
		if (!(C.current || o)) {
			if (s && !h.trim()) {
				b(`${e} cannot be empty.`);
				return;
			}
			if (h === p) {
				T(t);
				return;
			}
			C.current = !0, v(!0), b("");
			try {
				let e = S.current === void 0 ? await l(h) : await l(h, S.current);
				if (e?.ok === !1) {
					b(e.message || "Could not save changes.");
					return;
				}
				m(h), T(t);
			} catch (e) {
				b(e instanceof Error ? e.message : "Could not save changes.");
			} finally {
				C.current = !1, v(!1);
			}
		}
	}, D = /* @__PURE__ */ n(W, {
		as: "span",
		variant: i,
		className: "c-inline-text__copy",
		"aria-hidden": d || void 0,
		children: [d ? h : p || "Not specified", "​"]
	}), O = `c-inline-text ${u}`.trim();
	return d ? /* @__PURE__ */ n("div", {
		className: O,
		style: oe(i),
		"data-editing": "true",
		"aria-busy": _ || void 0,
		children: [
			/* @__PURE__ */ n("span", {
				className: "c-inline-text__field",
				children: [D, /* @__PURE__ */ t("textarea", {
					autoFocus: !0,
					"aria-label": e,
					"aria-describedby": y ? `${w}-error` : void 0,
					"aria-invalid": !!y || void 0,
					value: h,
					maxLength: c,
					readOnly: _ || o,
					rows: 1,
					onChange: (e) => g(e.target.value),
					onBlur: () => void E(!1),
					onKeyDown: (e) => {
						e.nativeEvent.isComposing || _ || (e.key === "Escape" && (e.preventDefault(), m(r), T(!0)), e.key === "Enter" && !e.shiftKey && (e.preventDefault(), E(!0)));
					}
				})]
			}),
			y && /* @__PURE__ */ t(W, {
				id: `${w}-error`,
				variant: "small",
				className: "c-inline-text__error",
				tone: "inherit",
				role: "alert",
				children: y
			}),
			S.current !== a && /* @__PURE__ */ t(W, {
				variant: "small",
				tone: "secondary",
				children: "The source changed. Your draft is preserved; Escape loads the latest text."
			})
		]
	}) : o ? /* @__PURE__ */ t("div", {
		className: O,
		style: oe(i),
		children: D
	}) : /* @__PURE__ */ n("button", {
		ref: x,
		type: "button",
		"aria-label": `Edit ${e}`,
		className: O,
		style: oe(i),
		onClick: () => {
			S.current = a, g(p), f(!0);
		},
		children: [/* @__PURE__ */ t("span", {
			className: "c-inline-text__field",
			children: D
		}), /* @__PURE__ */ t("span", {
			className: "c-inline-text__edit",
			"aria-hidden": "true",
			children: /* @__PURE__ */ t(G, {
				name: "edit",
				size: "small"
			})
		})]
	});
}
//#endregion
//#region src/atomic/components/TextAction.tsx
function Re({ children: e, disabled: n, className: r = "", ...i }) {
	let a = /* @__PURE__ */ t(W, {
		as: "span",
		variant: "h6",
		children: e
	}), o = `c-text-action ${r}`.trim();
	return i.href === void 0 ? /* @__PURE__ */ t("button", {
		...i,
		type: i.type ?? "button",
		className: o,
		disabled: n,
		children: a
	}) : n ? /* @__PURE__ */ t("span", {
		className: o,
		"aria-disabled": "true",
		children: a
	}) : /* @__PURE__ */ t("a", {
		...i,
		className: o,
		children: a
	});
}
//#endregion
//#region src/atomic/components/Form.tsx
function ze({ label: e, children: n, className: r = "", ...i }) {
	return /* @__PURE__ */ t("form", {
		...i,
		"aria-label": e,
		className: `c-form ${r}`.trim(),
		children: /* @__PURE__ */ t(K, {
			gap: 6,
			children: n
		})
	});
}
function Be({ onCancel: e, submitLabel: r = "Save", cancelLabel: i = "Cancel", busy: a, disabled: o, message: s }) {
	return /* @__PURE__ */ n(K, {
		gap: 2,
		className: "c-form-actions",
		children: [/* @__PURE__ */ n(q, { children: [e && /* @__PURE__ */ t(Y, {
			onClick: e,
			disabled: a,
			children: i
		}), /* @__PURE__ */ t(Y, {
			type: "submit",
			variant: "primary",
			busy: a,
			disabled: o,
			children: r
		})] }), s && /* @__PURE__ */ t(W, {
			variant: "small",
			role: "status",
			children: s
		})]
	});
}
//#endregion
//#region src/atomic/components/DatePicker.tsx
var $ = (e) => e.toISOString().slice(0, 10), Ve = (e) => {
	if (!/^\d{4}-\d{2}-\d{2}$/.test(e)) return null;
	let t = /* @__PURE__ */ new Date(e + "T12:00:00Z");
	return !Number.isNaN(t.getTime()) && $(t) === e ? t : null;
};
function He({ label: e, value: r, defaultValue: i = "", min: a, max: o, onChange: s, onValueChange: c, disabled: l, readOnly: u, required: d, name: f, id: p, instructions: m, error: h, className: g = "" }) {
	let _ = N(), v = p ?? _, y = P(null), b = P({}), [x, S] = F(i), [C, w] = F(!1), T = r ?? x, E = Ve(T) || Ve(a ?? "") || /* @__PURE__ */ new Date(), [D, O] = F(new Date(Date.UTC(E.getUTCFullYear(), E.getUTCMonth(), 1, 12))), [k, ee] = F(T || $(E));
	ne(() => {
		C && b.current[k]?.focus();
	}, [C, k]);
	let A = D.getUTCFullYear(), j = D.getUTCMonth(), te = new Date(Date.UTC(A, j + 1, 0)).getUTCDate(), M = (D.getUTCDay() + 6) % 7, I = (e) => !!a && e < a || !!o && e > o, L = typeof e == "string" ? e : "Date", z = (e) => {
		I(e) || (S(e), c?.(e), y.current && s && (y.current.value = e, s({
			target: y.current,
			currentTarget: y.current
		})), w(!1));
	}, B = (e) => {
		let t = new Date(Date.UTC(A, j + e, 1, 12));
		O(t);
		let n = $(t);
		ee(a && n < a ? a : o && n > o ? o : n);
	}, V = (e, t) => {
		let n = Ve(t), r = e.key === "ArrowRight" ? 1 : e.key === "ArrowLeft" ? -1 : e.key === "ArrowDown" ? 7 : e.key === "ArrowUp" ? -7 : 0;
		if (e.key === "Home" && (r = -((n.getUTCDay() + 6) % 7)), e.key === "End" && (r = 6 - (n.getUTCDay() + 6) % 7), e.key === "PageDown" || e.key === "PageUp") {
			e.preventDefault(), B(e.key === "PageDown" ? 1 : -1);
			return;
		}
		if (!r && e.key !== "Home") return;
		e.preventDefault(), n.setUTCDate(n.getUTCDate() + r);
		let i = $(n);
		I(i) || (ee(i), n.getUTCMonth() === j ? b.current[i]?.focus() : O(new Date(Date.UTC(n.getUTCFullYear(), n.getUTCMonth(), 1, 12))));
	};
	return /* @__PURE__ */ n(K, {
		gap: 2,
		className: `c-date-picker c-field ${g}`,
		children: [
			/* @__PURE__ */ t("label", {
				htmlFor: v,
				children: /* @__PURE__ */ t(W, {
					as: "span",
					variant: "h7",
					children: e
				})
			}),
			/* @__PURE__ */ n(R.Root, {
				open: C,
				onOpenChange: (e) => {
					if (w(e), e) {
						let e = Ve(T) || E;
						O(new Date(Date.UTC(e.getUTCFullYear(), e.getUTCMonth(), 1, 12))), ee($(e));
					}
				},
				children: [/* @__PURE__ */ t(R.Anchor, {
					asChild: !0,
					children: /* @__PURE__ */ n("div", {
						className: "c-date-picker__field",
						children: [/* @__PURE__ */ t("input", {
							ref: y,
							id: v,
							name: f,
							className: "c-text-input",
							value: T,
							placeholder: "YYYY-MM-DD",
							readOnly: !0,
							disabled: l,
							required: d,
							"aria-describedby": Z(v, m, h),
							"aria-invalid": !!h || void 0
						}), /* @__PURE__ */ t(R.Trigger, {
							asChild: !0,
							children: /* @__PURE__ */ t("button", {
								className: "c-date-picker__trigger",
								type: "button",
								disabled: l || u,
								"aria-label": `Open ${L} calendar`,
								children: /* @__PURE__ */ t(G, {
									name: "calendar",
									size: "small"
								})
							})
						})]
					})
				}), /* @__PURE__ */ t(R.Portal, { children: /* @__PURE__ */ t(H, {
					className: "c-overlay-root",
					children: /* @__PURE__ */ t(R.Content, {
						className: "c-popup c-calendar",
						sideOffset: 8,
						collisionPadding: 16,
						"aria-label": `${L} calendar`,
						onOpenAutoFocus: (e) => {
							e.preventDefault(), b.current[k]?.focus();
						},
						children: /* @__PURE__ */ n(K, {
							gap: 3,
							children: [/* @__PURE__ */ n(q, {
								className: "c-calendar__heading",
								children: [
									/* @__PURE__ */ t(Y, {
										iconOnly: !0,
										size: "compact",
										variant: "quiet",
										icon: "arrowLeft",
										"aria-label": "Previous month",
										disabled: !!a && $(new Date(Date.UTC(A, j, 0, 12))) < a,
										onClick: () => B(-1)
									}),
									/* @__PURE__ */ t(W, {
										variant: "h6",
										role: "status",
										children: D.toLocaleDateString("en", {
											month: "long",
											year: "numeric",
											timeZone: "UTC"
										})
									}),
									/* @__PURE__ */ t(Y, {
										iconOnly: !0,
										size: "compact",
										variant: "quiet",
										icon: "arrowRight",
										"aria-label": "Next month",
										disabled: !!o && $(new Date(Date.UTC(A, j + 1, 1, 12))) > o,
										onClick: () => B(1)
									})
								]
							}), /* @__PURE__ */ n("div", {
								className: "c-calendar__grid",
								role: "group",
								"aria-label": "Choose date",
								children: [
									[
										"Mo",
										"Tu",
										"We",
										"Th",
										"Fr",
										"Sa",
										"Su"
									].map((e) => /* @__PURE__ */ t(W, {
										as: "span",
										variant: "small",
										children: e
									}, e)),
									Array.from({ length: M }, (e, n) => /* @__PURE__ */ t("span", {}, `blank-${n}`)),
									Array.from({ length: te }, (e, n) => {
										let r = $(new Date(Date.UTC(A, j, n + 1, 12)));
										return /* @__PURE__ */ t(Y, {
											ref: (e) => {
												b.current[r] = e, e && r === k && document.activeElement?.closest(".c-calendar") && e.focus();
											},
											size: "compact",
											variant: r === T ? "primary" : "quiet",
											"aria-label": r,
											"aria-pressed": r === T,
											tabIndex: r === k ? 0 : -1,
											disabled: I(r),
											onKeyDown: (e) => V(e, r),
											onClick: () => z(r),
											children: n + 1
										}, r);
									})
								]
							})]
						})
					})
				}) })]
			}),
			/* @__PURE__ */ t(Q, {
				id: v,
				instructions: m,
				error: h
			})
		]
	});
}
//#endregion
//#region src/atomic/components/SpecialFields.tsx
function Ue({ label: e, ...r }) {
	let [i, a] = F(!1);
	return /* @__PURE__ */ n(K, {
		gap: 2,
		className: "c-password-field",
		children: [/* @__PURE__ */ t(he, {
			...r,
			label: e,
			type: i ? "text" : "password"
		}), /* @__PURE__ */ t(q, { children: /* @__PURE__ */ n(Y, {
			size: "compact",
			icon: "eye",
			"aria-pressed": i,
			disabled: r.disabled,
			onClick: () => a((e) => !e),
			children: [
				i ? "Hide" : "Show",
				" ",
				e
			]
		}) })]
	});
}
function We({ label: e, value: n, onChange: r, ...i }) {
	let a = !!n && !i.disabled;
	return /* @__PURE__ */ t(K, {
		gap: 2,
		className: "c-search-field",
		children: /* @__PURE__ */ t(he, {
			...i,
			type: "search",
			label: e,
			value: n,
			onChange: (e) => r(e.target.value),
			trailing: a ? /* @__PURE__ */ t(Y, {
				iconOnly: !0,
				size: "compact",
				variant: "quiet",
				icon: "close",
				"aria-label": `Clear ${e}`,
				onClick: () => r("")
			}) : /* @__PURE__ */ t(G, {
				name: "search",
				size: "small"
			})
		})
	});
}
//#endregion
//#region src/atomic/components/Loading.tsx
function Ge({ label: e }) {
	return /* @__PURE__ */ n(q, {
		gap: 2,
		className: "c-spinner",
		role: "status",
		"aria-label": e,
		children: [/* @__PURE__ */ t(G, { name: "loading" }), /* @__PURE__ */ t(W, {
			variant: "small",
			children: e
		})]
	});
}
function Ke({ label: e = "Loading", lines: n = 3 }) {
	return /* @__PURE__ */ t(K, {
		gap: 3,
		className: "c-skeleton",
		role: "status",
		"aria-label": e,
		children: Array.from({ length: Math.min(10, Math.max(1, Math.floor(n) || 1)) }, (e, n) => /* @__PURE__ */ t("span", { "aria-hidden": "true" }, n))
	});
}
function qe({ title: e, description: r, action: i }) {
	return /* @__PURE__ */ t(J, {
		padding: 8,
		className: "c-empty-state",
		children: /* @__PURE__ */ n(K, {
			gap: 3,
			children: [
				/* @__PURE__ */ t(G, {
					name: "folder",
					size: "large"
				}),
				/* @__PURE__ */ t(U, {
					level: 3,
					variant: "h5",
					children: e
				}),
				r && /* @__PURE__ */ t(W, {
					tone: "secondary",
					children: r
				}),
				i
			]
		})
	});
}
//#endregion
//#region src/atomic/components/Files.tsx
function Je({ label: e, onFiles: r, accept: i, multiple: a = !1, maxSize: o = 10485760, disabled: s, state: c = "idle", progress: l = 0, error: u, onRetry: d, size: f = "default" }) {
	let p = N(), [m, h] = F(""), [g, _] = F(!1), v = P(null), y = s || c === "uploading", b = u || m, x = (e) => {
		if (y) return;
		let t = e.find((e) => e.size > o || i && !i.split(",").some((t) => {
			let n = t.trim().toLowerCase();
			return n.startsWith(".") ? e.name.toLowerCase().endsWith(n) : n.endsWith("/*") ? e.type.startsWith(n.slice(0, -1)) : e.type === n;
		}));
		if (t) {
			h(`${t.name} exceeds the size limit or has an unsupported file type.`);
			return;
		}
		if (!a && e.length > 1) {
			h("Choose one file.");
			return;
		}
		h(""), e.length && r(e);
	};
	return /* @__PURE__ */ t(J, {
		padding: f === "small" ? 4 : 6,
		radius: "small",
		className: "c-file-dropzone",
		"data-size": f,
		"data-state": g ? "dragging" : c,
		"aria-disabled": y || void 0,
		onDragEnter: (e) => {
			e.preventDefault(), y || _(!0);
		},
		onDragLeave: (e) => {
			e.currentTarget.contains(e.relatedTarget) || _(!1);
		},
		onDragOver: (e) => e.preventDefault(),
		onDrop: (e) => {
			e.preventDefault(), _(!1), x(Array.from(e.dataTransfer.files));
		},
		children: /* @__PURE__ */ n(K, {
			gap: 3,
			children: [
				/* @__PURE__ */ t(G, { name: "upload" }),
				/* @__PURE__ */ t("label", {
					htmlFor: p,
					children: /* @__PURE__ */ t(W, {
						as: "span",
						variant: "h6",
						children: e
					})
				}),
				/* @__PURE__ */ n(W, {
					variant: "small",
					tone: "secondary",
					children: [
						"Choose ",
						a ? "files" : "a file",
						" or drop ",
						a ? "them" : "it",
						" here. Maximum ",
						Math.round(o / 1024 / 1024),
						" MB per file."
					]
				}),
				/* @__PURE__ */ t("input", {
					ref: v,
					className: "c-file-dropzone__input",
					tabIndex: -1,
					id: p,
					type: "file",
					accept: i,
					multiple: a,
					disabled: y,
					"aria-describedby": b ? `${p}-error` : void 0,
					onChange: (e) => {
						x(Array.from(e.target.files ?? [])), e.target.value = "";
					}
				}),
				/* @__PURE__ */ n(q, { children: [/* @__PURE__ */ t(Y, {
					icon: "upload",
					disabled: y,
					onClick: () => v.current?.click(),
					children: "Choose files"
				}), c === "error" && d && /* @__PURE__ */ t(Y, {
					onClick: d,
					disabled: y,
					children: "Retry upload"
				})] }),
				c === "uploading" && /* @__PURE__ */ t(je, {
					label: "Uploading files",
					value: l
				}),
				c === "success" && /* @__PURE__ */ t(W, {
					variant: "small",
					role: "status",
					children: "Files uploaded."
				}),
				b && /* @__PURE__ */ t(W, {
					id: `${p}-error`,
					tone: "inherit",
					className: "c-field-error",
					variant: "small",
					role: "alert",
					children: b
				})
			]
		})
	});
}
function Ye({ files: e, onRemove: r, disabled: i }) {
	return /* @__PURE__ */ t("ul", {
		className: "c-file-list",
		"aria-label": "Files",
		children: e.map((e) => /* @__PURE__ */ t("li", { children: /* @__PURE__ */ n(q, {
			gap: 3,
			children: [
				/* @__PURE__ */ t("span", {
					className: "c-file-list__icon",
					children: /* @__PURE__ */ t(G, { name: "file" })
				}),
				/* @__PURE__ */ n(K, {
					gap: 1,
					className: "c-file-list__copy",
					children: [/* @__PURE__ */ t(W, {
						variant: "h7",
						children: e.name
					}), e.size !== void 0 && /* @__PURE__ */ n(W, {
						variant: "small",
						tone: "secondary",
						children: [Math.ceil(e.size / 1024), " KB"]
					})]
				}),
				r && /* @__PURE__ */ t(Y, {
					iconOnly: !0,
					size: "compact",
					icon: "close",
					"aria-label": `Remove ${e.name}`,
					disabled: i,
					onClick: () => r(e.id)
				})
			]
		}) }, e.id))
	});
}
//#endregion
//#region src/atomic/components/WorkflowSteps.tsx
function Xe({ label: e, steps: r, current: i, onChange: a, orientation: o = "horizontal" }) {
	return /* @__PURE__ */ t("nav", {
		className: "c-workflow",
		"aria-label": e,
		"data-orientation": o,
		children: /* @__PURE__ */ t("ol", { children: r.map((e, r) => /* @__PURE__ */ t("li", { children: /* @__PURE__ */ n("button", {
			type: "button",
			className: "c-workflow__step",
			"aria-current": e.id === i ? "step" : void 0,
			disabled: e.disabled,
			onClick: () => a(e.id),
			children: [/* @__PURE__ */ t("span", {
				className: "c-workflow__circle",
				"data-complete": e.complete || void 0,
				children: e.complete ? /* @__PURE__ */ t(G, {
					name: "check",
					size: "small"
				}) : /* @__PURE__ */ t(W, {
					as: "span",
					variant: "h7",
					children: r + 1
				})
			}), /* @__PURE__ */ n("span", {
				className: "c-workflow__copy",
				children: [/* @__PURE__ */ t(W, {
					as: "span",
					variant: "h7",
					children: e.label
				}), e.description && /* @__PURE__ */ t(W, {
					as: "span",
					variant: "small",
					tone: "secondary",
					children: e.description
				})]
			})]
		}) }, e.id)) })
	});
}
//#endregion
//#region src/atomic/components/Table.tsx
function Ze({ label: e, rows: r, rowKey: i, columns: a, sort: o, onSort: s, emptyMessage: c = "No rows to display." }) {
	return /* @__PURE__ */ t(fe, {
		label: `${e} table`,
		maxHeight: "none",
		children: /* @__PURE__ */ n("table", {
			className: "c-table",
			"aria-label": e,
			children: [/* @__PURE__ */ t("thead", { children: /* @__PURE__ */ t("tr", { children: a.map((e) => /* @__PURE__ */ t("th", {
				scope: "col",
				"aria-sort": o?.column === e.id ? o.direction === "asc" ? "ascending" : "descending" : void 0,
				children: e.sortable && s ? /* @__PURE__ */ n("button", {
					type: "button",
					className: "c-table__sort",
					onClick: () => s({
						column: e.id,
						direction: o?.column === e.id && o.direction === "asc" ? "desc" : "asc"
					}),
					children: [/* @__PURE__ */ t(W, {
						as: "span",
						variant: "h7",
						children: e.header
					}), /* @__PURE__ */ t(G, {
						name: o?.column === e.id && o.direction === "asc" ? "arrowUp" : "arrowDown",
						size: "small"
					})]
				}) : /* @__PURE__ */ t(W, {
					as: "span",
					variant: "h7",
					children: e.header
				})
			}, e.id)) }) }), /* @__PURE__ */ n("tbody", { children: [r.map((e) => /* @__PURE__ */ t("tr", { children: a.map((n) => /* @__PURE__ */ t("td", { children: n.render(e) }, n.id)) }, i(e))), !r.length && /* @__PURE__ */ t("tr", { children: /* @__PURE__ */ t("td", {
				colSpan: a.length,
				children: c
			}) })] })]
		})
	});
}
//#endregion
//#region src/atomic/components/Toast.tsx
function Qe({ onDismiss: e, ...n }) {
	return /* @__PURE__ */ t(Ie, {
		...n,
		className: `c-toast ${n.className ?? ""}`,
		announce: !0,
		action: /* @__PURE__ */ t("button", {
			type: "button",
			className: "c-toast__dismiss",
			"aria-label": "Dismiss notification",
			onClick: e,
			children: /* @__PURE__ */ t(G, {
				name: "close",
				size: "small"
			})
		})
	});
}
//#endregion
//#region src/atomic/components/Overlays.tsx
function $e({ title: e, description: r, trigger: i, children: a, open: o, onOpenChange: s, drawer: c = !1, tone: l = "neutral" }) {
	let u = N();
	return /* @__PURE__ */ n(I.Root, {
		open: o,
		onOpenChange: s,
		children: [/* @__PURE__ */ t(I.Trigger, {
			asChild: !0,
			children: /* @__PURE__ */ t(Y, {
				className: c ? "c-drawer-trigger" : "c-dialog-trigger",
				children: i
			})
		}), /* @__PURE__ */ t(I.Portal, { children: /* @__PURE__ */ n(H, {
			className: "c-overlay-root",
			children: [/* @__PURE__ */ t(I.Overlay, { className: "c-backdrop" }), /* @__PURE__ */ t(I.Content, {
				className: c ? "c-modal c-drawer" : "c-modal",
				"aria-describedby": r ? u : void 0,
				children: /* @__PURE__ */ n(K, {
					gap: 4,
					children: [
						/* @__PURE__ */ n("div", {
							className: "c-modal__header",
							children: [/* @__PURE__ */ t(I.Title, {
								asChild: !0,
								children: /* @__PURE__ */ n(U, {
									level: 2,
									variant: "h4",
									children: [
										l !== "neutral" && /* @__PURE__ */ t(G, {
											name: l === "warning" ? "alert" : "check",
											size: "small"
										}),
										" ",
										e
									]
								})
							}), /* @__PURE__ */ t(I.Close, {
								asChild: !0,
								children: /* @__PURE__ */ t(Y, {
									iconOnly: !0,
									icon: "close",
									size: "compact",
									"aria-label": "Close dialog"
								})
							})]
						}),
						r && /* @__PURE__ */ t(I.Description, {
							asChild: !0,
							id: u,
							children: /* @__PURE__ */ t(W, {
								tone: "secondary",
								children: r
							})
						}),
						a
					]
				})
			})]
		}) })]
	});
}
function et(e) {
	return /* @__PURE__ */ t($e, { ...e });
}
function tt(e) {
	return /* @__PURE__ */ t($e, {
		...e,
		drawer: !0
	});
}
function nt({ label: e, children: r, open: i, onOpenChange: a, disabled: o, variant: s = "default" }) {
	return /* @__PURE__ */ n(R.Root, {
		open: i,
		onOpenChange: a,
		children: [/* @__PURE__ */ t(R.Trigger, {
			asChild: !0,
			children: s === "field" ? /* @__PURE__ */ n("button", {
				type: "button",
				className: "c-text-input c-select-trigger",
				disabled: o,
				children: [e, /* @__PURE__ */ t(G, {
					name: "chevronDown",
					size: "small"
				})]
			}) : /* @__PURE__ */ t(Y, {
				className: "c-popover-trigger",
				icon: "chevronDown",
				iconPosition: "end",
				disabled: o,
				children: e
			})
		}), /* @__PURE__ */ t(R.Portal, { children: /* @__PURE__ */ t(H, {
			className: "c-overlay-root",
			children: /* @__PURE__ */ t(R.Content, {
				className: s === "field" ? "c-popup c-dropdown-popup" : "c-popup",
				sideOffset: 8,
				collisionPadding: 16,
				"aria-label": e,
				children: r
			})
		}) })]
	});
}
var rt = {
	copy: "copy",
	duplicate: "copy",
	delete: "delete",
	download: "download",
	edit: "edit",
	settings: "settings"
};
function it({ label: e, items: r, onSelect: i, disabled: a, iconOnly: o, icon: s = "more", side: c = "bottom", className: l = "" }) {
	let u = `c-menu-trigger ${l}`.trim();
	return /* @__PURE__ */ n(L.Root, { children: [/* @__PURE__ */ t(L.Trigger, {
		asChild: !0,
		children: o ? /* @__PURE__ */ t(Y, {
			className: u,
			variant: "quiet",
			iconOnly: !0,
			"aria-label": e,
			icon: s,
			disabled: a
		}) : /* @__PURE__ */ t(Y, {
			className: u,
			icon: s,
			disabled: a,
			children: e
		})
	}), /* @__PURE__ */ t(L.Portal, { children: /* @__PURE__ */ t(H, {
		className: "c-overlay-root",
		children: /* @__PURE__ */ t(L.Content, {
			side: c,
			className: "c-popup c-menu",
			sideOffset: 8,
			collisionPadding: 16,
			"aria-label": e,
			children: r.map((e) => {
				let r = e.icon ?? rt[e.id];
				return /* @__PURE__ */ n(L.Item, {
					className: "c-menu__item",
					disabled: e.disabled,
					"data-danger": e.danger || void 0,
					onSelect: () => i(e.id),
					children: [r && /* @__PURE__ */ t(G, {
						name: r,
						size: "small"
					}), /* @__PURE__ */ t(W, {
						as: "span",
						variant: "small",
						tone: "inherit",
						children: e.label
					})]
				}, e.id);
			})
		})
	}) })] });
}
function at({ label: e, content: r }) {
	return /* @__PURE__ */ t(V.Provider, {
		delayDuration: 150,
		children: /* @__PURE__ */ n(V.Root, { children: [/* @__PURE__ */ t(V.Trigger, {
			asChild: !0,
			children: /* @__PURE__ */ t(Y, {
				className: "c-tooltip-trigger",
				icon: "info",
				size: "compact",
				children: e
			})
		}), /* @__PURE__ */ t(V.Portal, { children: /* @__PURE__ */ t(H, {
			className: "c-overlay-root",
			children: /* @__PURE__ */ t(V.Content, {
				className: "c-tooltip",
				sideOffset: 8,
				collisionPadding: 16,
				children: /* @__PURE__ */ t(W, {
					variant: "small",
					tone: "inherit",
					children: r
				})
			})
		}) })] })
	});
}
//#endregion
//#region src/atomic/components/Tabs.tsx
function ot(e) {
	let [r, i] = F("items" in e ? e.items.find((e) => !e.disabled)?.id : void 0);
	if (!("items" in e)) return /* @__PURE__ */ t(Ce, { ...e });
	let { label: a, items: o, size: s = "default", value: c, onChange: l, listOnly: u = !1, className: d = "" } = e, f = c ?? r, p = o.findIndex((e) => e.id === f);
	return /* @__PURE__ */ n(B.Root, {
		className: `c-tabs ${d}`.trim(),
		value: f,
		onValueChange: (e) => {
			i(e), l?.(e);
		},
		children: [/* @__PURE__ */ t("div", {
			className: "c-segmented-scroll",
			children: /* @__PURE__ */ n(B.List, {
				className: "c-segmented",
				"data-size": s,
				"aria-label": a,
				style: {
					"--segment-count": Math.max(1, o.length),
					"--segment-index": p
				},
				children: [p >= 0 && /* @__PURE__ */ t("span", {
					className: "c-segmented__indicator",
					"aria-hidden": "true"
				}), o.map((e) => /* @__PURE__ */ t(B.Trigger, {
					value: e.id,
					disabled: e.disabled,
					className: "c-segmented__option",
					children: /* @__PURE__ */ t(W, {
						as: "span",
						variant: "h6",
						tone: "inherit",
						children: e.label
					})
				}, e.id))]
			})
		}), !u && o.map((e) => /* @__PURE__ */ t(B.Content, {
			className: "c-tabs__content",
			value: e.id,
			children: e.content
		}, e.id))]
	});
}
//#endregion
//#region src/atomic/components/Combobox.tsx
function st({ label: e, value: r, onChange: i, options: a, disabled: o, name: s }) {
	let c = N(), [l, u] = F(!1), [d, f] = F(null), [p, m] = F(-1), h = a.filter((e) => e.label.toLowerCase().includes((d ?? "").toLowerCase())), g = (e) => {
		let t = h[e];
		!t || t.disabled || (i(t.value), f(null), u(!1), m(-1));
	};
	return /* @__PURE__ */ n(K, {
		gap: 2,
		className: "c-combobox",
		children: [
			/* @__PURE__ */ t(he, {
				label: e,
				role: "combobox",
				autoComplete: "off",
				"aria-expanded": l,
				"aria-autocomplete": "list",
				"aria-controls": l ? `${c}-list` : void 0,
				"aria-activedescendant": l && p >= 0 ? `${c}-${p}` : void 0,
				disabled: o,
				value: d ?? a.find((e) => e.value === r)?.label ?? "",
				onFocus: () => u(!0),
				onBlur: () => {
					u(!1), f(null), m(-1);
				},
				onChange: (e) => {
					f(e.target.value), m(-1), u(!0);
				},
				onKeyDown: (e) => {
					if (e.key === "Escape" && (e.preventDefault(), u(!1), f(null), m(-1)), e.key === "ArrowDown" || e.key === "ArrowUp") {
						e.preventDefault(), u(!0);
						let t = h.map((e, t) => e.disabled ? -1 : t).filter((e) => e >= 0), n = t.indexOf(p), r = n < 0 ? e.key === "ArrowDown" ? 0 : t.length - 1 : (n + (e.key === "ArrowDown" ? 1 : -1) + t.length) % t.length;
						m(t[r] ?? -1);
					}
					e.key === "Enter" && l && (e.preventDefault(), g(p));
				}
			}),
			/* @__PURE__ */ t(G, {
				name: "chevronDown",
				size: "small"
			}),
			s && /* @__PURE__ */ t("input", {
				type: "hidden",
				name: s,
				value: r,
				disabled: o
			}),
			l && /* @__PURE__ */ n("ul", {
				id: `${c}-list`,
				role: "listbox",
				"aria-label": e,
				className: "c-combobox__options c-dropdown-popup",
				children: [h.map((e, i) => /* @__PURE__ */ n("li", {
					id: `${c}-${i}`,
					className: "c-dropdown-option",
					role: "option",
					"aria-selected": e.value === r,
					"aria-disabled": e.disabled || void 0,
					"data-active": i === p || void 0,
					onMouseDown: (e) => e.preventDefault(),
					onClick: () => g(i),
					children: [/* @__PURE__ */ t(W, {
						as: "span",
						variant: "body",
						children: e.label
					}), e.value === r && /* @__PURE__ */ t(G, {
						name: "check",
						size: "small"
					})]
				}, e.value)), !h.length && /* @__PURE__ */ t("li", {
					role: "presentation",
					children: /* @__PURE__ */ t(W, {
						variant: "body",
						children: "No matches"
					})
				})]
			})
		]
	});
}
//#endregion
//#region src/atomic/components/MultiSelect.tsx
function ct({ label: e, value: r, onChange: i, options: a, disabled: o, name: s }) {
	return /* @__PURE__ */ n(K, {
		gap: 2,
		className: "c-multiselect",
		children: [
			/* @__PURE__ */ t(W, {
				variant: "h7",
				children: e
			}),
			/* @__PURE__ */ t(nt, {
				variant: "field",
				label: `${e} · ${r.length} selected`,
				disabled: o,
				children: /* @__PURE__ */ t(K, {
					gap: 2,
					children: a.map((e) => /* @__PURE__ */ t(ge, {
						label: e.label,
						checked: r.includes(e.value),
						disabled: o || e.disabled,
						onChange: (t) => i(t.target.checked ? [...r, e.value] : r.filter((t) => t !== e.value))
					}, e.value))
				})
			}),
			/* @__PURE__ */ t(q, { children: a.filter((e) => r.includes(e.value)).map((e) => {
				let n = !o && !e.disabled ? {
					children: e.label,
					removeLabel: `Remove ${e.label}`,
					onRemove: () => i(r.filter((t) => t !== e.value))
				} : { children: e.label };
				return /* @__PURE__ */ t(Se, {
					tone: "accent",
					...n
				}, e.value);
			}) }),
			s && r.map((e) => /* @__PURE__ */ t("input", {
				type: "hidden",
				name: s,
				value: e,
				disabled: o
			}, e))
		]
	});
}
//#endregion
//#region src/atomic/components/InlineConfirmation.tsx
function lt({ label: e, question: r, onConfirm: i, disabled: a, description: o }) {
	let [s, c] = F(!1), [l, u] = F(!1), [d, f] = F(""), p = P(null), m = P(null), h = P(!1);
	M(() => {
		s ? m.current?.focus() : h.current &&= (p.current?.focus(), !1);
	}, [s]);
	let g = () => {
		h.current = !0, c(!1), f("");
	};
	return /* @__PURE__ */ n(K, {
		gap: 2,
		className: "c-inline-confirmation",
		children: [/* @__PURE__ */ t(q, { children: /* @__PURE__ */ t(Y, {
			ref: p,
			onClick: () => c(!0),
			disabled: a || s,
			"aria-expanded": s,
			children: e
		}) }), s && /* @__PURE__ */ t(J, {
			tone: "canvas",
			radius: "small",
			padding: 4,
			children: /* @__PURE__ */ n(K, {
				gap: 2,
				role: "group",
				"aria-label": r,
				onKeyDown: (e) => {
					e.key === "Escape" && !l && (e.preventDefault(), g());
				},
				children: [
					/* @__PURE__ */ n(q, { children: [
						/* @__PURE__ */ t(W, {
							variant: "h6",
							children: r
						}),
						/* @__PURE__ */ t(Y, {
							ref: m,
							disabled: l,
							onClick: g,
							children: "Cancel"
						}),
						/* @__PURE__ */ t(Y, {
							variant: "danger",
							busy: l,
							onClick: async () => {
								u(!0), f("");
								try {
									await i(), g();
								} catch (e) {
									f(e instanceof Error ? e.message : "Action failed. Try again.");
								} finally {
									u(!1);
								}
							},
							children: "Confirm"
						})
					] }),
					o && /* @__PURE__ */ t(W, {
						variant: "small",
						tone: "secondary",
						children: o
					}),
					d && /* @__PURE__ */ t(W, {
						variant: "small",
						role: "alert",
						children: d
					})
				]
			})
		})]
	});
}
//#endregion
//#region src/atomic/components/NavigationList.tsx
function ut({ label: e, items: r }) {
	return /* @__PURE__ */ t("nav", {
		"aria-label": e,
		children: /* @__PURE__ */ t(K, {
			gap: 1,
			children: r.map((e) => {
				let r = e.status === "Missing component", i = e.status && !r ? /* @__PURE__ */ t(W, {
					as: "span",
					variant: "small",
					tone: "secondary",
					"aria-hidden": "true",
					children: e.status
				}) : null;
				return /* @__PURE__ */ n("div", {
					className: `c-navigation-row${e.status ? " c-navigation-row--missing" : ""}${r ? " c-navigation-row--unavailable" : ""}`,
					children: [e.href ? /* @__PURE__ */ n("a", {
						href: e.href,
						"aria-label": e.label,
						"aria-current": e.current ? "page" : void 0,
						onClick: e.onClick,
						title: e.label,
						children: [
							e.icon && /* @__PURE__ */ t(G, {
								name: e.icon,
								size: "small"
							}),
							/* @__PURE__ */ t(W, {
								as: "span",
								variant: "small",
								tone: "inherit",
								children: e.label
							}),
							i
						]
					}) : /* @__PURE__ */ n("div", {
						className: "c-navigation-row__static",
						"aria-label": e.label,
						title: e.label,
						children: [
							e.icon && /* @__PURE__ */ t(G, {
								name: e.icon,
								size: "small"
							}),
							/* @__PURE__ */ t(W, {
								as: "span",
								variant: "small",
								tone: "inherit",
								children: e.label
							}),
							i
						]
					}), e.trailing]
				}, e.id);
			})
		})
	});
}
//#endregion
//#region src/atomic/components/AttachmentArea.tsx
function dt({ label: r, children: i, actions: a, onFiles: o, disabled: s, accept: c = ".txt,.md,.pdf,.docx", maxSize: l = 10485760 }) {
	let u = N(), d = P(null), [f, p] = F(!1), [m, h] = F("");
	function g(e) {
		if (s || !o) return;
		let t = e.find((e) => e.size > l || !c.split(",").some((t) => {
			let n = t.trim().toLowerCase();
			return n.startsWith(".") ? e.name.toLowerCase().endsWith(n) : n.endsWith("/*") ? e.type.startsWith(n.slice(0, -1)) : e.type === n;
		}));
		if (t) {
			h(t.name + " is too large or has an unsupported file type.");
			return;
		}
		h(""), e.length && o(e);
	}
	return /* @__PURE__ */ t(J, {
		padding: 4,
		role: "group",
		"aria-label": r,
		className: "c-attachment-area",
		"data-dragging": f || void 0,
		onDragOver: (e) => {
			e.preventDefault(), o && !s && p(!0);
		},
		onDragLeave: (e) => {
			e.currentTarget.contains(e.relatedTarget) || p(!1);
		},
		onDrop: (e) => {
			e.preventDefault(), p(!1), g(Array.from(e.dataTransfer.files));
		},
		children: /* @__PURE__ */ n(K, {
			gap: 3,
			children: [
				/* @__PURE__ */ t("div", {
					className: "c-attachment-area__content",
					children: i
				}),
				/* @__PURE__ */ n(q, {
					className: "c-attachment-area__toolbar",
					children: [o && /* @__PURE__ */ n(e, { children: [/* @__PURE__ */ t("input", {
						ref: d,
						id: u,
						className: "c-attachment-area__picker",
						"aria-label": "Attach files",
						type: "file",
						multiple: !0,
						accept: c,
						disabled: s,
						tabIndex: -1,
						onChange: (e) => {
							g(Array.from(e.target.files ?? [])), e.target.value = "";
						}
					}), /* @__PURE__ */ t(Y, {
						iconOnly: !0,
						variant: "quiet",
						icon: "Paperclip",
						"aria-label": "Attach files",
						disabled: s,
						onClick: () => d.current?.click()
					})] }), /* @__PURE__ */ t(q, {
						className: "c-attachment-area__actions",
						children: a
					})]
				}),
				m && /* @__PURE__ */ t(W, {
					role: "alert",
					className: "c-field-error",
					tone: "inherit",
					variant: "small",
					children: m
				})
			]
		})
	});
}
//#endregion
//#region src/atomic/components/ReferenceComponents.tsx
function ft({ children: e, attached: n = !0, className: r = "", ...i }) {
	return /* @__PURE__ */ t("div", {
		...i,
		className: `c-button-group${n ? " c-button-group--attached" : ""} ${r}`.trim(),
		role: "group",
		children: e
	});
}
function pt(e) {
	return /* @__PURE__ */ t(Y, {
		...e,
		size: "compact"
	});
}
function mt({ children: e, subtitle: r, className: i = "", ...a }) {
	return /* @__PURE__ */ t(Y, {
		...a,
		className: `c-fancy-button ${i}`.trim(),
		children: /* @__PURE__ */ n("span", {
			className: "c-fancy-button__copy",
			children: [/* @__PURE__ */ t(W, {
				as: "span",
				variant: "h6",
				tone: "inherit",
				children: e
			}), r && /* @__PURE__ */ t(W, {
				as: "span",
				variant: "small",
				tone: "inherit",
				children: r
			})]
		})
	});
}
function ht({ name: e, src: r, size: i = "medium", status: a, className: o = "", ...s }) {
	let c = e.split(/\s+/).map((e) => e[0]).join("").slice(0, 2).toUpperCase();
	return /* @__PURE__ */ n("span", {
		...s,
		className: `c-avatar ${o}`.trim(),
		"data-size": i,
		"data-status": a,
		role: "img",
		"aria-label": e,
		children: [r ? /* @__PURE__ */ t("img", {
			src: r,
			alt: ""
		}) : /* @__PURE__ */ t(W, {
			as: "span",
			variant: "h6",
			tone: "inherit",
			style: i === "small" ? { fontSize: 12 } : void 0,
			children: c
		}), a && /* @__PURE__ */ t("span", {
			className: "c-avatar__status",
			"aria-label": a
		})]
	});
}
function gt({ label: e, items: r, max: i = 5, size: a = "medium" }) {
	let o = r.slice(0, i), s = r.length - o.length;
	return /* @__PURE__ */ n("div", {
		className: "c-avatar-group",
		"data-size": a,
		role: "group",
		"aria-label": e,
		children: [o.map((e) => /* @__PURE__ */ t(ht, {
			...e,
			size: a
		}, e.name)), s > 0 && /* @__PURE__ */ n("span", {
			className: "c-avatar c-avatar--more",
			"data-size": a,
			children: ["+", s]
		})]
	});
}
function _t(e) {
	return /* @__PURE__ */ t(gt, {
		...e,
		size: "small"
	});
}
function vt({ children: e, tone: r = "neutral", icon: i, className: a = "", ...o }) {
	return /* @__PURE__ */ n("span", {
		...o,
		className: `c-badge ${a}`.trim(),
		"data-tone": r,
		children: [i && /* @__PURE__ */ t(G, {
			name: i,
			size: "small"
		}), /* @__PURE__ */ t(W, {
			as: "span",
			variant: "h7",
			tone: "inherit",
			children: e
		})]
	});
}
function yt({ title: e, description: r, tone: i = "neutral", action: a, onDismiss: o, className: s = "", ...c }) {
	return /* @__PURE__ */ n("aside", {
		...c,
		className: `c-banner ${s}`.trim(),
		"data-tone": i,
		role: "status",
		children: [
			/* @__PURE__ */ t(G, { name: i === "danger" || i === "warning" ? "alert" : i === "success" ? "check" : "info" }),
			/* @__PURE__ */ n(K, {
				gap: 1,
				className: "c-banner__copy",
				children: [/* @__PURE__ */ t(W, {
					as: "span",
					variant: "h6",
					tone: "inherit",
					children: e
				}), r && /* @__PURE__ */ t(W, {
					variant: "small",
					tone: "inherit",
					children: r
				})]
			}),
			a,
			o && /* @__PURE__ */ t("button", {
				type: "button",
				className: "c-banner__dismiss",
				"aria-label": "Dismiss",
				onClick: o,
				children: /* @__PURE__ */ t(G, {
					name: "close",
					size: "small"
				})
			})
		]
	});
}
function bt({ children: e, className: n = "", ...r }) {
	return /* @__PURE__ */ t("kbd", {
		...r,
		className: `c-kbd ${n}`.trim(),
		children: e
	});
}
function xt({ actions: e, action: n, className: r = "", ...i }) {
	return /* @__PURE__ */ t(yt, {
		...i,
		className: `c-notification ${r}`.trim(),
		action: e ?? n
	});
}
function St({ label: e, value: r = "#72b8ff", onChange: i, presets: a = [
	"#72b8ff",
	"#23a094",
	"#dc341e",
	"#000000",
	"#ffffff"
] }) {
	let o = N(), [s, c] = F(r), [l, u] = F(r);
	M(() => {
		c(r), u(r);
	}, [r]);
	let d = (e) => {
		let t = e.trim().toLowerCase();
		return /^#[0-9a-f]{6}$/i.test(t) ? t === s ? (u(t), !0) : (c(t), u(t), i?.(t), !0) : !1;
	}, f = () => {
		d(l) || u(s);
	};
	return /* @__PURE__ */ n("div", {
		className: "c-color-picker",
		children: [
			/* @__PURE__ */ n("div", {
				className: "c-color-picker__heading",
				children: [
					/* @__PURE__ */ t(W, {
						as: "span",
						variant: "small",
						className: "c-color-picker__label",
						children: e
					}),
					/* @__PURE__ */ t("span", {
						className: "c-color-picker__current-swatch",
						style: { background: s },
						"aria-hidden": "true"
					}),
					/* @__PURE__ */ t("code", { children: s })
				]
			}),
			/* @__PURE__ */ n("div", {
				className: "c-color-picker__row",
				children: [/* @__PURE__ */ t("input", {
					id: `${o}-native`,
					className: "c-color-picker__native",
					"aria-label": e,
					type: "color",
					value: s,
					onChange: (e) => d(e.target.value)
				}), /* @__PURE__ */ n("label", {
					className: "c-color-picker__hex-label",
					htmlFor: `${o}-hex`,
					children: [/* @__PURE__ */ t(W, {
						as: "span",
						variant: "small",
						tone: "secondary",
						children: "Hex value"
					}), /* @__PURE__ */ t("input", {
						id: `${o}-hex`,
						"aria-label": `${e} hex value`,
						"aria-invalid": l !== s && !/^#[0-9a-f]{6}$/i.test(l),
						className: "c-color-picker__hex",
						type: "text",
						inputMode: "text",
						spellCheck: !1,
						value: l,
						onChange: (e) => u(e.target.value),
						onBlur: f,
						onKeyDown: (e) => {
							e.key === "Enter" && (e.preventDefault(), f());
						}
					})]
				})]
			}),
			/* @__PURE__ */ t("div", {
				className: "c-color-picker__presets",
				role: "group",
				"aria-label": `${e} presets`,
				children: a.map((e) => /* @__PURE__ */ t("button", {
					type: "button",
					"aria-label": `Use ${e}`,
					"aria-pressed": s.toLowerCase() === e.toLowerCase(),
					title: e,
					style: { background: e },
					onClick: () => d(e)
				}, e))
			})
		]
	});
}
function Ct({ label: e, length: r = 4, value: i = "", onChange: a, disabled: o, error: s }) {
	let c = N(), l = Array.from({ length: r }, (e, t) => i[t] ?? "");
	return /* @__PURE__ */ n("fieldset", {
		className: "c-digit-input",
		disabled: o,
		children: [
			/* @__PURE__ */ t("legend", { children: /* @__PURE__ */ t(W, {
				as: "span",
				variant: "small",
				children: e
			}) }),
			/* @__PURE__ */ t("div", {
				className: "c-digit-input__row",
				children: l.map((n, r) => /* @__PURE__ */ t("input", {
					"aria-label": `${e} ${r + 1}`,
					inputMode: "numeric",
					maxLength: 1,
					value: n,
					onChange: (e) => {
						let t = l.slice();
						t[r] = e.target.value.replace(/\D/g, ""), a?.(t.join(""));
					}
				}, `${c}-${r}`))
			}),
			s && /* @__PURE__ */ t(W, {
				variant: "small",
				className: "c-field-support--error",
				children: s
			})
		]
	});
}
function wt({ children: e, tone: n = "secondary", className: r = "", ...i }) {
	return /* @__PURE__ */ t(W, {
		...i,
		variant: "small",
		tone: n === "danger" ? "ink" : "secondary",
		className: `c-hint${n === "danger" ? " c-hint--error" : ""} ${r}`.trim(),
		children: e
	});
}
function Tt({ children: e, required: r, hint: i, className: a = "", ...o }) {
	return /* @__PURE__ */ n("label", {
		...o,
		className: `c-label ${a}`.trim(),
		children: [/* @__PURE__ */ n(W, {
			as: "span",
			variant: "small",
			tone: "inherit",
			children: [e, r && /* @__PURE__ */ t("span", {
				"aria-hidden": "true",
				children: " *"
			})]
		}), i && /* @__PURE__ */ t(W, {
			as: "span",
			variant: "small",
			tone: "secondary",
			children: i
		})]
	});
}
function Et({ label: e, items: r, multiple: i = !1, className: a = "" }) {
	return /* @__PURE__ */ t("section", {
		className: `c-accordion ${a}`.trim(),
		"aria-label": e,
		children: r.map((r) => /* @__PURE__ */ n("details", {
			open: r.defaultOpen,
			className: "c-accordion__item",
			name: i ? void 0 : e,
			children: [/* @__PURE__ */ n("summary", { children: [/* @__PURE__ */ t(W, {
				as: "span",
				variant: "h6",
				children: r.title
			}), /* @__PURE__ */ t(G, {
				name: "chevronDown",
				size: "small"
			})] }), /* @__PURE__ */ t("div", {
				className: "c-accordion__content",
				children: /* @__PURE__ */ t("div", {
					className: "c-accordion__content-inner",
					children: r.content
				})
			})]
		}, r.id))
	});
}
function Dt({ label: e, items: r, value: i, onChange: a }) {
	let [o, s] = F(r[0]?.id ?? ""), c = i ?? o;
	return /* @__PURE__ */ n("div", {
		className: "c-tab-menu-vertical",
		children: [/* @__PURE__ */ t("nav", {
			"aria-label": e,
			children: r.map((e) => /* @__PURE__ */ t("button", {
				type: "button",
				"aria-current": c === e.id ? "page" : void 0,
				onClick: () => {
					s(e.id), a?.(e.id);
				},
				children: e.label
			}, e.id))
		}), /* @__PURE__ */ t("div", {
			className: "c-tab-menu-vertical__content",
			children: r.find((e) => e.id === c)?.content
		})]
	});
}
function Ot({ label: e, steps: n, current: r = 0, onChange: i }) {
	return /* @__PURE__ */ t("nav", {
		className: "c-dot-stepper",
		"aria-label": e,
		children: n.map((e, n) => /* @__PURE__ */ t("button", {
			type: "button",
			"aria-label": e,
			"aria-current": n === r ? "step" : void 0,
			"data-complete": n < r || void 0,
			onClick: () => i?.(n),
			children: /* @__PURE__ */ t("span", {})
		}, e))
	});
}
function kt({ label: e, steps: r, current: i, onChange: a }) {
	return /* @__PURE__ */ t("nav", {
		className: "c-vertical-stepper",
		"aria-label": e,
		children: /* @__PURE__ */ t("ol", { children: r.map((e, r) => /* @__PURE__ */ t("li", {
			"data-current": e.id === i || void 0,
			"data-complete": e.complete || void 0,
			children: /* @__PURE__ */ n("button", {
				type: "button",
				onClick: () => a?.(e.id),
				children: [/* @__PURE__ */ t("span", {
					className: "c-vertical-stepper__marker",
					children: e.complete ? /* @__PURE__ */ t(G, {
						name: "check",
						size: "small"
					}) : r + 1
				}), /* @__PURE__ */ n(K, {
					gap: 1,
					children: [/* @__PURE__ */ t(W, {
						as: "span",
						variant: "h6",
						children: e.label
					}), e.description && /* @__PURE__ */ t(W, {
						as: "span",
						variant: "small",
						tone: "secondary",
						children: e.description
					})]
				})]
			})
		}, e.id)) })
	});
}
function At({ label: e, items: r, onSelect: i, placeholder: a = "Search commands" }) {
	let [o, s] = F(!1), [c, l] = F(""), u = r.filter((e) => e.label.toLowerCase().includes(c.toLowerCase()));
	return /* @__PURE__ */ n("div", {
		className: "c-command-menu",
		children: [/* @__PURE__ */ t(Y, {
			icon: "search",
			onClick: () => s(!0),
			children: e
		}), o && /* @__PURE__ */ t("div", {
			className: "c-command-menu__backdrop",
			role: "presentation",
			onClick: () => s(!1),
			children: /* @__PURE__ */ n("div", {
				className: "c-command-menu__dialog",
				role: "dialog",
				"aria-label": e,
				onClick: (e) => e.stopPropagation(),
				children: [
					/* @__PURE__ */ t("input", {
						autoFocus: !0,
						"aria-label": a,
						placeholder: a,
						value: c,
						onChange: (e) => l(e.target.value)
					}),
					u.map((e) => /* @__PURE__ */ n("button", {
						type: "button",
						disabled: e.disabled,
						onClick: () => {
							i(e.id), s(!1);
						},
						children: [/* @__PURE__ */ t(W, {
							as: "span",
							variant: "small",
							children: e.label
						}), /* @__PURE__ */ t(bt, { children: "↵" })]
					}, e.id)),
					/* @__PURE__ */ t(W, {
						variant: "small",
						tone: "secondary",
						children: "Esc to close"
					})
				]
			})
		})]
	});
}
//#endregion
//#region src/atomic/ui-blocks/SidebarPanel.tsx
function jt({ brand: r, primaryAction: i, navigation: a, projects: o, account: s, onProjectAction: c }) {
	let [l, u] = F(!1), [d, f] = F(""), p = P(null), m = P(!1);
	M(() => {
		!l && m.current && (p.current?.focus(), m.current = !1);
	}, [l]);
	let h = o.filter((e) => e.title.toLowerCase().includes(d.trim().toLowerCase())), g = (e) => e.map((e) => ({
		id: e.id,
		label: e.title,
		href: e.href,
		current: e.current,
		trailing: e.actions?.length ? /* @__PURE__ */ t(it, {
			label: "Actions for " + e.title,
			iconOnly: !0,
			items: e.actions,
			onSelect: (t) => c?.(e.id, t)
		}) : void 0
	}));
	return /* @__PURE__ */ n(J, {
		as: "aside",
		tone: "canvas",
		radius: "none",
		padding: 4,
		className: "b-sidebar",
		"aria-label": "Sidebar",
		children: [/* @__PURE__ */ n(K, {
			gap: 6,
			children: [
				l ? /* @__PURE__ */ t(We, {
					label: "Search projects",
					autoFocus: !0,
					value: d,
					onChange: f,
					onKeyDown: (e) => {
						e.key === "Escape" && (e.preventDefault(), m.current = !0, f(""), u(!1));
					}
				}) : /* @__PURE__ */ n(q, {
					className: "b-sidebar__header",
					children: [/* @__PURE__ */ t(U, {
						level: 2,
						variant: "h4",
						children: r.label
					}), /* @__PURE__ */ t(Y, {
						ref: p,
						iconOnly: !0,
						size: "compact",
						icon: "search",
						"aria-label": "Search projects",
						onClick: () => u(!0)
					})]
				}),
				!l && /* @__PURE__ */ n(e, { children: [/* @__PURE__ */ t(Y, {
					variant: "primary",
					icon: i.icon ?? "plus",
					onClick: i.onClick,
					children: i.label
				}), /* @__PURE__ */ t(ut, {
					label: "Workspace navigation",
					items: a
				})] }),
				/* @__PURE__ */ t(fe, {
					label: "Projects",
					maxHeight: "28rem",
					children: /* @__PURE__ */ n(K, {
						gap: 6,
						children: [["Pinned", "Recent projects"].map((e) => {
							let r = h.filter((t) => e === "Pinned" ? t.pinned : !t.pinned);
							return r.length ? /* @__PURE__ */ n(K, {
								gap: 2,
								children: [/* @__PURE__ */ t(U, {
									level: 3,
									variant: "h7",
									children: e
								}), /* @__PURE__ */ t(ut, {
									label: e,
									items: g(r)
								})]
							}, e) : null;
						}), !h.length && /* @__PURE__ */ t(W, {
							variant: "small",
							tone: "secondary",
							children: d ? "No matching projects." : "No projects yet."
						})]
					})
				})
			]
		}), s && /* @__PURE__ */ t(K, {
			gap: 2,
			className: "b-sidebar__account",
			children: /* @__PURE__ */ t(it, {
				label: s.label,
				icon: "UserRound",
				side: "top",
				items: s.actions,
				onSelect: s.onAction
			})
		})]
	});
}
//#endregion
//#region src/atomic/ui-blocks/PromptInput.tsx
function Mt({ value: e, onChange: r, onSubmit: i, files: a = [], onAttach: o, onRemove: s, disabled: c, readOnly: l, busy: u, error: d, label: f = "Prompt", placeholder: p = "Describe what you want to create…", accept: m }) {
	let h = c || l || u, g = !!e.trim() && !h, _ = () => {
		g && i();
	};
	return /* @__PURE__ */ n(ze, {
		label: "AI prompt input",
		"aria-busy": u || void 0,
		onSubmit: (e) => {
			e.preventDefault(), _();
		},
		children: [/* @__PURE__ */ n(dt, {
			label: "Prompt attachments",
			onFiles: l ? void 0 : o,
			disabled: h,
			accept: m,
			actions: !l && /* @__PURE__ */ t(Y, {
				type: "submit",
				variant: "primary",
				icon: "arrowUp",
				iconOnly: !0,
				"aria-label": "Send prompt",
				busy: u,
				disabled: !g
			}),
			children: [!!a.length && /* @__PURE__ */ t(q, { children: a.map((e) => s && !h ? /* @__PURE__ */ t(Se, {
				icon: "Paperclip",
				onRemove: () => s(e.id),
				removeLabel: "Remove " + e.name,
				children: e.name
			}, e.id) : /* @__PURE__ */ t(Se, {
				icon: "Paperclip",
				children: e.name
			}, e.id)) }), /* @__PURE__ */ t(be, {
				label: f,
				hideLabel: !0,
				embedded: !0,
				rows: 5,
				value: e,
				placeholder: p,
				disabled: c || u,
				readOnly: l,
				onChange: (e) => r(e.target.value),
				onKeyDown: (e) => {
					e.key === "Enter" && (e.ctrlKey || e.metaKey) && !e.nativeEvent.isComposing && (e.preventDefault(), _());
				}
			})]
		}), d && /* @__PURE__ */ t(Ie, {
			tone: "danger",
			title: "Could not send prompt",
			description: d
		})]
	});
}
//#endregion
//#region src/atomic/ui-blocks/CodeExample.tsx
var Nt = /(\/\/[^\n]*|\/\*[\s\S]*?\*\/|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|`(?:\\.|[^`\\])*`|<\/?[A-Za-z][^>]*>|\b(?:import|from|export|default|function|return|const|let|var|new|true|false|null|undefined|if|else|async|await|type|interface|as|class)\b|\b\d+(?:\.\d+)?\b)/g, Pt = /* @__PURE__ */ new Set([
	"import",
	"from",
	"export",
	"default",
	"function",
	"return",
	"const",
	"let",
	"var",
	"new",
	"true",
	"false",
	"null",
	"undefined",
	"if",
	"else",
	"async",
	"await",
	"type",
	"interface",
	"as",
	"class"
]);
function Ft(e) {
	return e.split(Nt).map((e, n) => {
		if (!e) return null;
		let r = e.startsWith("//") || e.startsWith("/*") ? "comment" : e.startsWith("<") ? "tag" : /^['"`]/.test(e) ? "string" : /^\d/.test(e) ? "number" : Pt.has(e) ? "keyword" : void 0;
		return r ? /* @__PURE__ */ t("span", {
			className: `b-code-example__token b-code-example__token--${r}`,
			children: e
		}, `${e}-${n}`) : e;
	});
}
function It({ title: e, description: r, filename: i, source: a, preview: o, controls: s, copyable: c = !0, headingLevel: l = 2, className: u = "" }) {
	let [d, f] = F("preview"), [p, m] = F("");
	M(() => {
		m("");
	}, [a]);
	async function h() {
		await navigator.clipboard.writeText(a);
	}
	function g() {
		f("code"), m("Clipboard unavailable. Select the code and copy it manually.");
	}
	let _ = /* @__PURE__ */ n(K, {
		gap: 2,
		children: [/* @__PURE__ */ t(W, {
			variant: "small",
			tone: "secondary",
			children: i
		}), /* @__PURE__ */ t(fe, {
			label: `${e} source`,
			maxHeight: "none",
			children: /* @__PURE__ */ t("pre", {
				className: "b-code-example__source",
				children: /* @__PURE__ */ t("code", { children: Ft(a) })
			})
		})]
	}), v = o == null ? null : /* @__PURE__ */ t(ot, {
		listOnly: !0,
		size: "compact",
		className: "b-code-example__view-tabs",
		label: `${e} view`,
		value: d,
		onChange: f,
		items: [{
			id: "preview",
			label: "Preview",
			content: null
		}, {
			id: "code",
			label: "Code",
			content: null
		}]
	}), y = c ? /* @__PURE__ */ t(pe, {
		size: "compact",
		className: "b-code-example__copy",
		icon: "copy",
		successIcon: "check",
		label: "Copy",
		successLabel: "Copied",
		"aria-label": `Copy ${e} code`,
		successAriaLabel: `Copied ${e} code`,
		onAction: h,
		onError: g,
		resetKey: a
	}) : null, b = v || s || y ? /* @__PURE__ */ n(q, {
		className: "b-code-example__header-controls",
		gap: 2,
		children: [
			v,
			s,
			y
		]
	}) : null, x = o == null ? _ : /* @__PURE__ */ t("div", {
		role: "tabpanel",
		"aria-label": `${e} ${d}`,
		className: "b-code-example__content",
		children: d === "preview" ? /* @__PURE__ */ t("div", {
			className: "b-code-example__preview",
			children: o
		}) : _
	});
	return /* @__PURE__ */ n(me, {
		title: e,
		description: r,
		headingLevel: l,
		variant: "split",
		density: "compact",
		className: `b-code-example ${u}`.trim(),
		filters: b,
		children: [x, p && /* @__PURE__ */ t(W, {
			role: "status",
			variant: "small",
			children: p
		})]
	});
}
//#endregion
export { Et as Accordion, Ie as Alert, H as AtomsRoot, dt as AttachmentArea, ht as Avatar, gt as AvatarGroup, _t as AvatarGroupCompact, vt as Badge, yt as Banner, we as Breadcrumbs, Y as Button, ft as ButtonGroup, ge as Checkbox, It as CodeExample, St as ColorPicker, st as Combobox, At as CommandMenu, pt as CompactButton, ue as Container, He as DatePicker, et as Dialog, Ct as DigitInput, de as Divider, Ot as DotStepper, tt as Drawer, qe as EmptyState, mt as FancyButton, pe as FeedbackButton, Je as FileDropzone, Ye as FileList, ze as Form, Be as FormActions, le as Grid, U as Heading, wt as Hint, G as Icon, q as Inline, lt as InlineConfirmation, Le as InlineText, bt as Kbd, Tt as Label, it as Menu, ct as MultiSelect, ut as NavigationList, xt as Notification, Ee as NumberStepper, Te as Pagination, me as Panel, Ue as PasswordField, nt as Popover, je as ProgressBar, Me as ProgressRing, Mt as PromptInput, _e as RadioGroup, Oe as RangeSlider, ke as Rating, fe as ScrollArea, We as SearchField, Ce as SegmentedControl, xe as Select, jt as SidebarPanel, Ke as Skeleton, De as Slider, Ge as Spinner, K as Stack, Pe as StatusBadge, J as Surface, Dt as TabMenuVertical, Ze as Table, ot as Tabs, Se as Tag, W as Text, Re as TextAction, be as TextArea, he as TextField, Qe as Toast, ve as Toggle, at as Tooltip, kt as VerticalStepper, Xe as WorkflowSteps, se as icons, ae as tokenVariables, re as tokens, ie as typography };
