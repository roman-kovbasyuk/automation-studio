export type SkeletonProps = {
    lines?: number;
    className?: string;
};
/** Decorative loading placeholders. Pair with nearby loading text when needed. */
export declare function Skeleton({ lines, className }: SkeletonProps): import("react").JSX.Element;
