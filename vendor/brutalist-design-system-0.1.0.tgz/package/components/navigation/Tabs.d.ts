import type { ReactNode } from 'react';
export type TabItem = {
    value: string;
    label: string;
    disabled?: boolean;
};
export type TabsProps = {
    items: TabItem[];
    value: string;
    onValueChange: (value: string) => void;
    ariaLabel: string;
    idPrefix?: string;
    className?: string;
};
/** Typed adapter for the established PillTabs control. */
export declare function Tabs({ items, value, onValueChange, ariaLabel, idPrefix, className }: TabsProps): import("react").JSX.Element | null;
export type TabPanelProps = {
    value: string;
    activeValue: string;
    idPrefix?: string;
    children: ReactNode;
    className?: string;
};
export declare function TabPanel({ value, activeValue, idPrefix, children, className }: TabPanelProps): import("react").JSX.Element;
