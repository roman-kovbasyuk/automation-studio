import type { ReactElement, ReactNode } from 'react';
type OpenState = {
    open: boolean;
    onOpenChange: (open: boolean) => void;
};
type Trigger = string | ReactElement;
export type DialogProps = OpenState & {
    title: ReactNode;
    description?: ReactNode;
    trigger?: Trigger;
    children: ReactNode;
    closeLabel?: string;
};
/** A controlled modal dialog with focus management supplied by Radix. */
export declare function Dialog({ open, onOpenChange, title, description, trigger, children, closeLabel }: DialogProps): import("react").JSX.Element;
export type DrawerProps = DialogProps & {
    side?: 'left' | 'right' | 'top' | 'bottom';
};
/** A controlled modal drawer. Its direction is presentational; its state stays with the consumer. */
export declare function Drawer({ side, open, onOpenChange, title, description, trigger, children, closeLabel }: DrawerProps): import("react").JSX.Element;
export type PopoverProps = OpenState & {
    trigger: Trigger;
    children: ReactNode;
    side?: 'top' | 'right' | 'bottom' | 'left';
    align?: 'start' | 'center' | 'end';
};
/** A controlled, non-modal surface for contextual controls. */
export declare function Popover({ open, onOpenChange, trigger, children, side, align }: PopoverProps): import("react").JSX.Element;
export type TooltipProps = {
    content: ReactNode;
    children: ReactElement;
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
    side?: 'top' | 'right' | 'bottom' | 'left';
    delayDuration?: number;
};
/** A concise label for a control whose purpose is not visible from its name alone. */
export declare function Tooltip({ content, children, open, onOpenChange, side, delayDuration }: TooltipProps): import("react").JSX.Element;
export type MenuItem = {
    id: string;
    label: ReactNode;
    disabled?: boolean;
    danger?: boolean;
};
export type MenuProps = OpenState & {
    trigger: Trigger;
    items: MenuItem[];
    onSelect: (id: string) => void;
    ariaLabel?: string;
};
/** A controlled menu for an explicit, short list of actions. */
export declare function Menu({ open, onOpenChange, trigger, items, onSelect, ariaLabel }: MenuProps): import("react").JSX.Element;
export {};
