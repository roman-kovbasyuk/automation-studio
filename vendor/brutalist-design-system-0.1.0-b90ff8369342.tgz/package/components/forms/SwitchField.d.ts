import type { InputHTMLAttributes, ReactNode } from 'react';
export type SwitchFieldProps = Omit<InputHTMLAttributes<HTMLInputElement>, 'id' | 'type' | 'role' | 'aria-describedby' | 'aria-invalid' | 'onChange'> & {
    id?: string;
    label: ReactNode;
    instructions?: ReactNode;
    error?: ReactNode;
    onCheckedChange?: (checked: boolean) => void;
};
/** A native checkbox exposed as a switch, with a full-size visible label. */
export declare function SwitchField({ id: providedId, label, instructions, error, onCheckedChange, className, ...props }: SwitchFieldProps): import("react").JSX.Element;
