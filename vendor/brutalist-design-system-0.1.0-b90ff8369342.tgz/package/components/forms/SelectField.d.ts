import type { ReactNode, SelectHTMLAttributes } from 'react';
export type SelectOption = {
    value: string;
    label: ReactNode;
    disabled?: boolean;
};
export type SelectFieldProps = Omit<SelectHTMLAttributes<HTMLSelectElement>, 'id' | 'aria-describedby' | 'aria-invalid' | 'children'> & {
    id?: string;
    label: ReactNode;
    instructions?: ReactNode;
    error?: ReactNode;
    options: SelectOption[];
};
/** A native select with an explicit options array, label, and support copy. */
export declare function SelectField({ id: providedId, label, instructions, error, options, className, ...props }: SelectFieldProps): import("react").JSX.Element;
