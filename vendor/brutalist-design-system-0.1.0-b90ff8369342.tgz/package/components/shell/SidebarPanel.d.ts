import { type ReactNode } from 'react';
import { type MenuItem } from '../overlays';
import './sidebar-panel.css';
export type SidebarBrand = {
    label: string;
    href?: string;
    icon?: ReactNode;
};
export type SidebarPrimaryAction = {
    label: string;
    icon?: ReactNode;
    onClick?: () => void;
};
export type SidebarNavigationItem = {
    id: string;
    label: string;
    href: string;
    icon?: ReactNode;
    current?: boolean;
    onClick?: () => void;
};
export type SidebarProject = {
    id: string;
    title: string;
    href?: string;
    pinned?: boolean;
    actions?: MenuItem[];
};
export type SidebarSearch = {
    placeholder?: string;
    query?: string;
    onQueryChange?: (query: string) => void;
};
export type SidebarAccount = {
    label: string;
    icon?: ReactNode;
    actions?: MenuItem[];
    onAction?: (id: string) => void;
};
export type SidebarHeaderProps = {
    brand: SidebarBrand;
    searchOpen: boolean;
    query: string;
    placeholder: string;
    onSearchOpen: () => void;
    onSearchClose: () => void;
    onQueryChange: (query: string) => void;
};
export declare function SidebarHeader({ brand, searchOpen, query, placeholder, onSearchOpen, onSearchClose, onQueryChange }: SidebarHeaderProps): import("react").JSX.Element;
export type SidebarNavigationProps = {
    items: readonly SidebarNavigationItem[];
};
export declare function SidebarNavigation({ items }: SidebarNavigationProps): import("react").JSX.Element;
export type SidebarContextMenuProps = {
    project: SidebarProject;
    onSelect?: (id: string) => void;
};
export declare function SidebarContextMenu({ project, onSelect }: SidebarContextMenuProps): import("react").JSX.Element | null;
export type SidebarProjectRowProps = {
    project: SidebarProject;
    onAction?: (id: string) => void;
};
export declare function SidebarProjectRow({ project, onAction }: SidebarProjectRowProps): import("react").JSX.Element;
export type SidebarProjectsProps = {
    projects: readonly SidebarProject[];
    onAction?: (projectId: string, actionId: string) => void;
    emptyMessage?: string;
};
export declare function SidebarProjects({ projects, onAction, emptyMessage }: SidebarProjectsProps): import("react").JSX.Element;
export type SidebarAccountMenuProps = {
    account: SidebarAccount;
};
export declare function SidebarAccountMenu({ account }: SidebarAccountMenuProps): import("react").JSX.Element;
export type SidebarPanelProps = {
    brand: SidebarBrand;
    primaryAction: SidebarPrimaryAction;
    navigation: readonly SidebarNavigationItem[];
    projects: readonly SidebarProject[];
    search?: SidebarSearch;
    account?: SidebarAccount;
    onProjectAction?: (projectId: string, actionId: string) => void;
    className?: string;
};
export declare function SidebarPanel({ brand, primaryAction, navigation, projects, search, account, onProjectAction, className }: SidebarPanelProps): import("react").JSX.Element;
