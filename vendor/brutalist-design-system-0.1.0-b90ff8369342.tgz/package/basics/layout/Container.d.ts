import type { ComponentProps } from 'react';
export type ContainerProps = ComponentProps<'div'> & {
    maxWidth?: number;
};
export declare function Container({ maxWidth, className, style, ...props }: ContainerProps): import("react").JSX.Element;
