
export type ProgressRingProps = {
    label: string;
    value: number;
    max?: number;
    description?: string;
    className?: string;
};
export declare function ProgressRing({ label, value, max, description, className }: ProgressRingProps): import("react").JSX.Element;
