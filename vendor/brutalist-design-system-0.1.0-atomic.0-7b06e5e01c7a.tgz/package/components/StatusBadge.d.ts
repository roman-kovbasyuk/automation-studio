import type { ReactNode } from 'react';
declare const states: {
    readonly neutral: {
        readonly tone: 'neutral';
        readonly icon: 'info';
    };
    readonly pending: {
        readonly tone: 'accent';
        readonly icon: 'clock';
    };
    readonly success: {
        readonly tone: 'success';
        readonly icon: 'check';
    };
    readonly danger: {
        readonly tone: 'danger';
        readonly icon: 'alert';
    };
};
export type StatusBadgeProps = {
    status: keyof typeof states;
    children: ReactNode;
    showIcon?: boolean;
    className?: string;
};
export declare function StatusBadge({ status, children, showIcon, className }: StatusBadgeProps): import("react").JSX.Element;
export {};
