
export type RatingProps = {
    label: string;
    value: number;
    onChange: (value: number) => void;
    max?: number;
    name?: string;
    disabled?: boolean;
    className?: string;
};
export declare function Rating({ label, value, onChange, max, name, disabled, className }: RatingProps): import("react").JSX.Element;
