import { Fragment as e, jsx as t, jsxs as n } from "react/jsx-runtime";
import { Check as r, LoaderCircle as i, Plus as a, TriangleAlert as o, X as s } from "lucide-react";
import { createContext as c, useCallback as l, useContext as u, useEffect as d, useId as f, useImperativeHandle as p, useMemo as m, useRef as h, useState as g } from "react";
import { Dialog as _, DropdownMenu as v, Popover as y, Tooltip as b } from "radix-ui";
//#region src/components/design-system/basics/DesignSystemRoot.tsx
function x({ className: e = "", ...n }) {
	return /* @__PURE__ */ t("div", {
		...n,
		className: `ds-root ${e}`.trim()
	});
}
//#endregion
//#region src/components/design-system/basics/layout/Container.tsx
function S({ maxWidth: e = 1200, className: n = "", style: r, ...i }) {
	return /* @__PURE__ */ t("div", {
		...i,
		className: `ds-container ${n}`.trim(),
		style: {
			...r,
			"--ds-container-max": `${e}px`
		}
	});
}
//#endregion
//#region src/components/design-system/basics/layout/Divider.tsx
function C({ className: e = "", ...n }) {
	return /* @__PURE__ */ t("hr", {
		...n,
		className: `ds-divider ${e}`.trim()
	});
}
//#endregion
//#region src/components/design-system/basics/layout/types.ts
function w(e) {
	return `var(--v2-space-${e ?? 4})`;
}
//#endregion
//#region src/components/design-system/basics/layout/Grid.tsx
function T({ gap: e, minItemWidth: n = 280, className: r = "", style: i, ...a }) {
	return /* @__PURE__ */ t("div", {
		...a,
		className: `ds-grid ${r}`.trim(),
		style: {
			...i,
			"--ds-gap": w(e),
			"--ds-grid-min": `${n}px`
		}
	});
}
//#endregion
//#region src/components/design-system/basics/layout/Inline.tsx
function ee({ gap: e, className: n = "", style: r, ...i }) {
	return /* @__PURE__ */ t("div", {
		...i,
		className: `ds-inline ${n}`.trim(),
		style: {
			...r,
			"--ds-gap": w(e)
		}
	});
}
//#endregion
//#region src/components/design-system/basics/layout/ScrollArea.tsx
function te({ label: e, className: n = "", tabIndex: r, ...i }) {
	return /* @__PURE__ */ t("div", {
		...i,
		"aria-label": e,
		className: `ds-scroll-area ${n}`.trim(),
		role: "region",
		tabIndex: r ?? 0
	});
}
//#endregion
//#region src/components/design-system/basics/layout/Stack.tsx
function E({ gap: e, className: n = "", style: r, ...i }) {
	return /* @__PURE__ */ t("div", {
		...i,
		className: `ds-stack ${n}`.trim(),
		style: {
			...r,
			"--ds-gap": w(e)
		}
	});
}
//#endregion
//#region src/components/design-system/basics/layout/Surface.tsx
function ne({ tone: e = "surface", className: n = "", ...r }) {
	return /* @__PURE__ */ t("div", {
		...r,
		className: `ds-surface ds-surface--${e} ${n}`.trim()
	});
}
//#endregion
//#region src/components/design-system/components/actions/AppButton.tsx
function D(e) {
	if (e.as === "a") {
		let { children: r, as: a, variant: o = "secondary", size: s = "default", iconOnly: c = !1, busy: l = !1, disabled: u = !1, className: d = "", onClick: f, ...p } = e, m = l || u, h = [
			"ds-button",
			`ds-button--${o === "icon" ? "secondary" : o}`,
			(c || o === "icon") && "ds-button--icon",
			d
		].filter(Boolean).join(" "), g = (e) => {
			if (m) {
				e.preventDefault(), e.stopPropagation();
				return;
			}
			f?.(e);
		};
		return /* @__PURE__ */ n("a", {
			...p,
			className: h,
			"data-size": s,
			"aria-busy": l || void 0,
			"aria-disabled": m || void 0,
			tabIndex: m ? -1 : p.tabIndex,
			onClick: g,
			children: [l && /* @__PURE__ */ t(i, {
				size: 16,
				className: "ds-button__spinner",
				"aria-hidden": "true"
			}), r]
		});
	}
	let { children: r, variant: a = "secondary", size: o = "default", iconOnly: s = !1, busy: c = !1, disabled: l = !1, className: u = "", onClick: d, ...f } = e, p = c || l, m = [
		"ds-button",
		`ds-button--${a === "icon" ? "secondary" : a}`,
		(s || a === "icon") && "ds-button--icon",
		u
	].filter(Boolean).join(" ");
	return /* @__PURE__ */ n("button", {
		...f,
		type: e.type ?? "button",
		className: m,
		"data-size": o,
		"aria-busy": c || void 0,
		disabled: p,
		onClick: d,
		children: [c && /* @__PURE__ */ t(i, {
			size: 16,
			className: "ds-button__spinner",
			"aria-hidden": "true"
		}), r]
	});
}
//#endregion
//#region src/components/design-system/components/actions/TextAction.tsx
function re({ children: e, className: n = "", ...r }) {
	return /* @__PURE__ */ t(D, {
		...r,
		variant: "quiet",
		size: "compact",
		className: `ds-text-action ${n}`,
		children: e
	});
}
//#endregion
//#region src/components/design-system/components/forms/FieldSupport.tsx
function O(e) {
	let t = f();
	return e ?? `ds-field-${t.replace(/:/g, "")}`;
}
function k(e, t, n) {
	let r = [t ? `${e}-instructions` : void 0, n ? `${e}-error` : void 0].filter(Boolean);
	return r.length ? r.join(" ") : void 0;
}
function A({ id: r, instructions: i, error: a }) {
	return /* @__PURE__ */ n(e, { children: [i && /* @__PURE__ */ t("p", {
		id: `${r}-instructions`,
		className: "ds-field__instructions",
		children: i
	}), a && /* @__PURE__ */ t("p", {
		id: `${r}-error`,
		className: "ds-field__error",
		role: "alert",
		children: a
	})] });
}
//#endregion
//#region src/components/design-system/components/forms/CheckboxField.tsx
function ie({ id: e, label: r, instructions: i, error: a, indeterminate: o = !1, ref: s, className: c = "", ...l }) {
	let u = O(e), f = h(null);
	return p(s, () => f.current, []), d(() => {
		f.current && (f.current.indeterminate = o);
	}, [o]), /* @__PURE__ */ n("div", {
		className: `ds-choice-field ${c}`.trim(),
		"data-mixed": o || void 0,
		children: [/* @__PURE__ */ n("label", {
			className: "ds-choice-field__label",
			htmlFor: u,
			children: [/* @__PURE__ */ t("input", {
				...l,
				ref: f,
				id: u,
				type: "checkbox",
				"aria-checked": o ? "mixed" : void 0,
				className: "ds-choice-field__control",
				"aria-describedby": k(u, i, a),
				"aria-invalid": a ? !0 : void 0
			}), /* @__PURE__ */ t("span", { children: r })]
		}), /* @__PURE__ */ t(A, {
			id: u,
			instructions: i,
			error: a
		})]
	});
}
//#endregion
//#region src/components/design-system/components/forms/RadioGroup.tsx
function ae({ id: e, name: r, label: i, instructions: a, error: o, options: s, value: c, defaultValue: l, onChange: u, disabled: d = !1, className: p = "" }) {
	let m = O(e), h = f(), g = r ?? `ds-radio-${h.replace(/:/g, "")}`;
	return /* @__PURE__ */ n("fieldset", {
		className: `ds-radio-group ${p}`.trim(),
		"aria-describedby": k(m, a, o),
		children: [
			/* @__PURE__ */ t("legend", {
				className: "ds-field__label",
				children: i
			}),
			/* @__PURE__ */ t("div", {
				className: "ds-radio-group__options",
				role: "radiogroup",
				"aria-label": typeof i == "string" ? i : void 0,
				children: s.map((e) => {
					let r = `${m}-${e.value}`;
					return /* @__PURE__ */ n("label", {
						className: "ds-choice-field__label",
						htmlFor: r,
						children: [/* @__PURE__ */ t("input", {
							id: r,
							className: "ds-choice-field__control",
							type: "radio",
							name: g,
							value: e.value,
							checked: c === void 0 ? void 0 : c === e.value,
							defaultChecked: l === e.value,
							disabled: d || e.disabled,
							"aria-invalid": o ? !0 : void 0,
							onChange: () => u?.(e.value)
						}), /* @__PURE__ */ t("span", { children: e.label })]
					}, e.value);
				})
			}),
			/* @__PURE__ */ t(A, {
				id: m,
				instructions: a,
				error: o
			})
		]
	});
}
//#endregion
//#region src/components/design-system/components/forms/SelectField.tsx
function oe({ id: e, label: r, instructions: i, error: a, options: o, className: s = "", ...c }) {
	let l = O(e);
	return /* @__PURE__ */ n("div", {
		className: `ds-field ${s}`.trim(),
		children: [
			/* @__PURE__ */ t("label", {
				className: "ds-field__label",
				htmlFor: l,
				children: r
			}),
			/* @__PURE__ */ t("select", {
				...c,
				id: l,
				className: "ds-field__control",
				"aria-describedby": k(l, i, a),
				"aria-invalid": a ? !0 : void 0,
				children: o.map((e) => /* @__PURE__ */ t("option", {
					value: e.value,
					disabled: e.disabled,
					children: e.label
				}, e.value))
			}),
			/* @__PURE__ */ t(A, {
				id: l,
				instructions: i,
				error: a
			})
		]
	});
}
//#endregion
//#region src/components/design-system/components/forms/SwitchField.tsx
function se({ id: e, label: r, instructions: i, error: a, onCheckedChange: o, className: s = "", ...c }) {
	let l = O(e);
	return /* @__PURE__ */ n("div", {
		className: `ds-switch-field ${s}`.trim(),
		children: [/* @__PURE__ */ n("label", {
			className: "ds-switch-field__label",
			htmlFor: l,
			children: [
				/* @__PURE__ */ t("input", {
					...c,
					id: l,
					type: "checkbox",
					role: "switch",
					className: "ds-switch-field__control",
					"aria-describedby": k(l, i, a),
					"aria-invalid": a ? !0 : void 0,
					onChange: (e) => o?.(e.currentTarget.checked)
				}),
				/* @__PURE__ */ t("span", {
					className: "ds-switch-field__track",
					"aria-hidden": "true",
					children: /* @__PURE__ */ t("span", { className: "ds-switch-field__thumb" })
				}),
				/* @__PURE__ */ t("span", { children: r })
			]
		}), /* @__PURE__ */ t(A, {
			id: l,
			instructions: i,
			error: a
		})]
	});
}
//#endregion
//#region src/components/design-system/components/forms/TextArea.tsx
function ce({ id: e, label: r, instructions: i, error: a, className: o = "", ...s }) {
	let c = O(e);
	return /* @__PURE__ */ n("div", {
		className: `ds-field ${o}`.trim(),
		children: [
			/* @__PURE__ */ t("label", {
				className: "ds-field__label",
				htmlFor: c,
				children: r
			}),
			/* @__PURE__ */ t("textarea", {
				...s,
				id: c,
				className: "ds-field__control ds-field__control--textarea",
				"aria-describedby": k(c, i, a),
				"aria-invalid": a ? !0 : void 0
			}),
			/* @__PURE__ */ t(A, {
				id: c,
				instructions: i,
				error: a
			})
		]
	});
}
//#endregion
//#region src/components/design-system/components/forms/TextField.tsx
function j({ id: e, label: r, instructions: i, error: a, className: o = "", ...s }) {
	let c = O(e);
	return /* @__PURE__ */ n("div", {
		className: `ds-field ${o}`.trim(),
		children: [
			/* @__PURE__ */ t("label", {
				className: "ds-field__label",
				htmlFor: c,
				children: r
			}),
			/* @__PURE__ */ t("input", {
				...s,
				id: c,
				className: "ds-field__control",
				"aria-describedby": k(c, i, a),
				"aria-invalid": a ? !0 : void 0
			}),
			/* @__PURE__ */ t(A, {
				id: c,
				instructions: i,
				error: a
			})
		]
	});
}
//#endregion
//#region src/components/design-system/components/navigation/Breadcrumbs.tsx
function le({ items: e, ariaLabel: r = "Breadcrumb", className: i = "" }) {
	return /* @__PURE__ */ t("nav", {
		className: `ds-breadcrumbs ${i}`.trim(),
		"aria-label": r,
		children: /* @__PURE__ */ t("ol", { children: e.map((r, i) => {
			let a = i === e.length - 1;
			return /* @__PURE__ */ n("li", { children: [i > 0 && /* @__PURE__ */ t("span", {
				className: "ds-breadcrumbs__separator",
				"aria-hidden": "true",
				children: "/"
			}), r.href && !a ? /* @__PURE__ */ t("a", {
				href: r.href,
				children: r.label
			}) : /* @__PURE__ */ t("span", {
				"aria-current": a ? "page" : void 0,
				children: r.label
			})] }, i);
		}) })
	});
}
//#endregion
//#region src/components/design-system/components/navigation/Pagination.tsx
function M({ page: e, pageCount: r, onPageChange: i, className: a = "" }) {
	let o = Math.min(Math.max(e, 1), Math.max(r, 1)), s = Array.from({ length: Math.max(r, 0) }, (e, t) => t + 1);
	return /* @__PURE__ */ n("nav", {
		className: `ds-pagination ${a}`.trim(),
		"aria-label": "Pagination",
		children: [
			/* @__PURE__ */ t("button", {
				type: "button",
				"aria-label": "Previous page",
				disabled: o <= 1,
				onClick: () => i(o - 1),
				children: "Previous"
			}),
			/* @__PURE__ */ t("ol", { children: s.map((e) => /* @__PURE__ */ t("li", { children: /* @__PURE__ */ t("button", {
				type: "button",
				"aria-label": `Page ${e}`,
				"aria-current": e === o ? "page" : void 0,
				onClick: () => i(e),
				children: e
			}) }, e)) }),
			/* @__PURE__ */ t("button", {
				type: "button",
				"aria-label": "Next page",
				disabled: o >= r,
				onClick: () => i(o + 1),
				children: "Next"
			})
		]
	});
}
//#endregion
//#region src/components/design-system/components/navigation/SegmentedControl.tsx
function N({ options: e, value: r, onValueChange: i, ariaLabel: a, className: o = "" }) {
	return /* @__PURE__ */ t("div", {
		className: `ds-segmented-control ${o}`.trim(),
		role: "radiogroup",
		"aria-label": a,
		children: e.map((e) => /* @__PURE__ */ n("label", {
			className: "ds-segmented-control__option",
			"data-selected": e.value === r || void 0,
			children: [/* @__PURE__ */ t("input", {
				type: "radio",
				name: a,
				value: e.value,
				checked: e.value === r,
				disabled: e.disabled,
				onChange: () => i(e.value)
			}), /* @__PURE__ */ t("span", { children: e.label })]
		}, e.value))
	});
}
//#endregion
//#region src/components/design-system/components/navigation/Stepper.tsx
function ue({ steps: e, activeStep: r, ariaLabel: i = "Progress", className: a = "" }) {
	return /* @__PURE__ */ t("ol", {
		className: `ds-stepper ${a}`.trim(),
		"aria-label": i,
		children: e.map((e, i) => {
			let a = i < r ? "complete" : i === r ? "current" : e.disabled ? "disabled" : "upcoming";
			return /* @__PURE__ */ n("li", {
				"data-status": a,
				"aria-current": a === "current" ? "step" : void 0,
				children: [/* @__PURE__ */ t("span", {
					className: "ds-stepper__number",
					"aria-hidden": "true",
					children: i + 1
				}), /* @__PURE__ */ n("span", {
					className: "ds-stepper__content",
					children: [/* @__PURE__ */ t("strong", { children: e.label }), e.description && /* @__PURE__ */ t("small", { children: e.description })]
				})]
			}, e.label);
		})
	});
}
//#endregion
//#region src/components/design-system/molecules/PillTabs.jsx
function P({ tabs: e, value: n, onChange: r, ariaLabel: i, idPrefix: a = "tab" }) {
	let o = h({});
	function s(t, n) {
		if (![
			"ArrowRight",
			"ArrowLeft",
			"Home",
			"End"
		].includes(t.key)) return;
		t.preventDefault();
		let i = e.indexOf(n), a = e[t.key === "Home" ? 0 : t.key === "End" ? e.length - 1 : (i + (t.key === "ArrowRight" ? 1 : -1) + e.length) % e.length];
		r(a), o.current[a]?.focus();
	}
	return /* @__PURE__ */ t("div", {
		className: "v2-pill-tabs",
		role: "tablist",
		"aria-label": i,
		children: e.map((e) => {
			let i = e === n, c = e.toLowerCase().replace(/\s+/g, "-"), l = `${a}-${c}-tab`, u = `${a}-${c}-panel`;
			return /* @__PURE__ */ t("button", {
				ref: (t) => {
					o.current[e] = t;
				},
				id: l,
				type: "button",
				role: "tab",
				"aria-selected": i,
				"aria-controls": u,
				tabIndex: i ? 0 : -1,
				onClick: () => r(e),
				onKeyDown: (t) => s(t, e),
				children: e
			}, e);
		})
	});
}
//#endregion
//#region src/components/design-system/components/navigation/Tabs.tsx
function F({ items: e, value: n, onValueChange: r, ariaLabel: i, idPrefix: a = "tab", className: o = "" }) {
	let s = e.filter((e) => !e.disabled), c = s.map((e) => e.label), l = s.find((e) => e.value === n) ?? s[0];
	return l ? /* @__PURE__ */ t("div", {
		className: o,
		children: /* @__PURE__ */ t(P, {
			tabs: c,
			value: l.label,
			ariaLabel: i,
			idPrefix: a,
			onChange: (e) => {
				let t = s.find((t) => t.label === e);
				t && r(t.value);
			}
		})
	}) : null;
}
function I({ value: e, activeValue: n, idPrefix: r = "tab", children: i, className: a = "" }) {
	return /* @__PURE__ */ t("div", {
		className: a,
		role: "tabpanel",
		id: `${r}-${e}-panel`,
		"aria-labelledby": `${r}-${e}-tab`,
		hidden: e !== n,
		tabIndex: 0,
		children: i
	});
}
//#endregion
//#region src/components/design-system/components/overlays/overlays.tsx
function L({ children: e, primitive: n }) {
	return /* @__PURE__ */ t(n, {
		asChild: !0,
		children: typeof e == "string" ? /* @__PURE__ */ t("button", {
			className: "ds-overlay-trigger",
			type: "button",
			children: e
		}) : e
	});
}
function R({ open: e, onOpenChange: r, title: i, description: a, trigger: o, children: s, closeLabel: c = "Close dialog" }) {
	return /* @__PURE__ */ n(_.Root, {
		open: e,
		onOpenChange: r,
		children: [o && /* @__PURE__ */ t(L, {
			primitive: _.Trigger,
			children: o
		}), /* @__PURE__ */ n(_.Portal, { children: [/* @__PURE__ */ t(_.Overlay, { className: "ds-overlay-backdrop" }), /* @__PURE__ */ n(_.Content, {
			className: "ds-dialog",
			"aria-describedby": void 0,
			children: [
				/* @__PURE__ */ n("div", {
					className: "ds-overlay__header",
					children: [/* @__PURE__ */ t(_.Title, {
						className: "ds-overlay__title",
						children: i
					}), /* @__PURE__ */ t(_.Close, {
						className: "ds-overlay__close",
						"aria-label": c,
						children: "×"
					})]
				}),
				a && /* @__PURE__ */ t(_.Description, {
					className: "ds-overlay__description",
					children: a
				}),
				/* @__PURE__ */ t("div", {
					className: "ds-overlay__body",
					children: s
				})
			]
		})] })]
	});
}
function z({ side: e = "right", open: r, onOpenChange: i, title: a, description: o, trigger: s, children: c, closeLabel: l }) {
	return /* @__PURE__ */ n(_.Root, {
		open: r,
		onOpenChange: i,
		children: [s && /* @__PURE__ */ t(L, {
			primitive: _.Trigger,
			children: s
		}), /* @__PURE__ */ n(_.Portal, { children: [/* @__PURE__ */ t(_.Overlay, { className: "ds-overlay-backdrop" }), /* @__PURE__ */ n(_.Content, {
			className: `ds-drawer ds-drawer--${e}`,
			children: [
				/* @__PURE__ */ n("div", {
					className: "ds-overlay__header",
					children: [/* @__PURE__ */ t(_.Title, {
						className: "ds-overlay__title",
						children: a
					}), /* @__PURE__ */ t(_.Close, {
						className: "ds-overlay__close",
						"aria-label": l ?? "Close drawer",
						children: "×"
					})]
				}),
				o && /* @__PURE__ */ t(_.Description, {
					className: "ds-overlay__description",
					children: o
				}),
				/* @__PURE__ */ t("div", {
					className: "ds-overlay__body",
					children: c
				})
			]
		})] })]
	});
}
function B({ open: e, onOpenChange: r, trigger: i, children: a, side: o = "bottom", align: s = "start" }) {
	return /* @__PURE__ */ n(y.Root, {
		open: e,
		onOpenChange: r,
		children: [/* @__PURE__ */ t(L, {
			primitive: y.Trigger,
			children: i
		}), /* @__PURE__ */ t(y.Portal, { children: /* @__PURE__ */ t(y.Content, {
			className: "ds-popover",
			side: o,
			align: s,
			sideOffset: 8,
			children: a
		}) })]
	});
}
function V({ content: e, children: r, open: i, onOpenChange: a, side: o = "top", delayDuration: s = 0 }) {
	return /* @__PURE__ */ t(b.Provider, {
		delayDuration: s,
		children: /* @__PURE__ */ n(b.Root, {
			open: i,
			onOpenChange: a,
			children: [/* @__PURE__ */ t(b.Trigger, {
				asChild: !0,
				children: r
			}), /* @__PURE__ */ t(b.Portal, { children: /* @__PURE__ */ n(b.Content, {
				className: "ds-tooltip",
				side: o,
				sideOffset: 8,
				children: [e, /* @__PURE__ */ t(b.Arrow, { className: "ds-tooltip__arrow" })]
			}) })]
		})
	});
}
function H({ open: e, onOpenChange: r, trigger: i, items: a, onSelect: o, ariaLabel: s = "Actions" }) {
	return /* @__PURE__ */ n(v.Root, {
		open: e,
		onOpenChange: r,
		children: [/* @__PURE__ */ t(L, {
			primitive: v.Trigger,
			children: i
		}), /* @__PURE__ */ t(v.Portal, { children: /* @__PURE__ */ t(v.Content, {
			className: "ds-menu",
			align: "start",
			sideOffset: 8,
			"aria-label": s,
			children: a.map((e) => /* @__PURE__ */ t(v.Item, {
				className: `ds-menu__item${e.danger ? " ds-menu__item--danger" : ""}`,
				disabled: e.disabled,
				onSelect: () => o(e.id),
				children: e.label
			}, e.id))
		}) })]
	});
}
//#endregion
//#region src/components/design-system/components/selection/Combobox.tsx
function U({ label: e, options: r, value: i, onValueChange: a, clearable: o = !1, disabled: s = !1, placeholder: c = "Search options", className: l = "" }) {
	let u = f(), d = r.find((e) => e.value === i), [p, h] = g(!1), [_, v] = g(""), y = _.trim().toLocaleLowerCase(), b = m(() => r.filter((e) => String(e.label).toLocaleLowerCase().includes(y)), [r, y]), x = p ? _ : d ? String(d.label) : "";
	function S(e, t) {
		t || s || (a(e), v(""), h(!1));
	}
	return /* @__PURE__ */ n("div", {
		className: `ds-selection ${l}`.trim(),
		children: [
			/* @__PURE__ */ t("label", {
				className: "ds-selection__label",
				htmlFor: u,
				children: e
			}),
			/* @__PURE__ */ n("div", {
				className: "ds-selection__control-wrap",
				children: [/* @__PURE__ */ t("input", {
					id: u,
					className: "ds-selection__control",
					type: "text",
					role: "combobox",
					"aria-autocomplete": "list",
					"aria-controls": `${u}-options`,
					"aria-expanded": p,
					"aria-haspopup": "listbox",
					disabled: s,
					placeholder: c,
					value: x,
					onFocus: () => {
						h(!0), v("");
					},
					onChange: (e) => {
						v(e.target.value), h(!0);
					},
					onKeyDown: (e) => {
						e.key === "Escape" && (h(!1), v("")), e.key === "Enter" && b.length === 1 && (e.preventDefault(), S(b[0].value, b[0].disabled));
					}
				}), o && i !== null && !s && /* @__PURE__ */ t("button", {
					className: "ds-selection__clear",
					type: "button",
					"aria-label": `Clear ${e}`,
					onClick: () => {
						a(null), v("");
					},
					children: "×"
				})]
			}),
			p && /* @__PURE__ */ t("ul", {
				id: `${u}-options`,
				className: "ds-selection__options",
				role: "listbox",
				"aria-label": `${e} options`,
				children: b.length > 0 ? b.map((e) => /* @__PURE__ */ t("li", { children: /* @__PURE__ */ t("button", {
					type: "button",
					className: "ds-selection__option",
					role: "option",
					"aria-selected": e.value === i,
					"aria-disabled": e.disabled || void 0,
					disabled: e.disabled || s,
					onMouseDown: (e) => e.preventDefault(),
					onClick: () => S(e.value, e.disabled),
					children: e.label
				}) }, String(e.value))) : /* @__PURE__ */ t("li", {
					className: "ds-selection__empty",
					role: "status",
					children: "No matching options."
				})
			})
		]
	});
}
//#endregion
//#region src/components/design-system/components/selection/MultiSelect.tsx
function de({ label: e, options: r, value: i, onValueChange: a, disabled: o = !1, placeholder: s = "Search options", className: c = "" }) {
	let l = f(), [u, d] = g(!1), [p, h] = g(""), _ = p.trim().toLocaleLowerCase(), v = m(() => r.filter((e) => String(e.label).toLocaleLowerCase().includes(_)), [r, _]), y = r.filter((e) => i.includes(e.value)).map((e) => String(e.label));
	function b(e, t) {
		t || o || a(i.includes(e) ? i.filter((t) => t !== e) : [...i, e]);
	}
	return /* @__PURE__ */ n("div", {
		className: `ds-selection ${c}`.trim(),
		children: [
			/* @__PURE__ */ t("label", {
				className: "ds-selection__label",
				htmlFor: l,
				children: e
			}),
			/* @__PURE__ */ t("input", {
				id: l,
				className: "ds-selection__control",
				type: "text",
				role: "combobox",
				"aria-autocomplete": "list",
				"aria-controls": `${l}-options`,
				"aria-expanded": u,
				"aria-haspopup": "listbox",
				disabled: o,
				placeholder: y.length ? y.join(", ") : s,
				value: p,
				onFocus: () => d(!0),
				onChange: (e) => {
					h(e.target.value), d(!0);
				},
				onKeyDown: (e) => {
					e.key === "Escape" && (d(!1), h(""));
				}
			}),
			u && /* @__PURE__ */ t("ul", {
				id: `${l}-options`,
				className: "ds-selection__options",
				role: "listbox",
				"aria-label": `${e} options`,
				"aria-multiselectable": "true",
				children: v.length > 0 ? v.map((e) => /* @__PURE__ */ t("li", { children: /* @__PURE__ */ t("button", {
					type: "button",
					className: "ds-selection__option",
					role: "option",
					"aria-selected": i.includes(e.value),
					"aria-disabled": e.disabled || void 0,
					disabled: e.disabled || o,
					onMouseDown: (e) => e.preventDefault(),
					onClick: () => b(e.value, e.disabled),
					children: e.label
				}) }, String(e.value))) : /* @__PURE__ */ t("li", {
					className: "ds-selection__empty",
					role: "status",
					children: "No matching options."
				})
			})
		]
	});
}
//#endregion
//#region src/components/design-system/components/feedback/Alert.tsx
function fe({ title: e, children: r, tone: i = "info", onDismiss: a, className: o = "" }) {
	let c = i === "danger";
	return /* @__PURE__ */ n("div", {
		className: `ds-alert ${o}`.trim(),
		"data-tone": i,
		role: c ? "alert" : "status",
		children: [/* @__PURE__ */ n("div", {
			className: "ds-alert__content",
			children: [e && /* @__PURE__ */ t("strong", {
				className: "ds-alert__title",
				children: e
			}), r && /* @__PURE__ */ t("div", {
				className: "ds-alert__body",
				children: r
			})]
		}), a && /* @__PURE__ */ t("button", {
			type: "button",
			className: "ds-alert__dismiss",
			"aria-label": "Dismiss alert",
			onClick: a,
			children: /* @__PURE__ */ t(s, {
				size: 16,
				"aria-hidden": "true"
			})
		})]
	});
}
//#endregion
//#region src/components/design-system/components/feedback/ErrorState.tsx
function W({ title: e, description: r, actionLabel: i, onAction: a, className: s = "" }) {
	return /* @__PURE__ */ n("section", {
		className: `ds-error-state ${s}`.trim(),
		"aria-labelledby": "ds-error-state-title",
		children: [
			/* @__PURE__ */ t(o, {
				className: "ds-error-state__icon",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ t("h2", {
				id: "ds-error-state-title",
				className: "ds-error-state__title",
				children: e
			}),
			r && /* @__PURE__ */ t("p", {
				className: "ds-error-state__description",
				children: r
			}),
			i && a && /* @__PURE__ */ t(D, {
				variant: "secondary",
				onClick: a,
				children: i
			})
		]
	});
}
//#endregion
//#region src/components/design-system/components/feedback/Progress.tsx
function G({ value: e, max: r = 100, label: i, showValue: a = !0, className: o = "" }) {
	let s = f(), c = Math.max(0, Math.min(e, r)), l = Math.round(c / r * 100);
	return /* @__PURE__ */ n("div", {
		className: `ds-progress ${o}`.trim(),
		children: [/* @__PURE__ */ n("div", {
			className: "ds-progress__header",
			children: [/* @__PURE__ */ t("span", {
				id: s,
				children: i
			}), a && /* @__PURE__ */ n("span", { children: [l, "%"] })]
		}), /* @__PURE__ */ t("div", {
			className: "ds-progress__track",
			role: "progressbar",
			"aria-labelledby": s,
			"aria-valuemin": 0,
			"aria-valuemax": r,
			"aria-valuenow": c,
			children: /* @__PURE__ */ t("span", {
				className: "ds-progress__value",
				style: { width: `${l}%` }
			})
		})]
	});
}
//#endregion
//#region src/components/design-system/components/feedback/Skeleton.tsx
function K({ lines: e = 1, className: n = "" }) {
	return /* @__PURE__ */ t("div", {
		className: `ds-skeleton ${n}`.trim(),
		children: Array.from({ length: Math.max(1, e) }, (e, n) => /* @__PURE__ */ t("span", {
			className: "ds-skeleton__line",
			"aria-hidden": "true"
		}, n))
	});
}
//#endregion
//#region src/components/design-system/components/feedback/StatusBadge.tsx
function pe({ children: e, tone: n = "neutral", className: r = "" }) {
	return /* @__PURE__ */ t("span", {
		className: `ds-status-badge ${r}`.trim(),
		"data-tone": n,
		children: e
	});
}
//#endregion
//#region src/components/design-system/components/feedback/ToastProvider.tsx
var q = c(null);
function me({ children: e }) {
	let [r, i] = g([]), a = l((e) => i((t) => [...t, {
		...e,
		id: Date.now() + t.length
	}]), []), o = l((e) => i((t) => t.filter((t) => t.id !== e)), []), c = m(() => ({
		toast: a,
		dismiss: o
	}), [a, o]);
	return /* @__PURE__ */ n(q.Provider, {
		value: c,
		children: [e, /* @__PURE__ */ t("div", {
			className: "ds-toast-viewport",
			"aria-label": "Notifications",
			"aria-live": "polite",
			children: r.map((e) => /* @__PURE__ */ n("div", {
				className: "ds-toast",
				"data-tone": e.tone ?? "info",
				role: "status",
				children: [/* @__PURE__ */ n("div", { children: [/* @__PURE__ */ t("strong", { children: e.title }), e.description && /* @__PURE__ */ t("div", {
					className: "ds-toast__description",
					children: e.description
				})] }), /* @__PURE__ */ t("button", {
					type: "button",
					className: "ds-toast__dismiss",
					"aria-label": `Dismiss ${String(e.title)}`,
					onClick: () => o(e.id),
					children: /* @__PURE__ */ t(s, {
						size: 16,
						"aria-hidden": "true"
					})
				})]
			}, e.id))
		})]
	});
}
function he() {
	let e = u(q);
	if (!e) throw Error("useToast must be used inside ToastProvider");
	return e;
}
//#endregion
//#region src/components/design-system/components/files/FileDropzone.tsx
function ge({ label: e, onFilesChange: r, accept: i, multiple: a = !0, disabled: o = !1, description: s = "Drop files here or choose files from your device.", chooseLabel: c = "Choose files", className: l = "", id: u }) {
	let d = f(), p = u ?? d, m = h(null), g = (e) => {
		!o && e && r(Array.from(e));
	};
	return /* @__PURE__ */ n("div", {
		className: `ds-file-dropzone ${l}`.trim(),
		"data-disabled": o || void 0,
		onDragOver: (e) => e.preventDefault(),
		onDrop: (e) => {
			e.preventDefault(), g(e.dataTransfer.files);
		},
		children: [/* @__PURE__ */ t("input", {
			ref: m,
			id: p,
			className: "ds-file-dropzone__input",
			type: "file",
			accept: i,
			multiple: a,
			disabled: o,
			"aria-label": typeof e == "string" ? e : void 0,
			onChange: (e) => {
				g(e.currentTarget.files), e.currentTarget.value = "";
			}
		}), /* @__PURE__ */ n("div", {
			className: "ds-file-dropzone__body",
			children: [
				/* @__PURE__ */ t("strong", {
					className: "ds-file-dropzone__label",
					children: e
				}),
				/* @__PURE__ */ t("p", {
					className: "ds-file-dropzone__description",
					children: s
				}),
				/* @__PURE__ */ t("button", {
					type: "button",
					className: "ds-file-dropzone__choose",
					disabled: o,
					onClick: () => m.current?.click(),
					children: c
				})
			]
		})]
	});
}
//#endregion
//#region src/components/design-system/components/files/FileList.tsx
function _e(e) {
	if (e < 1024) return `${e} B`;
	let t = [
		"KB",
		"MB",
		"GB"
	], n = e / 1024, r = 0;
	for (; n >= 1024 && r < t.length - 1;) n /= 1024, r += 1;
	return `${Math.round(n * 10) / 10} ${t[r]}`;
}
function ve({ files: e, onRemove: r, emptyMessage: i = "No files selected.", className: a = "" }) {
	return e.length === 0 ? /* @__PURE__ */ t("p", {
		className: `ds-file-list__empty ${a}`.trim(),
		children: i
	}) : /* @__PURE__ */ t("ul", {
		className: `ds-file-list ${a}`.trim(),
		"aria-label": "Selected files",
		children: e.map((e, i) => /* @__PURE__ */ n("li", {
			className: "ds-file-list__item",
			children: [/* @__PURE__ */ n("span", {
				className: "ds-file-list__details",
				children: [/* @__PURE__ */ t("strong", { children: e.name }), /* @__PURE__ */ t("span", { children: _e(e.size) })]
			}), r && /* @__PURE__ */ t("button", {
				type: "button",
				className: "ds-file-list__remove",
				onClick: () => r(i),
				"aria-label": `Remove ${e.name}`,
				children: "Remove"
			})]
		}, `${e.name}-${e.lastModified}-${i}`))
	});
}
//#endregion
//#region src/components/design-system/components/ai/AITaskStatus.tsx
var ye = {
	queued: "Queued",
	running: "Working",
	succeeded: "Complete",
	failed: "Failed"
};
function J({ status: e, label: r, progress: i, className: a = "" }) {
	let o = e === "failed" ? "alert" : "status";
	return /* @__PURE__ */ n("section", {
		className: `ds-ai-task-status ${a}`.trim(),
		"data-state": e,
		role: o,
		children: [/* @__PURE__ */ n("div", {
			className: "ds-ai-task-status__summary",
			children: [
				/* @__PURE__ */ t("span", {
					"aria-hidden": "true",
					children: e === "succeeded" ? "✓" : e === "failed" ? "!" : "✦"
				}),
				/* @__PURE__ */ t("span", { children: r }),
				/* @__PURE__ */ t("small", { children: ye[e] })
			]
		}), e === "running" && i !== void 0 && /* @__PURE__ */ t(G, {
			value: i,
			label: r
		})]
	});
}
//#endregion
//#region src/components/design-system/components/ai/AIResult.tsx
function be({ title: e, children: r, actionLabel: i, onAction: a, className: o = "" }) {
	return /* @__PURE__ */ n("section", {
		className: `ds-ai-result ${o}`.trim(),
		children: [
			/* @__PURE__ */ t("div", {
				className: "ds-ai-result__mark",
				"aria-hidden": "true",
				children: "✦"
			}),
			/* @__PURE__ */ n("div", {
				className: "ds-ai-result__content",
				children: [/* @__PURE__ */ t("h3", { children: e }), r && /* @__PURE__ */ t("div", { children: r })]
			}),
			i && a && /* @__PURE__ */ t("button", {
				type: "button",
				className: "ds-ai-result__action",
				onClick: a,
				children: i
			})
		]
	});
}
//#endregion
//#region src/components/design-system/components/content/ActionCard.tsx
function xe({ label: e, status: r, actions: i, persistentAction: a, highlighted: o = !1, children: s, className: c = "", ...l }) {
	return /* @__PURE__ */ n("article", {
		...l,
		"aria-label": l["aria-label"] ?? e,
		className: `ds-action-card ${c}`.trim(),
		"data-highlighted": o || void 0,
		children: [/* @__PURE__ */ n("header", {
			className: "ds-action-card__header",
			children: [/* @__PURE__ */ n("div", {
				className: "ds-action-card__meta",
				children: [/* @__PURE__ */ t("span", { children: e }), r]
			}), (i || a) && /* @__PURE__ */ n("div", {
				className: "ds-action-card__controls",
				children: [i && /* @__PURE__ */ t("div", {
					className: "ds-action-card__actions",
					children: i
				}), a]
			})]
		}), /* @__PURE__ */ t("div", {
			className: "ds-action-card__content",
			children: s
		})]
	});
}
//#endregion
//#region src/components/design-system/components/content/FactGrid.tsx
function Y({ items: e, label: r = "Details", className: i = "" }) {
	return /* @__PURE__ */ t("div", {
		className: `ds-fact-grid-container ${i}`.trim(),
		role: "group",
		"aria-label": r,
		children: /* @__PURE__ */ t("dl", {
			className: "ds-fact-grid",
			children: e.map(({ id: e, label: r, value: i, emphasis: a }) => /* @__PURE__ */ n("div", {
				"data-emphasis": a || void 0,
				children: [/* @__PURE__ */ t("dt", { children: r }), /* @__PURE__ */ t("dd", { children: i })]
			}, e))
		})
	});
}
//#endregion
//#region src/components/design-system/components/content/InlineText.tsx
function X({ label: e, value: r = "", onSave: i, readOnly: a = !1, multiline: o = !1, required: s = !1, maxLength: c = 500, className: l = "" }) {
	let [u, f] = g(!1), [p, m] = g(r), [_, v] = g(r), [y, b] = g(!1), [x, S] = g(""), C = h(null);
	d(() => {
		u || m(r);
	}, [r]);
	let w = () => {
		f(!1), S(""), requestAnimationFrame(() => C.current?.focus());
	}, T = async () => {
		let t = _.trim();
		if (s && !t) {
			S(`${e} cannot be empty.`);
			return;
		}
		b(!0), S("");
		try {
			await i(t), m(t), w();
		} catch (e) {
			S(e instanceof Error ? e.message : "Could not save changes.");
		} finally {
			b(!1);
		}
	};
	return u ? /* @__PURE__ */ n("div", {
		className: `ds-inline-text-editor ${l}`.trim(),
		children: [
			/* @__PURE__ */ t("textarea", {
				autoFocus: !0,
				"aria-label": e,
				value: _,
				maxLength: c,
				rows: o ? 3 : 1,
				disabled: y,
				onChange: (e) => v(e.target.value),
				onKeyDown: (e) => {
					e.nativeEvent.isComposing || (e.key === "Escape" && !y && (e.preventDefault(), w()), e.key === "Enter" && !e.shiftKey && !o && (e.preventDefault(), T()));
				}
			}),
			/* @__PURE__ */ n("div", {
				className: "ds-inline-text-editor__actions",
				children: [/* @__PURE__ */ t(D, {
					size: "compact",
					onClick: () => void T(),
					busy: y,
					children: "Save"
				}), /* @__PURE__ */ t(D, {
					size: "compact",
					variant: "secondary",
					onClick: w,
					disabled: y,
					children: "Cancel"
				})]
			}),
			x && /* @__PURE__ */ t("p", {
				className: "ds-inline-text-editor__error",
				role: "alert",
				children: x
			})
		]
	}) : a ? /* @__PURE__ */ t("span", {
		className: `ds-inline-text-value ${l}`.trim(),
		children: p || "Not specified"
	}) : /* @__PURE__ */ t("button", {
		ref: C,
		type: "button",
		className: `ds-inline-text-value ${l}`.trim(),
		"aria-label": `Edit ${e.toLowerCase()}`,
		onClick: () => {
			v(p), f(!0);
		},
		children: p || "Not specified"
	});
}
//#endregion
//#region src/components/design-system/components/content/SelectionTile.tsx
function Z({ label: e, selected: i = !1, onChange: o, disabled: s = !1, caption: c, children: l, className: u = "", ...d }) {
	return /* @__PURE__ */ n("button", {
		...d,
		type: d.type ?? "button",
		className: `ds-selection-tile ${u}`.trim(),
		"aria-label": `${i ? "Deselect" : "Select"} ${e}`,
		"aria-pressed": i,
		disabled: s,
		onClick: o,
		children: [
			/* @__PURE__ */ t("span", {
				className: "ds-selection-tile__content",
				children: l
			}),
			/* @__PURE__ */ t("span", {
				className: "ds-selection-tile__action",
				"aria-hidden": "true",
				children: t(i ? r : a, { size: 20 })
			}),
			c && /* @__PURE__ */ t("span", {
				className: "ds-selection-tile__caption",
				children: c
			})
		]
	});
}
//#endregion
//#region src/components/design-system/components/data/BulkActionBar.tsx
function Q({ count: e, children: r, onClear: i, className: a = "" }) {
	return /* @__PURE__ */ n("section", {
		className: `ds-bulk-action-bar ${a}`.trim(),
		"aria-label": "Bulk actions",
		children: [/* @__PURE__ */ n("p", { children: [
			/* @__PURE__ */ t("strong", { children: e }),
			" ",
			e === 1 ? "item selected" : "items selected"
		] }), /* @__PURE__ */ n("div", {
			className: "ds-bulk-action-bar__actions",
			children: [r, /* @__PURE__ */ t("button", {
				type: "button",
				onClick: i,
				children: "Clear selection"
			})]
		})]
	});
}
//#endregion
//#region src/components/design-system/components/data/FilterToolbar.tsx
function Se({ query: e, onQueryChange: r, children: i, onClear: a, resultCount: o, searchLabel: s = "Search results", className: c = "" }) {
	return /* @__PURE__ */ n("section", {
		className: `ds-filter-toolbar ${c}`.trim(),
		"aria-label": "Filters",
		children: [/* @__PURE__ */ n("div", {
			className: "ds-filter-toolbar__controls",
			children: [
				/* @__PURE__ */ n("label", {
					className: "ds-filter-toolbar__search",
					children: [/* @__PURE__ */ t("span", { children: s }), /* @__PURE__ */ t("input", {
						type: "search",
						value: e,
						onChange: (e) => r(e.target.value)
					})]
				}),
				i,
				a && /* @__PURE__ */ t("button", {
					type: "button",
					className: "ds-filter-toolbar__clear",
					onClick: a,
					children: "Clear filters"
				})
			]
		}), o !== void 0 && /* @__PURE__ */ n("p", {
			className: "ds-filter-toolbar__count",
			role: "status",
			children: [
				o,
				" ",
				o === 1 ? "result" : "results"
			]
		})]
	});
}
//#endregion
//#region src/components/design-system/components/data/Table.tsx
function Ce({ checked: e, indeterminate: n, disabled: r, onChange: i }) {
	let a = h(null);
	return d(() => {
		a.current && (a.current.indeterminate = n);
	}, [n]), /* @__PURE__ */ t("input", {
		ref: a,
		type: "checkbox",
		"aria-label": "Select all rows",
		checked: e,
		disabled: r,
		onChange: i
	});
}
function $({ label: e, rows: r, columns: i, getRowId: a, sort: o, onSortChange: s, selectedIds: c, onSelectionChange: l, emptyMessage: u = "No rows to display.", className: d = "" }) {
	let f = c !== void 0 && l !== void 0, p = r.map(a), m = new Set(c), h = p.filter((e) => m.has(e)).length, g = p.length > 0 && h === p.length, _ = h > 0 && !g;
	function v(e) {
		let t = o?.columnId === e && o.direction === "asc" ? "desc" : "asc";
		s?.({
			columnId: e,
			direction: t
		});
	}
	function y() {
		if (!l) return;
		let e = new Set(p);
		if (g) {
			l((c ?? []).filter((t) => !e.has(t)));
			return;
		}
		l([.../* @__PURE__ */ new Set([...c ?? [], ...p])]);
	}
	function b(e) {
		l && l(m.has(e) ? (c ?? []).filter((t) => t !== e) : [...c ?? [], e]);
	}
	return /* @__PURE__ */ t("div", {
		className: `ds-table-scroll ${d}`.trim(),
		children: /* @__PURE__ */ n("table", {
			className: "ds-table",
			"aria-label": e,
			children: [
				/* @__PURE__ */ t("caption", { children: e }),
				/* @__PURE__ */ t("thead", { children: /* @__PURE__ */ n("tr", { children: [f && /* @__PURE__ */ t("th", {
					scope: "col",
					className: "ds-table__selection",
					children: /* @__PURE__ */ t(Ce, {
						checked: g,
						indeterminate: _,
						disabled: p.length === 0,
						onChange: y
					})
				}), i.map((e) => {
					let n = o?.columnId === e.id ? o?.direction === "asc" ? "ascending" : "descending" : e.sortable ? "none" : void 0;
					return /* @__PURE__ */ t("th", {
						scope: "col",
						className: e.className,
						"aria-sort": n,
						children: e.sortable ? /* @__PURE__ */ t("button", {
							type: "button",
							className: "ds-table__sort",
							onClick: () => v(e.id),
							"aria-label": `Sort by ${e.header}`,
							children: e.header
						}) : e.header
					}, e.id);
				})] }) }),
				/* @__PURE__ */ t("tbody", { children: r.length === 0 ? /* @__PURE__ */ t("tr", { children: /* @__PURE__ */ t("td", {
					colSpan: i.length + +!!f,
					className: "ds-table__empty",
					children: u
				}) }) : r.map((e) => {
					let r = a(e);
					return /* @__PURE__ */ n("tr", {
						"data-row-id": r,
						children: [f && /* @__PURE__ */ t("td", {
							className: "ds-table__selection",
							children: /* @__PURE__ */ t("input", {
								type: "checkbox",
								"aria-label": `Select row ${r}`,
								checked: m.has(r),
								onChange: () => b(r)
							})
						}), i.map((n) => /* @__PURE__ */ t("td", {
							className: n.className,
							children: n.cell(e)
						}, n.id))]
					}, r);
				}) })
			]
		})
	});
}
//#endregion
//#region src/components/design-system/ui-blocks/settings/SettingsForm.tsx
function we({ initialValue: e, onSave: r }) {
	let [i, a] = g(e), [o, s] = g(e), [c, l] = g(null), [u, d] = g(!1), f = (e, t) => a((n) => ({
		...n,
		[e]: t
	})), p = i.name.trim().length > 0, m = JSON.stringify(i) !== JSON.stringify(o);
	async function h(e) {
		if (e.preventDefault(), !p || u) return;
		d(!0), l(null);
		let t = await r(i);
		d(!1), t.ok ? s(i) : l(t.message);
	}
	return /* @__PURE__ */ n("form", {
		className: "ds-settings-form",
		onSubmit: h,
		children: [
			/* @__PURE__ */ n("div", {
				className: "ds-settings-form__field",
				children: [/* @__PURE__ */ t("label", {
					htmlFor: "settings-name",
					children: "Workspace name"
				}), /* @__PURE__ */ t("input", {
					id: "settings-name",
					value: i.name,
					onChange: (e) => f("name", e.target.value),
					"aria-invalid": !p || void 0
				})]
			}),
			/* @__PURE__ */ n("div", {
				className: "ds-settings-form__field",
				children: [/* @__PURE__ */ t("label", {
					htmlFor: "settings-language",
					children: "Language"
				}), /* @__PURE__ */ n("select", {
					id: "settings-language",
					value: i.language,
					onChange: (e) => f("language", e.target.value),
					children: [
						/* @__PURE__ */ t("option", { children: "English" }),
						/* @__PURE__ */ t("option", { children: "Deutsch" }),
						/* @__PURE__ */ t("option", { children: "Français" })
					]
				})]
			}),
			/* @__PURE__ */ n("label", {
				className: "ds-settings-form__check",
				children: [/* @__PURE__ */ t("input", {
					type: "checkbox",
					checked: i.notifications,
					onChange: (e) => f("notifications", e.target.checked)
				}), " Notifications"]
			}),
			c && /* @__PURE__ */ t("p", {
				role: "alert",
				children: c
			}),
			/* @__PURE__ */ n("footer", { children: [/* @__PURE__ */ t("button", {
				type: "button",
				onClick: () => {
					a(o), l(null);
				},
				disabled: !m || u,
				children: "Cancel"
			}), /* @__PURE__ */ t("button", {
				type: "submit",
				disabled: !p || !m || u,
				children: u ? "Saving…" : "Save settings"
			})] })
		]
	});
}
//#endregion
//#region src/components/design-system/ui-blocks/ai-workspace/AIWorkspace.tsx
function Te({ prompt: e, onPromptChange: r, state: i, message: a, result: o, attachments: s, onSubmit: c, onCancel: l, onRetry: u, onApply: d, onRevise: f, readOnly: p = !1 }) {
	let m = i === "running" || i === "waiting", h = i === "failed" ? "failed" : i === "ready" ? "succeeded" : i === "running" || i === "waiting" ? "running" : "queued";
	return /* @__PURE__ */ n("section", {
		className: "ds-ai-workspace",
		"aria-label": "AI workspace",
		children: [
			/* @__PURE__ */ n("div", {
				className: "ds-ai-workspace__prompt",
				children: [
					/* @__PURE__ */ t("label", {
						htmlFor: "ai-workspace-prompt",
						children: "Prompt"
					}),
					/* @__PURE__ */ t("textarea", {
						id: "ai-workspace-prompt",
						value: e,
						onChange: (e) => r(e.target.value),
						readOnly: p
					}),
					/* @__PURE__ */ t("div", { children: s }),
					/* @__PURE__ */ t("button", {
						type: "button",
						onClick: c,
						disabled: p || m || !e.trim(),
						children: "Run task"
					})
				]
			}),
			/* @__PURE__ */ t(J, {
				status: h,
				label: a
			}),
			m && l && /* @__PURE__ */ t("button", {
				type: "button",
				onClick: l,
				children: "Cancel"
			}),
			i === "failed" && u && /* @__PURE__ */ t("button", {
				type: "button",
				onClick: u,
				children: "Retry"
			}),
			o && /* @__PURE__ */ n("section", {
				className: "ds-ai-workspace__result",
				"aria-label": "Result",
				children: [
					/* @__PURE__ */ t("div", { children: o }),
					d && /* @__PURE__ */ t("button", {
						type: "button",
						onClick: d,
						disabled: m,
						children: "Apply"
					}),
					f && /* @__PURE__ */ t("button", {
						type: "button",
						onClick: f,
						disabled: m,
						children: "Revise"
					})
				]
			})
		]
	});
}
//#endregion
//#region src/components/design-system/ui-blocks/app-layout/AppLayout.tsx
function Ee({ navigation: e, header: r, children: i, inspector: a, feedback: o, className: s = "" }) {
	return /* @__PURE__ */ n("div", {
		className: `ds-app-layout ${s}`.trim(),
		children: [
			/* @__PURE__ */ t("aside", {
				className: "ds-app-layout__navigation",
				"aria-label": "Application navigation",
				children: e
			}),
			/* @__PURE__ */ n("div", {
				className: "ds-app-layout__main",
				children: [/* @__PURE__ */ t("header", {
					className: "ds-app-layout__header",
					children: r
				}), /* @__PURE__ */ t("main", {
					className: "ds-app-layout__content",
					children: i
				})]
			}),
			a && /* @__PURE__ */ t("aside", {
				className: "ds-app-layout__inspector",
				"aria-label": "Inspector",
				children: a
			}),
			o && /* @__PURE__ */ t("div", {
				className: "ds-app-layout__feedback",
				children: o
			})
		]
	});
}
//#endregion
//#region src/components/design-system/ui-blocks/item-browser/ItemBrowser.tsx
var De = [{
	value: "list",
	label: "List"
}, {
	value: "grid",
	label: "Grid"
}];
function Oe({ items: r, total: i, query: a, onQueryChange: o, page: s, pageCount: c, onPageChange: l, view: u, onViewChange: d, selectedIds: f, onSelectionChange: p, loading: m = !1, error: h, onRetry: g, onOpen: _, bulkActions: v, className: y = "" }) {
	let b = a ? `No items match “${a}”.` : "Your library is empty.", x = new Set(f), S = (e) => p(x.has(e) ? f.filter((t) => t !== e) : [...f, e]);
	return /* @__PURE__ */ n("section", {
		className: `ds-item-browser ${y}`.trim(),
		"aria-label": "Items",
		children: [
			/* @__PURE__ */ n("div", {
				className: "ds-item-browser__toolbar",
				children: [/* @__PURE__ */ t(j, {
					type: "search",
					label: "Search items",
					value: a,
					onChange: (e) => o(e.target.value)
				}), /* @__PURE__ */ t(N, {
					ariaLabel: "View items as",
					options: De,
					value: u,
					onValueChange: (e) => d(e)
				})]
			}),
			v && f.length > 0 && /* @__PURE__ */ t("div", {
				className: "ds-item-browser__bulk-actions",
				children: v
			}),
			h && /* @__PURE__ */ t(W, {
				title: h,
				description: r.length ? "Showing the most recently available items." : void 0,
				actionLabel: g ? "Try again" : void 0,
				onAction: g
			}),
			m && r.length === 0 ? /* @__PURE__ */ t("p", {
				className: "ds-item-browser__message",
				role: "status",
				children: "Loading items…"
			}) : r.length === 0 ? /* @__PURE__ */ t("p", {
				className: "ds-item-browser__message",
				children: b
			}) : u === "list" ? /* @__PURE__ */ t($, {
				label: "Items",
				rows: r,
				getRowId: (e) => e.id,
				selectedIds: f,
				onSelectionChange: p,
				columns: [
					{
						id: "title",
						header: "Title",
						cell: (r) => /* @__PURE__ */ n(e, { children: [/* @__PURE__ */ t("strong", { children: r.title }), r.description && /* @__PURE__ */ t("span", {
							className: "ds-item-browser__description",
							children: r.description
						})] })
					},
					{
						id: "status",
						header: "Status",
						cell: (e) => e.status ?? "—"
					},
					{
						id: "open",
						header: "Open",
						cell: (e) => /* @__PURE__ */ t(D, {
							size: "compact",
							variant: "quiet",
							onClick: () => _(e.id),
							children: "Open"
						})
					}
				]
			}) : /* @__PURE__ */ t("div", {
				className: "ds-item-browser__grid",
				children: r.map((e) => /* @__PURE__ */ n("div", {
					className: "ds-item-browser__grid-item",
					children: [/* @__PURE__ */ n(Z, {
						label: e.title,
						selected: x.has(e.id),
						onChange: () => S(e.id),
						caption: e.status,
						children: [/* @__PURE__ */ t("strong", { children: e.title }), e.description && /* @__PURE__ */ t("span", { children: e.description })]
					}), /* @__PURE__ */ n(D, {
						size: "compact",
						variant: "quiet",
						onClick: () => _(e.id),
						children: ["Open ", e.title]
					})]
				}, e.id))
			}),
			/* @__PURE__ */ n("footer", {
				className: "ds-item-browser__footer",
				children: [/* @__PURE__ */ n("span", { children: [
					i,
					" ",
					i === 1 ? "item" : "items"
				] }), /* @__PURE__ */ t(M, {
					page: s,
					pageCount: c,
					onPageChange: l
				})]
			})
		]
	});
}
//#endregion
//#region src/components/design-system/ui-blocks/item-detail/ItemDetail.tsx
function ke({ item: e, onSave: r, metadata: i, preview: a, actions: o, readOnly: s = !1, className: c = "" }) {
	let l = h(e.revision);
	return /* @__PURE__ */ n("article", {
		className: `ds-item-detail ${c}`.trim(),
		"aria-labelledby": `item-detail-${e.id}`,
		children: [
			/* @__PURE__ */ n("header", {
				className: "ds-item-detail__header",
				children: [/* @__PURE__ */ n("div", { children: [/* @__PURE__ */ t("p", {
					className: "ds-item-detail__eyebrow",
					children: "Item detail"
				}), /* @__PURE__ */ t("h1", {
					id: `item-detail-${e.id}`,
					children: e.title
				})] }), o && /* @__PURE__ */ t("div", {
					className: "ds-item-detail__actions",
					children: o
				})]
			}),
			/* @__PURE__ */ n("section", {
				className: "ds-item-detail__body",
				"aria-label": "Item content",
				children: [/* @__PURE__ */ n("div", {
					className: "ds-item-detail__copy",
					children: [/* @__PURE__ */ t(X, {
						label: "Title",
						value: e.title,
						onSave: async (e) => {
							let t = await r({ title: e }, l.current);
							if (!t.ok) throw Error(t.message);
						},
						readOnly: s,
						required: !0
					}), /* @__PURE__ */ t(X, {
						label: "Description",
						value: e.description,
						onSave: async (e) => {
							let t = await r({ description: e }, l.current);
							if (!t.ok) throw Error(t.message);
						},
						readOnly: s,
						multiline: !0
					})]
				}), a && /* @__PURE__ */ t("section", {
					className: "ds-item-detail__preview",
					"aria-label": "Preview",
					children: a
				})]
			}),
			/* @__PURE__ */ n("aside", {
				className: "ds-item-detail__metadata",
				"aria-label": "Item metadata",
				children: [/* @__PURE__ */ t(Y, {
					label: "Item facts",
					items: [{
						id: "revision",
						label: "Revision",
						value: e.revision
					}]
				}), i]
			})
		]
	});
}
function Ae({ item: e, loading: r = !1, error: i, onRetry: a, onSave: o, metadata: s, preview: c, actions: l, readOnly: u, className: d = "" }) {
	return r ? /* @__PURE__ */ n("section", {
		className: `ds-item-detail ds-item-detail--loading ${d}`.trim(),
		"aria-label": "Loading item",
		children: [/* @__PURE__ */ t("p", {
			role: "status",
			children: "Loading item…"
		}), /* @__PURE__ */ t(K, { lines: 4 })]
	}) : i ? /* @__PURE__ */ t(W, {
		title: i,
		actionLabel: a ? "Try again" : void 0,
		onAction: a,
		className: d
	}) : e ? /* @__PURE__ */ t(ke, {
		item: e,
		onSave: o,
		metadata: s,
		preview: c,
		actions: l,
		readOnly: u,
		className: d
	}, e.id) : /* @__PURE__ */ t("section", {
		className: `ds-item-detail ds-item-detail--empty ${d}`.trim(),
		children: /* @__PURE__ */ t("p", { children: "No item selected." })
	});
}
//#endregion
export { be as AIResult, J as AITaskStatus, Te as AIWorkspace, xe as ActionCard, fe as Alert, D as AppButton, Ee as AppLayout, le as Breadcrumbs, Q as BulkActionBar, ie as CheckboxField, U as Combobox, S as Container, x as DesignSystemRoot, R as Dialog, C as Divider, z as Drawer, W as ErrorState, Y as FactGrid, ge as FileDropzone, ve as FileList, Se as FilterToolbar, T as Grid, ee as Inline, X as InlineText, Oe as ItemBrowser, Ae as ItemDetail, H as Menu, de as MultiSelect, M as Pagination, B as Popover, G as Progress, ae as RadioGroup, te as ScrollArea, N as SegmentedControl, oe as SelectField, Z as SelectionTile, we as SettingsForm, K as Skeleton, E as Stack, pe as StatusBadge, ue as Stepper, ne as Surface, se as SwitchField, I as TabPanel, $ as Table, F as Tabs, re as TextAction, ce as TextArea, j as TextField, me as ToastProvider, V as Tooltip, he as useToast };
