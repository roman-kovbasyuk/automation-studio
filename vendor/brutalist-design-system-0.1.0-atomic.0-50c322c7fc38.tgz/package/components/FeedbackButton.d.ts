import { type Ref } from 'react';
import { type ButtonProps } from './Button';
import type { IconName } from '../atoms';
export type FeedbackButtonProps = Omit<ButtonProps, 'children' | 'icon' | 'iconOnly' | 'onClick' | 'aria-label'> & {
    label: string;
    successLabel: string;
    icon?: IconName;
    successIcon?: IconName;
    onAction: () => void | Promise<void>;
    onError?: (error: unknown) => void;
    resetKey?: string | number;
    'aria-label'?: string;
    successAriaLabel?: string;
    ref?: Ref<HTMLButtonElement>;
};
/** Shared action button that exposes completion in its own label and icon. */
export declare function FeedbackButton({ label, successLabel, icon, successIcon, onAction, onError, resetKey, successAriaLabel, 'aria-label': ariaLabel, disabled, busy, ref, ...props }: FeedbackButtonProps): import("react").JSX.Element;
