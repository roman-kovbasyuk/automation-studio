import { Fragment as e, jsx as t, jsxs as n } from "react/jsx-runtime";
import { ArrowDown as r, ArrowLeft as i, ArrowRight as a, ArrowUp as o, CalendarDays as s, Check as c, ChevronDown as l, ChevronRight as u, CircleAlert as d, Clock as f, Copy as p, Download as m, Ellipsis as h, ExternalLink as g, Eye as _, File as v, Folder as y, Image as b, Info as x, LoaderCircle as S, Menu as C, Minus as w, Pencil as T, Plus as E, Search as D, Settings as O, Star as k, Trash2 as ee, Upload as A, X as j, icons as te } from "lucide-react";
import { useEffect as ne, useId as M, useLayoutEffect as re, useRef as N, useState as P } from "react";
import { Dialog as F, DropdownMenu as I, Popover as L, Select as R, Tabs as z, Tooltip as B } from "radix-ui";
//#region src/atomic/atoms/tokens.ts
var ie = {
	color: {
		canvas: "#f4f4f0",
		surface: "#ffffff",
		ink: "#000000",
		secondary: "#595959",
		accent: "#79d9ff",
		success: "#23a094",
		danger: "#dc341e",
		editHighlight: "rgb(0 0 0 / 3%)",
		backdrop: "rgb(0 0 0 / 35%)"
	},
	space: {
		0: "0px",
		1: "4px",
		2: "8px",
		3: "12px",
		4: "16px",
		6: "24px",
		8: "32px",
		12: "48px",
		16: "64px"
	},
	radius: {
		none: "0px",
		small: "4px",
		large: "20px",
		pill: "999px"
	},
	border: { width: "1px" },
	size: {
		control: "48px",
		compact: "44px",
		small: "32px",
		choice: "20px",
		marker: "10px",
		switchHeight: "28px"
	},
	icon: {
		small: "16px",
		medium: "20px",
		large: "24px",
		xlarge: "32px",
		display: "48px"
	},
	shadow: {
		none: "none",
		small: "2px 2px 0 var(--a-color-ink)",
		interactive: "4px 4px 0 var(--a-color-ink)",
		floating: "8px 8px 0 var(--a-color-ink)"
	},
	motion: {
		fast: "150ms",
		disclosure: "200ms",
		ease: "cubic-bezier(0.4, 0, 0.2, 1)",
		out: "cubic-bezier(0.22, 1, 0.36, 1)",
		lift: "-2px",
		liftStrong: "-4px",
		spin: "1s"
	},
	state: { disabled: "0.45" },
	focus: {
		width: "2px",
		offset: "4px"
	},
	layer: {
		base: "0",
		popover: "20",
		modal: "40",
		toast: "60"
	},
	font: { family: "\"Avenir Next\", Avenir, Montserrat, Corbel, \"URW Gothic\", sans-serif" }
}, ae = {
	h1: {
		size: "48px",
		line: "52px",
		weight: 500
	},
	h2: {
		size: "32px",
		line: "36px",
		weight: 500
	},
	h3: {
		size: "24px",
		line: "28px",
		weight: 500
	},
	h4: {
		size: "20px",
		line: "24px",
		weight: 500
	},
	h5: {
		size: "18px",
		line: "24px",
		weight: 600
	},
	h6: {
		size: "16px",
		line: "22px",
		weight: 600
	},
	h7: {
		size: "14px",
		line: "20px",
		weight: 600
	},
	leadLarge: {
		size: "24px",
		line: "36px",
		weight: 500
	},
	leadMedium: {
		size: "20px",
		line: "28px",
		weight: 500
	},
	body: {
		size: "16px",
		line: "22px",
		weight: 400
	},
	small: {
		size: "14px",
		line: "20px",
		weight: 400
	}
}, oe = Object.fromEntries([...Object.entries(ie).flatMap(([e, t]) => Object.entries(t).map(([t, n]) => [`--a-${e}-${t}`, n])), ...Object.entries(ae).flatMap(([e, t]) => Object.entries(t).map(([t, n]) => [`--a-type-${e}-${t}`, String(n)]))]), se = (e) => ({
	fontSize: `var(--a-type-${e}-size)`,
	lineHeight: `var(--a-type-${e}-line)`,
	fontWeight: `var(--a-type-${e}-weight)`
});
//#endregion
//#region src/atomic/atoms/typography.tsx
function V({ className: e = "", style: n, ...r }) {
	return /* @__PURE__ */ t("div", {
		...r,
		className: `atomic-root ${e}`.trim(),
		style: {
			...oe,
			...n
		}
	});
}
function H({ level: e, variant: n = `h${e}`, className: r = "", style: i, ...a }) {
	let o = `h${e}`;
	return /* @__PURE__ */ t(o, {
		...a,
		className: `a-type ${r}`.trim(),
		"data-type": n,
		style: {
			...se(n),
			...i
		}
	});
}
function U({ as: e = "p", variant: n = "body", tone: r = "ink", className: i = "", style: a, ...o }) {
	return /* @__PURE__ */ t(e, {
		...o,
		className: `a-type ${i}`.trim(),
		"data-type": n,
		style: {
			...se(n),
			color: r === "inherit" ? "inherit" : `var(--a-color-${r})`,
			...a
		}
	});
}
//#endregion
//#region src/atomic/atoms/Icon.tsx
var ce = {
	...te,
	calendar: s,
	arrowUp: o,
	arrowDown: r,
	search: D,
	plus: E,
	minus: w,
	star: k,
	clock: f,
	check: c,
	close: j,
	arrowLeft: i,
	arrowRight: a,
	chevronDown: l,
	chevronRight: u,
	copy: p,
	download: m,
	upload: A,
	delete: ee,
	edit: T,
	settings: O,
	menu: C,
	more: h,
	eye: _,
	info: x,
	alert: d,
	loading: S,
	image: b,
	file: v,
	folder: y,
	externalLink: g
};
function W({ name: e, size: n = "medium", label: r, className: i = "" }) {
	let a = ce[e];
	return /* @__PURE__ */ t(a, {
		className: `a-icon ${i}`.trim(),
		"data-icon": e,
		style: { "--icon-size": `var(--a-icon-${n})` },
		strokeWidth: 1.5,
		role: r ? "img" : void 0,
		"aria-label": r || void 0,
		"aria-hidden": !r || void 0,
		focusable: "false"
	});
}
//#endregion
//#region src/atomic/atoms/layout.tsx
var le = (e) => ({ "--layout-gap": `var(--a-space-${e})` });
function G({ gap: e = 4, className: n = "", style: r, ...i }) {
	return /* @__PURE__ */ t("div", {
		...i,
		className: `a-stack ${n}`.trim(),
		style: {
			...le(e),
			...r
		}
	});
}
function K({ gap: e = 2, className: n = "", style: r, ...i }) {
	return /* @__PURE__ */ t("div", {
		...i,
		className: `a-inline ${n}`.trim(),
		style: {
			...le(e),
			...r
		}
	});
}
function ue({ gap: e = 4, minItemWidth: n = "16rem", className: r = "", style: i, ...a }) {
	return /* @__PURE__ */ t("div", {
		...a,
		className: `a-grid ${r}`.trim(),
		style: {
			...le(e),
			"--grid-min": n,
			...i
		}
	});
}
function de({ className: e = "", style: n, maxWidth: r = "72rem", ...i }) {
	return /* @__PURE__ */ t("div", {
		...i,
		className: `a-container ${e}`.trim(),
		style: {
			maxWidth: r,
			...n
		}
	});
}
function q({ as: e = "div", padding: n = 8, radius: r = "large", elevation: i = "none", tone: a = "surface", className: o = "", style: s, ...c }) {
	return /* @__PURE__ */ t(e, {
		...c,
		className: `a-surface ${o}`.trim(),
		style: {
			padding: `var(--a-space-${n})`,
			borderRadius: `var(--a-radius-${r})`,
			"--surface-elevation": `var(--a-shadow-${i})`,
			background: `var(--a-color-${a})`,
			...s
		}
	});
}
function fe(e) {
	return /* @__PURE__ */ t("hr", {
		...e,
		className: `a-divider ${e.className ?? ""}`.trim()
	});
}
function pe({ label: e, className: n = "", style: r, maxHeight: i = "16rem", ...a }) {
	return /* @__PURE__ */ t("div", {
		...a,
		className: `a-scroll ${n}`.trim(),
		style: {
			maxHeight: i,
			...r
		},
		role: "region",
		"aria-label": e,
		tabIndex: 0
	});
}
//#endregion
//#region src/atomic/components/Button.tsx
function J({ children: e, icon: r, iconOnly: i = !1, iconPosition: a = "start", variant: o = "secondary", size: s = "default", busy: c = !1, disabled: l = !1, type: u = "button", className: d = "", ...f }) {
	let p = c ? /* @__PURE__ */ t(W, {
		name: "loading",
		className: "c-button__spinner"
	}) : r ? /* @__PURE__ */ t(W, { name: r }) : null;
	return /* @__PURE__ */ n("button", {
		...f,
		type: u,
		disabled: l || c,
		"aria-busy": c || void 0,
		className: `c-button ${d}`.trim(),
		"data-variant": o,
		"data-size": s,
		"data-icon-only": i || void 0,
		children: [
			a === "start" && p,
			!i && /* @__PURE__ */ t(U, {
				as: "span",
				variant: "h6",
				tone: "inherit",
				children: e
			}),
			a === "end" && p
		]
	});
}
//#endregion
//#region src/atomic/components/Panel.tsx
function me({ title: e, description: r, headingLevel: i = 3, variant: a = "default", filters: o, as: s = "section", children: c, className: l = "", ...u }) {
	let d = M(), f = /* @__PURE__ */ n(G, {
		gap: 1,
		children: [/* @__PURE__ */ t(H, {
			id: d,
			level: i,
			variant: "h4",
			children: e
		}), r != null && /* @__PURE__ */ t(U, {
			tone: "secondary",
			children: r
		})]
	});
	return a === "split" ? /* @__PURE__ */ n(q, {
		...u,
		as: s,
		padding: 0,
		className: `c-panel c-panel--split ${l}`.trim(),
		"aria-labelledby": d,
		children: [/* @__PURE__ */ t("header", {
			className: "c-panel__header",
			children: /* @__PURE__ */ n(G, {
				gap: 6,
				children: [f, o]
			})
		}), c != null && /* @__PURE__ */ t("div", {
			className: "c-panel__content",
			children: /* @__PURE__ */ t(G, {
				gap: 6,
				children: c
			})
		})]
	}) : /* @__PURE__ */ t(q, {
		...u,
		as: s,
		className: `c-panel ${l}`.trim(),
		"aria-labelledby": d,
		children: /* @__PURE__ */ n(G, {
			gap: 6,
			children: [
				f,
				o,
				c
			]
		})
	});
}
//#endregion
//#region src/atomic/components/FieldSupport.tsx
var Y = (e) => e != null && e !== !1 && e !== "", X = (e, t, n, r) => [
	r,
	Y(t) && `${e}-hint`,
	Y(n) && `${e}-error`
].filter(Boolean).join(" ") || void 0;
function Z({ id: r, instructions: i, error: a }) {
	return /* @__PURE__ */ n(e, { children: [Y(i) && /* @__PURE__ */ t(U, {
		id: `${r}-hint`,
		variant: "small",
		tone: "secondary",
		children: i
	}), Y(a) && /* @__PURE__ */ t(U, {
		id: `${r}-error`,
		variant: "small",
		role: "alert",
		className: "c-field-error",
		tone: "inherit",
		children: a
	})] });
}
//#endregion
//#region src/atomic/components/TextField.tsx
function Q({ label: e, instructions: r, error: i, id: a, className: o = "", type: s = "text", width: c = [
	"number",
	"time",
	"date",
	"color"
].includes(s) ? "content" : "full", onChange: l, "aria-describedby": u, "aria-invalid": d, ...f }) {
	let p = M(), m = a ?? p, [h, g] = P(String(f.defaultValue ?? "").length), _ = Math.max(s === "time" ? 10 : s === "date" ? 12 : 4, f.value == null ? h : String(f.value).length, f.placeholder?.length ?? 0);
	return /* @__PURE__ */ n(G, {
		gap: 2,
		className: `c-field${c === "content" ? " c-field--content" : ""}`,
		style: { "--field-characters": _ + 2 },
		children: [
			/* @__PURE__ */ t("label", {
				htmlFor: m,
				children: /* @__PURE__ */ t(U, {
					as: "span",
					variant: "h7",
					children: e
				})
			}),
			/* @__PURE__ */ t("input", {
				...f,
				onChange: (e) => {
					g(e.target.value.length), l?.(e);
				},
				id: m,
				type: s,
				className: `c-text-input ${o}`.trim(),
				"aria-describedby": X(m, r, i, u),
				"aria-invalid": Y(i) || d || void 0
			}),
			/* @__PURE__ */ t(Z, {
				id: m,
				instructions: r,
				error: i
			})
		]
	});
}
//#endregion
//#region src/atomic/components/Checkbox.tsx
function he({ label: e, instructions: r, error: i, indeterminate: a = !1, id: o, checked: s, defaultChecked: c, className: l = "", "aria-describedby": u, "aria-invalid": d, ...f }) {
	let p = M(), m = o ?? p, h = N(null);
	return ne(() => {
		h.current && (h.current.indeterminate = a);
	}, [a]), /* @__PURE__ */ n(G, {
		gap: 1,
		children: [/* @__PURE__ */ n("label", {
			className: "c-choice-row",
			htmlFor: m,
			children: [/* @__PURE__ */ n("span", {
				className: "c-check-control",
				children: [/* @__PURE__ */ t("input", {
					...f,
					...s === void 0 ? { defaultChecked: c } : { checked: s },
					ref: h,
					id: m,
					type: "checkbox",
					className: `c-checkbox ${l}`.trim(),
					"aria-describedby": X(m, r, i, u),
					"aria-invalid": Y(i) || d || void 0
				}), /* @__PURE__ */ t("span", {
					className: "c-choice-mark",
					"aria-hidden": "true",
					children: /* @__PURE__ */ t(W, {
						name: "check",
						size: "small"
					})
				})]
			}), /* @__PURE__ */ t(U, {
				as: "span",
				children: e
			})]
		}), /* @__PURE__ */ t(Z, {
			id: m,
			instructions: r,
			error: i
		})]
	});
}
//#endregion
//#region src/atomic/components/RadioGroup.tsx
function ge({ id: e, name: r, label: i, instructions: a, error: o, options: s, value: c, defaultValue: l, onChange: u, disabled: d = !1, required: f, className: p = "", customOption: m }) {
	let h = M(), g = e ?? h, _ = r ?? h, [v, y] = P(l), b = c ?? v, x = m ? [...s, m] : s;
	return /* @__PURE__ */ n("fieldset", {
		id: g,
		disabled: d,
		className: `c-radio-group ${p}`.trim(),
		"aria-describedby": X(g, a, o),
		"aria-invalid": Y(o) || void 0,
		children: [/* @__PURE__ */ t("legend", { children: /* @__PURE__ */ t(U, {
			as: "span",
			variant: "h7",
			children: i
		}) }), /* @__PURE__ */ n(G, {
			gap: 2,
			children: [
				/* @__PURE__ */ t(Z, {
					id: g,
					instructions: a
				}),
				/* @__PURE__ */ t(G, {
					gap: 0,
					children: x.map((e, r) => /* @__PURE__ */ n("label", {
						className: "c-choice-row",
						htmlFor: `${g}-${r}`,
						children: [/* @__PURE__ */ t("input", {
							type: "radio",
							id: `${g}-${r}`,
							name: _,
							value: e.value,
							className: "c-radio",
							checked: b === e.value,
							disabled: e.disabled,
							required: f,
							"aria-describedby": X(g, a, o),
							"aria-invalid": Y(o) || void 0,
							onChange: () => {
								y(e.value), u?.(e.value);
							}
						}), /* @__PURE__ */ t(U, {
							as: "span",
							children: e.label
						})]
					}, e.value))
				}),
				m && /* @__PURE__ */ t(Q, {
					label: `${m.label} answer`,
					name: r ? `${r}Custom` : void 0,
					value: m.text,
					onChange: (e) => m.onTextChange(e.target.value),
					placeholder: m.placeholder,
					disabled: d || b !== m.value,
					required: f && b === m.value
				}),
				/* @__PURE__ */ t(Z, {
					id: g,
					error: o
				})
			]
		})]
	});
}
//#endregion
//#region src/atomic/components/Toggle.tsx
function _e({ label: e, instructions: r, error: i, id: a, checked: o, defaultChecked: s, className: c = "", "aria-describedby": l, "aria-invalid": u, ...d }) {
	let f = M(), p = a ?? f;
	return /* @__PURE__ */ n(G, {
		gap: 1,
		children: [/* @__PURE__ */ n("label", {
			htmlFor: p,
			className: "c-choice-row",
			children: [/* @__PURE__ */ t("input", {
				...d,
				...o === void 0 ? { defaultChecked: s } : { checked: o },
				type: "checkbox",
				role: "switch",
				id: p,
				className: `c-toggle ${c}`.trim(),
				"aria-describedby": X(p, r, i, l),
				"aria-invalid": Y(i) || u || void 0
			}), /* @__PURE__ */ t(U, {
				as: "span",
				children: e
			})]
		}), /* @__PURE__ */ t(Z, {
			id: p,
			instructions: r,
			error: i
		})]
	});
}
//#endregion
//#region src/atomic/components/TextArea.tsx
function ve(e) {
	let t = getComputedStyle(e), n = (e) => parseFloat(e) || 0, r = n(t.borderTopWidth) + n(t.borderBottomWidth), i = e.rows * n(t.lineHeight) + n(t.paddingTop) + n(t.paddingBottom) + r;
	e.style.height = "0px", e.style.height = `${Math.max(i, e.scrollHeight + r)}px`;
}
function ye({ label: e, embedded: r = !1, hideLabel: i = !1, instructions: a, error: o, id: s, rows: c = 3, className: l = "", onInput: u, "aria-describedby": d, "aria-invalid": f, ...p }) {
	let m = M(), h = s ?? m, g = N(null);
	return re(() => {
		g.current && ve(g.current);
	}), re(() => {
		let e = g.current;
		if (!e || typeof ResizeObserver > "u") return;
		let t = e.getBoundingClientRect().width, n = new ResizeObserver(() => {
			let n = e.getBoundingClientRect().width;
			n !== t && (t = n, ve(e));
		});
		return n.observe(e), () => n.disconnect();
	}, []), /* @__PURE__ */ n(G, {
		gap: 2,
		className: "c-field",
		children: [
			/* @__PURE__ */ t("label", {
				htmlFor: h,
				className: i ? "c-field-label-hidden" : void 0,
				children: /* @__PURE__ */ t(U, {
					as: "span",
					variant: "h7",
					children: e
				})
			}),
			/* @__PURE__ */ t("textarea", {
				...p,
				ref: g,
				id: h,
				rows: c,
				className: `c-text-input c-textarea ${r ? "c-textarea--embedded" : ""} ${l}`.trim(),
				"aria-describedby": X(h, a, o, d),
				"aria-invalid": Y(o) || f || void 0,
				onInput: (e) => {
					ve(e.currentTarget), u?.(e);
				}
			}),
			/* @__PURE__ */ t(Z, {
				id: h,
				instructions: a,
				error: o
			})
		]
	});
}
//#endregion
//#region src/atomic/components/Select.tsx
function be({ label: e, options: r, placeholder: i, value: a, defaultValue: o, instructions: s, error: c, id: l, className: u = "", disabled: d, name: f, required: p, onChange: m, onValueChange: h, customOption: g, "aria-describedby": _, "aria-invalid": v }) {
	let y = M(), b = l ?? y, x = N(null), [S, C] = P(o ?? (i ? "" : r.find((e) => !e.disabled)?.value ?? "")), w = a ?? S, T = g ? [...r, g] : r, E = (e) => {
		if (C(e), h?.(e), x.current && m) {
			x.current.value = e;
			let t = new Event("change", { bubbles: !0 });
			m({
				target: x.current,
				currentTarget: x.current,
				nativeEvent: t,
				type: "change",
				bubbles: !0,
				cancelable: !1,
				defaultPrevented: !1,
				eventPhase: 3,
				isTrusted: !1,
				timeStamp: t.timeStamp,
				persist() {},
				isDefaultPrevented: () => !1,
				isPropagationStopped: () => !1,
				preventDefault: () => t.preventDefault(),
				stopPropagation: () => t.stopPropagation()
			});
		}
	};
	return /* @__PURE__ */ n(G, {
		gap: 2,
		className: "c-field",
		children: [
			/* @__PURE__ */ t("label", {
				id: `${b}-label`,
				htmlFor: b,
				children: /* @__PURE__ */ t(U, {
					as: "span",
					variant: "h7",
					children: e
				})
			}),
			/* @__PURE__ */ n(R.Root, {
				value: w,
				onValueChange: E,
				disabled: d,
				children: [/* @__PURE__ */ n(R.Trigger, {
					id: b,
					className: `c-text-input c-select-trigger ${u}`,
					"aria-labelledby": `${b}-label`,
					"aria-describedby": X(b, s, c, _),
					"aria-invalid": Y(c) || v || void 0,
					"aria-required": p,
					children: [/* @__PURE__ */ t(R.Value, { placeholder: i }), /* @__PURE__ */ t(R.Icon, {
						asChild: !0,
						children: /* @__PURE__ */ t(W, {
							name: "chevronDown",
							size: "small"
						})
					})]
				}), /* @__PURE__ */ t(R.Portal, { children: /* @__PURE__ */ t(V, {
					className: "c-overlay-root",
					children: /* @__PURE__ */ t(R.Content, {
						className: "c-dropdown-popup",
						position: "popper",
						sideOffset: 8,
						collisionPadding: 16,
						children: /* @__PURE__ */ t(R.Viewport, { children: T.map((e) => /* @__PURE__ */ n(R.Item, {
							value: e.value,
							disabled: "disabled" in e && e.disabled,
							className: "c-dropdown-option",
							children: [/* @__PURE__ */ n(K, {
								gap: 2,
								children: ["icon" in e && e.icon && /* @__PURE__ */ t(W, {
									name: e.icon,
									size: "small"
								}), /* @__PURE__ */ t(R.ItemText, { children: e.label })]
							}), /* @__PURE__ */ t(R.ItemIndicator, { children: /* @__PURE__ */ t(W, {
								name: "check",
								size: "small"
							}) })]
						}, e.value)) })
					})
				}) })]
			}),
			/* @__PURE__ */ n("select", {
				ref: x,
				name: f,
				value: w,
				onChange: (e) => E(e.target.value),
				disabled: d,
				required: p,
				tabIndex: -1,
				"aria-hidden": "true",
				className: "c-select-native",
				onInvalid: (e) => {
					e.preventDefault(), document.getElementById(b)?.focus();
				},
				children: [/* @__PURE__ */ t("option", { value: "" }), T.map((e) => /* @__PURE__ */ t("option", {
					value: e.value,
					disabled: "disabled" in e && e.disabled,
					children: e.label
				}, e.value))]
			}),
			g && w === g.value && /* @__PURE__ */ t(Q, {
				label: `${g.label} answer`,
				value: g.text,
				onChange: (e) => g.onTextChange(e.target.value),
				disabled: d,
				required: p,
				name: f ? `${f}Custom` : void 0
			}),
			/* @__PURE__ */ t(Z, {
				id: b,
				instructions: s,
				error: c
			})
		]
	});
}
//#endregion
//#region src/atomic/components/Tag.tsx
function xe({ children: e, tone: r = "neutral", icon: i, status: a, onRemove: o, removeLabel: s, className: c = "", ...l }) {
	return a && (r = a === "pending" ? "accent" : a, i ??= a === "pending" ? "clock" : a === "success" ? "check" : a === "danger" ? "alert" : "info"), /* @__PURE__ */ t("span", {
		...l,
		className: `c-tag-wrap ${c}`.trim(),
		children: /* @__PURE__ */ n("span", {
			className: "c-tag",
			"data-tone": r,
			children: [
				i && /* @__PURE__ */ t(W, {
					name: i,
					size: "small"
				}),
				/* @__PURE__ */ t(U, {
					as: "span",
					variant: "small",
					tone: "inherit",
					children: e
				}),
				o && /* @__PURE__ */ t("button", {
					type: "button",
					className: "c-tag__remove",
					"aria-label": s,
					onClick: o,
					children: /* @__PURE__ */ t(W, {
						name: "close",
						size: "small"
					})
				})
			]
		})
	});
}
//#endregion
//#region src/atomic/components/SegmentedControl.tsx
function Se({ label: e, options: r, value: i, defaultValue: a, onChange: o, name: s, disabled: c = !1, className: l = "", style: u, ...d }) {
	let [f, p] = P(a ?? r.find((e) => !e.disabled)?.value), m = i === void 0 ? f : i, h = r.findIndex((e) => e.value === m), g = r.map((e, t) => e.disabled ? -1 : t).filter((e) => e >= 0), _ = g.includes(h) ? h : g[0], v = N([]);
	function y(e) {
		let t = r[e];
		c || !t || t.disabled || (i === void 0 && p(t.value), o?.(t.value));
	}
	function b(e, t) {
		if (![
			"ArrowRight",
			"ArrowLeft",
			"ArrowDown",
			"ArrowUp",
			"Home",
			"End"
		].includes(e.key) || c || !g.length) return;
		e.preventDefault();
		let n = getComputedStyle(e.currentTarget).direction === "rtl", r = e.key === "ArrowDown" || e.key === (n ? "ArrowLeft" : "ArrowRight"), i = g.indexOf(t), a = e.key === "Home" ? g[0] : e.key === "End" ? g[g.length - 1] : g[(i + (r ? 1 : -1) + g.length) % g.length];
		y(a), v.current[a]?.focus(), v.current[a]?.scrollIntoView?.({
			block: "nearest",
			inline: "nearest"
		});
	}
	return /* @__PURE__ */ t(pe, {
		label: `${e} options`,
		maxHeight: "none",
		className: "c-segmented-scroll",
		children: /* @__PURE__ */ n("div", {
			...d,
			role: "radiogroup",
			"aria-label": e,
			"aria-disabled": c || void 0,
			className: `c-segmented ${l}`.trim(),
			style: {
				"--segment-count": Math.max(1, r.length),
				"--segment-index": h,
				...u
			},
			children: [
				h >= 0 && /* @__PURE__ */ t("span", {
					className: "c-segmented__indicator",
					"aria-hidden": "true"
				}),
				r.map((e, n) => /* @__PURE__ */ t("button", {
					ref: (e) => {
						v.current[n] = e;
					},
					type: "button",
					role: "radio",
					"aria-checked": n === h,
					disabled: c || e.disabled,
					tabIndex: !c && n === _ ? 0 : -1,
					className: "c-segmented__option",
					onClick: () => y(n),
					onKeyDown: (e) => b(e, n),
					children: /* @__PURE__ */ t(U, {
						as: "span",
						variant: "h6",
						tone: "inherit",
						children: e.label
					})
				}, e.value)),
				s && h >= 0 && /* @__PURE__ */ t("input", {
					type: "hidden",
					name: s,
					value: m,
					disabled: c || r[h].disabled
				})
			]
		})
	});
}
//#endregion
//#region src/atomic/components/Breadcrumbs.tsx
function Ce({ items: e, label: r = "Breadcrumbs", className: i = "" }) {
	return /* @__PURE__ */ t("nav", {
		"aria-label": r,
		className: `c-breadcrumbs ${i}`.trim(),
		children: /* @__PURE__ */ t("ol", { children: e.map((r, i) => {
			let a = i === e.length - 1;
			return /* @__PURE__ */ n("li", { children: [i > 0 && /* @__PURE__ */ t(W, {
				name: "chevronRight",
				size: "small"
			}), !a && r.href ? /* @__PURE__ */ t("a", {
				href: r.href,
				children: /* @__PURE__ */ t(U, {
					as: "span",
					variant: "small",
					children: r.label
				})
			}) : /* @__PURE__ */ t(U, {
				as: "span",
				variant: a ? "h7" : "small",
				"aria-current": a ? "page" : void 0,
				children: r.label
			})] }, i);
		}) })
	});
}
//#endregion
//#region src/atomic/components/Pagination.tsx
function we({ page: e, pageCount: r, onPageChange: i, disabled: a = !1, label: o = "Pagination", className: s = "" }) {
	let c = Number.isFinite(r) ? Math.max(0, Math.floor(r)) : 0, l = Math.min(Math.max(1, Math.floor(e) || 1), Math.max(1, c)), u = c <= 7 ? Array.from({ length: c }, (e, t) => t + 1) : [.../* @__PURE__ */ new Set([
		1,
		...Array.from({ length: 3 }, (e, t) => Math.min(c - 3, Math.max(2, l - 1)) + t),
		c
	])].sort((e, t) => e - t);
	return /* @__PURE__ */ t("nav", {
		"aria-label": o,
		className: `c-pagination ${s}`.trim(),
		children: /* @__PURE__ */ n("ol", { children: [
			/* @__PURE__ */ t("li", { children: /* @__PURE__ */ t(J, {
				iconOnly: !0,
				icon: "arrowLeft",
				size: "compact",
				"aria-label": "Previous page",
				disabled: a || l <= 1 || !c,
				onClick: () => i(l - 1)
			}) }),
			u.map((e, r) => /* @__PURE__ */ n("li", { children: [r > 0 && e - u[r - 1] > 1 && /* @__PURE__ */ t(U, {
				as: "span",
				"aria-hidden": "true",
				children: "…"
			}), /* @__PURE__ */ t(J, {
				size: "compact",
				"aria-label": `Page ${e}`,
				"aria-current": e === l ? "page" : void 0,
				variant: e === l ? "primary" : "secondary",
				disabled: a,
				onClick: () => {
					e !== l && i(e);
				},
				children: e
			})] }, e)),
			/* @__PURE__ */ t("li", { children: /* @__PURE__ */ t(J, {
				iconOnly: !0,
				icon: "arrowRight",
				size: "compact",
				"aria-label": "Next page",
				disabled: a || l >= c,
				onClick: () => i(l + 1)
			}) })
		] })
	});
}
//#endregion
//#region src/atomic/components/NumberStepper.tsx
function Te({ label: e, value: r, onChange: i, min: a = 0, max: o = 100, step: s = 1, name: c, id: l, disabled: u = !1, instructions: d, className: f = "" }) {
	let p = M(), m = l ?? p, h = Math.max(a, o), g = s > 0 && Number.isFinite(s) ? s : 1, _ = (e) => Math.min(h, Math.max(a, Number.isFinite(e) ? e : a)), v = _(r), [y, b] = P(null), x = (e) => {
		b(null);
		let t = _(Number(e.toFixed(10)));
		t !== v && i(t);
	};
	return /* @__PURE__ */ n(G, {
		gap: 2,
		className: `c-number-stepper ${f}`.trim(),
		children: [
			/* @__PURE__ */ t("label", {
				htmlFor: m,
				children: /* @__PURE__ */ t(U, {
					as: "span",
					variant: "h7",
					children: e
				})
			}),
			/* @__PURE__ */ n(K, {
				gap: 0,
				children: [
					/* @__PURE__ */ t(J, {
						iconOnly: !0,
						icon: "minus",
						"aria-label": `Decrease ${e}`,
						disabled: u || v <= a,
						onClick: () => x(v - g)
					}),
					/* @__PURE__ */ t("input", {
						id: m,
						name: c,
						type: "number",
						value: y ?? v,
						min: a,
						max: h,
						step: g,
						disabled: u,
						"aria-describedby": X(m, d),
						onChange: (e) => b(e.target.value),
						onBlur: () => x(y === null || y.trim() === "" ? v : Number(y)),
						onKeyDown: (e) => {
							e.key === "Enter" && (e.preventDefault(), x(y === null || y.trim() === "" ? v : Number(y)));
						}
					}),
					/* @__PURE__ */ t(J, {
						iconOnly: !0,
						icon: "plus",
						"aria-label": `Increase ${e}`,
						disabled: u || v >= h,
						onClick: () => x(v + g)
					})
				]
			}),
			/* @__PURE__ */ t(Z, {
				id: m,
				instructions: d
			})
		]
	});
}
//#endregion
//#region src/atomic/components/Slider.tsx
function Ee({ label: e, value: r, onChange: i, min: a = 0, max: o = 100, step: s = 1, name: c, id: l, disabled: u, instructions: d, formatValue: f = String, className: p = "" }) {
	let m = M(), h = l ?? m, g = Math.max(a, o), _ = Math.min(g, Math.max(a, Number.isFinite(r) ? r : a)), v = g === a ? 0 : (_ - a) / (g - a) * 100;
	return /* @__PURE__ */ n(G, {
		gap: 2,
		className: `c-slider ${p}`.trim(),
		children: [
			/* @__PURE__ */ n("div", {
				className: "c-slider__label",
				children: [/* @__PURE__ */ t("label", {
					htmlFor: h,
					children: /* @__PURE__ */ t(U, {
						as: "span",
						variant: "h7",
						children: e
					})
				}), /* @__PURE__ */ t(U, {
					as: "span",
					variant: "h6",
					"aria-hidden": "true",
					children: f(_)
				})]
			}),
			/* @__PURE__ */ t("input", {
				type: "range",
				id: h,
				name: c,
				min: a,
				max: g,
				step: s > 0 ? s : 1,
				value: _,
				disabled: u,
				"aria-valuetext": f(_),
				"aria-describedby": X(h, d),
				style: { "--range-progress": `${v}%` },
				onChange: (e) => i(Number(e.target.value))
			}),
			/* @__PURE__ */ t(Z, {
				id: h,
				instructions: d
			})
		]
	});
}
//#endregion
//#region src/atomic/components/RangeSlider.tsx
function De({ label: e, value: r, onChange: i, min: a = 0, max: o = 100, names: s, lowerLabel: c = "Minimum", upperLabel: l = "Maximum", instructions: u, className: d = "", ...f }) {
	let p = Math.max(a, o), m = Math.min(p, Math.max(a, Number.isFinite(r[0]) ? r[0] : a)), h = Math.min(p, Math.max(m, Number.isFinite(r[1]) ? r[1] : p));
	return /* @__PURE__ */ n("fieldset", {
		className: `c-range-slider ${d}`.trim(),
		disabled: f.disabled,
		children: [/* @__PURE__ */ t("legend", { children: /* @__PURE__ */ t(U, {
			as: "span",
			variant: "h7",
			children: e
		}) }), /* @__PURE__ */ n(G, {
			gap: 4,
			children: [
				u && /* @__PURE__ */ t(U, {
					variant: "small",
					tone: "secondary",
					children: u
				}),
				/* @__PURE__ */ t(Ee, {
					...f,
					label: c,
					name: s?.[0],
					min: a,
					max: h,
					value: m,
					onChange: (e) => i([Math.min(e, h), h])
				}),
				/* @__PURE__ */ t(Ee, {
					...f,
					label: l,
					name: s?.[1],
					min: m,
					max: p,
					value: h,
					onChange: (e) => i([m, Math.max(e, m)])
				})
			]
		})]
	});
}
//#endregion
//#region src/atomic/components/Rating.tsx
function Oe({ label: e, value: r, onChange: i, max: a = 5, name: o, disabled: s, className: c = "" }) {
	let l = M(), u = o ?? l, d = Number.isFinite(a) ? Math.max(1, Math.min(10, Math.floor(a))) : 5;
	return /* @__PURE__ */ n("fieldset", {
		className: `c-rating ${c}`.trim(),
		disabled: s,
		children: [/* @__PURE__ */ t("legend", { children: /* @__PURE__ */ t(U, {
			as: "span",
			variant: "h7",
			children: e
		}) }), /* @__PURE__ */ t("div", {
			className: "c-rating__options",
			children: Array.from({ length: d }, (e, t) => t + 1).map((e) => /* @__PURE__ */ n("label", {
				className: "c-rating__choice",
				"data-filled": e <= r || void 0,
				children: [/* @__PURE__ */ t("input", {
					type: "radio",
					name: u,
					value: e,
					checked: e === r,
					onChange: () => i(e),
					"aria-label": `${e} of ${d}`
				}), /* @__PURE__ */ t(W, {
					name: "star",
					size: "large"
				})]
			}, e))
		})]
	});
}
//#endregion
//#region src/atomic/components/progressValues.ts
function ke(e, t) {
	let n = Number.isFinite(t) && t > 0 ? t : 100, r = Math.min(n, Math.max(0, Number.isFinite(e) ? e : 0));
	return {
		total: n,
		current: r,
		percent: Math.round(r / n * 100)
	};
}
//#endregion
//#region src/atomic/components/ProgressBar.tsx
function Ae({ label: e, value: r, max: i = 100, showValue: a = !0, className: o = "" }) {
	let s = M(), { current: c, total: l, percent: u } = ke(r ?? 0, i);
	return /* @__PURE__ */ n(G, {
		gap: 2,
		className: `c-progress-bar ${o}`.trim(),
		children: [/* @__PURE__ */ n("div", {
			className: "c-progress__label",
			children: [/* @__PURE__ */ t(U, {
				id: s,
				as: "span",
				variant: "h6",
				children: e
			}), a && /* @__PURE__ */ t(U, {
				as: "span",
				variant: "small",
				tone: "secondary",
				children: r === void 0 ? "Working…" : `${u}%`
			})]
		}), /* @__PURE__ */ t("div", {
			className: "c-progress-bar__track",
			role: "progressbar",
			"aria-labelledby": s,
			"aria-valuemin": 0,
			"aria-valuemax": l,
			"aria-valuenow": r === void 0 ? void 0 : c,
			"data-indeterminate": r === void 0 || void 0,
			style: { "--progress": `${u}%` },
			children: /* @__PURE__ */ t("span", {})
		})]
	});
}
//#endregion
//#region src/atomic/components/ProgressRing.tsx
function je({ label: e, value: r, max: i = 100, description: a, className: o = "" }) {
	let { current: s, total: c, percent: l } = ke(r, i);
	return /* @__PURE__ */ n(K, {
		gap: 3,
		className: `c-progress-ring ${o}`.trim(),
		children: [/* @__PURE__ */ t("div", {
			className: "c-progress-ring__track",
			role: "progressbar",
			"aria-label": e,
			"aria-valuemin": 0,
			"aria-valuemax": c,
			"aria-valuenow": s,
			style: { "--progress": `${l}%` },
			children: /* @__PURE__ */ n(U, {
				as: "span",
				variant: "h6",
				children: [l, "%"]
			})
		}), /* @__PURE__ */ n(G, {
			gap: 1,
			children: [/* @__PURE__ */ t(U, {
				variant: "h6",
				children: e
			}), a && /* @__PURE__ */ t(U, {
				variant: "small",
				tone: "secondary",
				children: a
			})]
		})]
	});
}
//#endregion
//#region src/atomic/components/StatusBadge.tsx
var Me = {
	neutral: {
		tone: "neutral",
		icon: "info"
	},
	pending: {
		tone: "accent",
		icon: "clock"
	},
	success: {
		tone: "success",
		icon: "check"
	},
	danger: {
		tone: "danger",
		icon: "alert"
	}
};
function Ne({ status: e, children: n, showIcon: r = !0, className: i = "" }) {
	let a = Me[e];
	return /* @__PURE__ */ t(xe, {
		className: `c-status-badge ${i}`.trim(),
		tone: a.tone,
		icon: r ? a.icon : void 0,
		children: n
	});
}
//#endregion
//#region src/atomic/components/Alert.tsx
function Pe({ title: e, description: r, tone: i = "neutral", showIcon: a = !0, announce: o = !1, className: s = "", action: c }) {
	return /* @__PURE__ */ t(q, {
		padding: 4,
		radius: "small",
		className: `c-alert ${s}`.trim(),
		"data-tone": i,
		role: o ? i === "danger" ? "alert" : "status" : void 0,
		children: /* @__PURE__ */ n(K, {
			gap: 3,
			children: [
				a && /* @__PURE__ */ t("span", {
					className: "c-alert__icon",
					children: /* @__PURE__ */ t(W, {
						name: i === "success" ? "check" : i === "danger" ? "alert" : "info",
						size: "small"
					})
				}),
				/* @__PURE__ */ n(G, {
					gap: 1,
					className: "c-alert__copy",
					children: [/* @__PURE__ */ t(H, {
						level: 3,
						variant: "h7",
						children: e
					}), r && /* @__PURE__ */ t(U, {
						variant: "small",
						tone: "secondary",
						children: r
					})]
				}),
				c
			]
		})
	});
}
//#endregion
//#region src/atomic/components/InlineText.tsx
function Fe({ label: e, value: r, variant: i = "body", sourceKey: a, readOnly: o, required: s, maxLength: c = 2e3, onSave: l, className: u = "" }) {
	let [d, f] = P(!1), [p, m] = P(r), [h, g] = P(r), [_, v] = P(!1), [y, b] = P(""), x = N(null), S = N(a), C = N(!1), w = M();
	ne(() => {
		d || m(r);
	}, [r, a]);
	let T = (e) => {
		f(!1), b(""), e && requestAnimationFrame(() => x.current?.focus());
	}, E = async (t) => {
		if (!(C.current || o)) {
			if (s && !h.trim()) {
				b(`${e} cannot be empty.`);
				return;
			}
			if (h === p) {
				T(t);
				return;
			}
			C.current = !0, v(!0), b("");
			try {
				let e = S.current === void 0 ? await l(h) : await l(h, S.current);
				if (e?.ok === !1) {
					b(e.message || "Could not save changes.");
					return;
				}
				m(h), T(t);
			} catch (e) {
				b(e instanceof Error ? e.message : "Could not save changes.");
			} finally {
				C.current = !1, v(!1);
			}
		}
	}, D = /* @__PURE__ */ n(U, {
		as: "span",
		variant: i,
		className: "c-inline-text__copy",
		"aria-hidden": d || void 0,
		children: [d ? h : p || "Not specified", "​"]
	}), O = `c-inline-text ${u}`.trim();
	return d ? /* @__PURE__ */ n("div", {
		className: O,
		style: se(i),
		"data-editing": "true",
		"aria-busy": _ || void 0,
		children: [
			/* @__PURE__ */ n("span", {
				className: "c-inline-text__field",
				children: [D, /* @__PURE__ */ t("textarea", {
					autoFocus: !0,
					"aria-label": e,
					"aria-describedby": y ? `${w}-error` : void 0,
					"aria-invalid": !!y || void 0,
					value: h,
					maxLength: c,
					readOnly: _ || o,
					rows: 1,
					onChange: (e) => g(e.target.value),
					onBlur: () => void E(!1),
					onKeyDown: (e) => {
						e.nativeEvent.isComposing || _ || (e.key === "Escape" && (e.preventDefault(), m(r), T(!0)), e.key === "Enter" && !e.shiftKey && (e.preventDefault(), E(!0)));
					}
				})]
			}),
			y && /* @__PURE__ */ t(U, {
				id: `${w}-error`,
				variant: "small",
				className: "c-inline-text__error",
				tone: "inherit",
				role: "alert",
				children: y
			}),
			S.current !== a && /* @__PURE__ */ t(U, {
				variant: "small",
				tone: "secondary",
				children: "The source changed. Your draft is preserved; Escape loads the latest text."
			})
		]
	}) : o ? /* @__PURE__ */ t("div", {
		className: O,
		style: se(i),
		children: D
	}) : /* @__PURE__ */ n("button", {
		ref: x,
		type: "button",
		"aria-label": `Edit ${e}`,
		className: O,
		style: se(i),
		onClick: () => {
			S.current = a, g(p), f(!0);
		},
		children: [/* @__PURE__ */ t("span", {
			className: "c-inline-text__field",
			children: D
		}), /* @__PURE__ */ t("span", {
			className: "c-inline-text__edit",
			"aria-hidden": "true",
			children: /* @__PURE__ */ t(W, {
				name: "edit",
				size: "small"
			})
		})]
	});
}
//#endregion
//#region src/atomic/components/TextAction.tsx
function Ie({ children: e, disabled: n, className: r = "", ...i }) {
	let a = /* @__PURE__ */ t(U, {
		as: "span",
		variant: "h6",
		children: e
	}), o = `c-text-action ${r}`.trim();
	return i.href === void 0 ? /* @__PURE__ */ t("button", {
		...i,
		type: i.type ?? "button",
		className: o,
		disabled: n,
		children: a
	}) : n ? /* @__PURE__ */ t("span", {
		className: o,
		"aria-disabled": "true",
		children: a
	}) : /* @__PURE__ */ t("a", {
		...i,
		className: o,
		children: a
	});
}
//#endregion
//#region src/atomic/components/Form.tsx
function Le({ label: e, children: n, className: r = "", ...i }) {
	return /* @__PURE__ */ t("form", {
		...i,
		"aria-label": e,
		className: `c-form ${r}`.trim(),
		children: /* @__PURE__ */ t(G, {
			gap: 6,
			children: n
		})
	});
}
function Re({ onCancel: e, submitLabel: r = "Save", cancelLabel: i = "Cancel", busy: a, disabled: o, message: s }) {
	return /* @__PURE__ */ n(G, {
		gap: 2,
		className: "c-form-actions",
		children: [/* @__PURE__ */ n(K, { children: [e && /* @__PURE__ */ t(J, {
			onClick: e,
			disabled: a,
			children: i
		}), /* @__PURE__ */ t(J, {
			type: "submit",
			variant: "primary",
			busy: a,
			disabled: o,
			children: r
		})] }), s && /* @__PURE__ */ t(U, {
			variant: "small",
			role: "status",
			children: s
		})]
	});
}
//#endregion
//#region src/atomic/components/DatePicker.tsx
var $ = (e) => e.toISOString().slice(0, 10), ze = (e) => {
	if (!/^\d{4}-\d{2}-\d{2}$/.test(e)) return null;
	let t = /* @__PURE__ */ new Date(e + "T12:00:00Z");
	return !Number.isNaN(t.getTime()) && $(t) === e ? t : null;
};
function Be({ label: e, value: r, defaultValue: i = "", min: a, max: o, onChange: s, onValueChange: c, disabled: l, readOnly: u, required: d, name: f, id: p, instructions: m, error: h, className: g = "" }) {
	let _ = M(), v = p ?? _, y = N(null), b = N({}), [x, S] = P(i), [C, w] = P(!1), T = r ?? x, E = ze(T) || ze(a ?? "") || /* @__PURE__ */ new Date(), [D, O] = P(new Date(Date.UTC(E.getUTCFullYear(), E.getUTCMonth(), 1, 12))), [k, ee] = P(T || $(E));
	re(() => {
		C && b.current[k]?.focus();
	}, [C, k]);
	let A = D.getUTCFullYear(), j = D.getUTCMonth(), te = new Date(Date.UTC(A, j + 1, 0)).getUTCDate(), ne = (D.getUTCDay() + 6) % 7, F = (e) => !!a && e < a || !!o && e > o, I = typeof e == "string" ? e : "Date", R = (e) => {
		F(e) || (S(e), c?.(e), y.current && s && (y.current.value = e, s({
			target: y.current,
			currentTarget: y.current
		})), w(!1));
	}, z = (e) => {
		let t = new Date(Date.UTC(A, j + e, 1, 12));
		O(t);
		let n = $(t);
		ee(a && n < a ? a : o && n > o ? o : n);
	}, B = (e, t) => {
		let n = ze(t), r = e.key === "ArrowRight" ? 1 : e.key === "ArrowLeft" ? -1 : e.key === "ArrowDown" ? 7 : e.key === "ArrowUp" ? -7 : 0;
		if (e.key === "Home" && (r = -((n.getUTCDay() + 6) % 7)), e.key === "End" && (r = 6 - (n.getUTCDay() + 6) % 7), e.key === "PageDown" || e.key === "PageUp") {
			e.preventDefault(), z(e.key === "PageDown" ? 1 : -1);
			return;
		}
		if (!r && e.key !== "Home") return;
		e.preventDefault(), n.setUTCDate(n.getUTCDate() + r);
		let i = $(n);
		F(i) || (ee(i), n.getUTCMonth() === j ? b.current[i]?.focus() : O(new Date(Date.UTC(n.getUTCFullYear(), n.getUTCMonth(), 1, 12))));
	};
	return /* @__PURE__ */ n(G, {
		gap: 2,
		className: `c-date-picker c-field ${g}`,
		children: [
			/* @__PURE__ */ t("label", {
				htmlFor: v,
				children: /* @__PURE__ */ t(U, {
					as: "span",
					variant: "h7",
					children: e
				})
			}),
			/* @__PURE__ */ n(L.Root, {
				open: C,
				onOpenChange: (e) => {
					if (w(e), e) {
						let e = ze(T) || E;
						O(new Date(Date.UTC(e.getUTCFullYear(), e.getUTCMonth(), 1, 12))), ee($(e));
					}
				},
				children: [/* @__PURE__ */ t(L.Anchor, {
					asChild: !0,
					children: /* @__PURE__ */ n("div", {
						className: "c-date-picker__field",
						children: [/* @__PURE__ */ t("input", {
							ref: y,
							id: v,
							name: f,
							className: "c-text-input",
							value: T,
							placeholder: "YYYY-MM-DD",
							readOnly: !0,
							disabled: l,
							required: d,
							"aria-describedby": X(v, m, h),
							"aria-invalid": !!h || void 0
						}), /* @__PURE__ */ t(L.Trigger, {
							asChild: !0,
							children: /* @__PURE__ */ t("button", {
								className: "c-date-picker__trigger",
								type: "button",
								disabled: l || u,
								"aria-label": `Open ${I} calendar`,
								children: /* @__PURE__ */ t(W, {
									name: "calendar",
									size: "small"
								})
							})
						})]
					})
				}), /* @__PURE__ */ t(L.Portal, { children: /* @__PURE__ */ t(V, {
					className: "c-overlay-root",
					children: /* @__PURE__ */ t(L.Content, {
						className: "c-popup c-calendar",
						sideOffset: 8,
						collisionPadding: 16,
						"aria-label": `${I} calendar`,
						onOpenAutoFocus: (e) => {
							e.preventDefault(), b.current[k]?.focus();
						},
						children: /* @__PURE__ */ n(G, {
							gap: 3,
							children: [/* @__PURE__ */ n(K, {
								className: "c-calendar__heading",
								children: [
									/* @__PURE__ */ t(J, {
										iconOnly: !0,
										size: "compact",
										variant: "quiet",
										icon: "arrowLeft",
										"aria-label": "Previous month",
										disabled: !!a && $(new Date(Date.UTC(A, j, 0, 12))) < a,
										onClick: () => z(-1)
									}),
									/* @__PURE__ */ t(U, {
										variant: "h6",
										role: "status",
										children: D.toLocaleDateString("en", {
											month: "long",
											year: "numeric",
											timeZone: "UTC"
										})
									}),
									/* @__PURE__ */ t(J, {
										iconOnly: !0,
										size: "compact",
										variant: "quiet",
										icon: "arrowRight",
										"aria-label": "Next month",
										disabled: !!o && $(new Date(Date.UTC(A, j + 1, 1, 12))) > o,
										onClick: () => z(1)
									})
								]
							}), /* @__PURE__ */ n("div", {
								className: "c-calendar__grid",
								role: "group",
								"aria-label": "Choose date",
								children: [
									[
										"Mo",
										"Tu",
										"We",
										"Th",
										"Fr",
										"Sa",
										"Su"
									].map((e) => /* @__PURE__ */ t(U, {
										as: "span",
										variant: "small",
										children: e
									}, e)),
									Array.from({ length: ne }, (e, n) => /* @__PURE__ */ t("span", {}, `blank-${n}`)),
									Array.from({ length: te }, (e, n) => {
										let r = $(new Date(Date.UTC(A, j, n + 1, 12)));
										return /* @__PURE__ */ t(J, {
											ref: (e) => {
												b.current[r] = e, e && r === k && document.activeElement?.closest(".c-calendar") && e.focus();
											},
											size: "compact",
											variant: r === T ? "primary" : "quiet",
											"aria-label": r,
											"aria-pressed": r === T,
											tabIndex: r === k ? 0 : -1,
											disabled: F(r),
											onKeyDown: (e) => B(e, r),
											onClick: () => R(r),
											children: n + 1
										}, r);
									})
								]
							})]
						})
					})
				}) })]
			}),
			/* @__PURE__ */ t(Z, {
				id: v,
				instructions: m,
				error: h
			})
		]
	});
}
//#endregion
//#region src/atomic/components/SpecialFields.tsx
function Ve({ label: e, ...r }) {
	let [i, a] = P(!1);
	return /* @__PURE__ */ n(G, {
		gap: 2,
		className: "c-password-field",
		children: [/* @__PURE__ */ t(Q, {
			...r,
			label: e,
			type: i ? "text" : "password"
		}), /* @__PURE__ */ t(K, { children: /* @__PURE__ */ n(J, {
			size: "compact",
			icon: "eye",
			"aria-pressed": i,
			disabled: r.disabled,
			onClick: () => a((e) => !e),
			children: [
				i ? "Hide" : "Show",
				" ",
				e
			]
		}) })]
	});
}
function He({ label: e, value: r, onChange: i, ...a }) {
	return /* @__PURE__ */ n(G, {
		gap: 2,
		className: "c-search-field",
		children: [/* @__PURE__ */ t(Q, {
			...a,
			type: "search",
			label: e,
			value: r,
			onChange: (e) => i(e.target.value)
		}), /* @__PURE__ */ t(K, { children: /* @__PURE__ */ n(J, {
			size: "compact",
			icon: "close",
			disabled: a.disabled || !r,
			onClick: () => i(""),
			children: ["Clear ", e]
		}) })]
	});
}
//#endregion
//#region src/atomic/components/Loading.tsx
function Ue({ label: e }) {
	return /* @__PURE__ */ n(K, {
		gap: 2,
		className: "c-spinner",
		role: "status",
		"aria-label": e,
		children: [/* @__PURE__ */ t(W, { name: "loading" }), /* @__PURE__ */ t(U, {
			variant: "small",
			children: e
		})]
	});
}
function We({ label: e = "Loading", lines: n = 3 }) {
	return /* @__PURE__ */ t(G, {
		gap: 3,
		className: "c-skeleton",
		role: "status",
		"aria-label": e,
		children: Array.from({ length: Math.min(10, Math.max(1, Math.floor(n) || 1)) }, (e, n) => /* @__PURE__ */ t("span", { "aria-hidden": "true" }, n))
	});
}
function Ge({ title: e, description: r, action: i }) {
	return /* @__PURE__ */ t(q, {
		padding: 8,
		className: "c-empty-state",
		children: /* @__PURE__ */ n(G, {
			gap: 3,
			children: [
				/* @__PURE__ */ t(W, {
					name: "folder",
					size: "large"
				}),
				/* @__PURE__ */ t(H, {
					level: 3,
					variant: "h5",
					children: e
				}),
				r && /* @__PURE__ */ t(U, {
					tone: "secondary",
					children: r
				}),
				i
			]
		})
	});
}
//#endregion
//#region src/atomic/components/Files.tsx
function Ke({ label: e, onFiles: r, accept: i, multiple: a = !1, maxSize: o = 10485760, disabled: s, state: c = "idle", progress: l = 0, error: u, onRetry: d }) {
	let f = M(), [p, m] = P(""), [h, g] = P(!1), _ = N(null), v = s || c === "uploading", y = u || p, b = (e) => {
		if (v) return;
		let t = e.find((e) => e.size > o || i && !i.split(",").some((t) => {
			let n = t.trim().toLowerCase();
			return n.startsWith(".") ? e.name.toLowerCase().endsWith(n) : n.endsWith("/*") ? e.type.startsWith(n.slice(0, -1)) : e.type === n;
		}));
		if (t) {
			m(`${t.name} exceeds the size limit or has an unsupported file type.`);
			return;
		}
		if (!a && e.length > 1) {
			m("Choose one file.");
			return;
		}
		m(""), e.length && r(e);
	};
	return /* @__PURE__ */ t(q, {
		padding: 6,
		radius: "small",
		className: "c-file-dropzone",
		"data-state": h ? "dragging" : c,
		"aria-disabled": v || void 0,
		onDragEnter: (e) => {
			e.preventDefault(), v || g(!0);
		},
		onDragLeave: (e) => {
			e.currentTarget.contains(e.relatedTarget) || g(!1);
		},
		onDragOver: (e) => e.preventDefault(),
		onDrop: (e) => {
			e.preventDefault(), g(!1), b(Array.from(e.dataTransfer.files));
		},
		children: /* @__PURE__ */ n(G, {
			gap: 3,
			children: [
				/* @__PURE__ */ t(W, { name: "upload" }),
				/* @__PURE__ */ t("label", {
					htmlFor: f,
					children: /* @__PURE__ */ t(U, {
						as: "span",
						variant: "h6",
						children: e
					})
				}),
				/* @__PURE__ */ n(U, {
					variant: "small",
					tone: "secondary",
					children: [
						"Choose ",
						a ? "files" : "a file",
						" or drop ",
						a ? "them" : "it",
						" here. Maximum ",
						Math.round(o / 1024 / 1024),
						" MB per file."
					]
				}),
				/* @__PURE__ */ t("input", {
					ref: _,
					className: "c-file-dropzone__input",
					tabIndex: -1,
					id: f,
					type: "file",
					accept: i,
					multiple: a,
					disabled: v,
					"aria-describedby": y ? `${f}-error` : void 0,
					onChange: (e) => {
						b(Array.from(e.target.files ?? [])), e.target.value = "";
					}
				}),
				/* @__PURE__ */ n(K, { children: [/* @__PURE__ */ t(J, {
					icon: "upload",
					disabled: v,
					onClick: () => _.current?.click(),
					children: "Choose files"
				}), c === "error" && d && /* @__PURE__ */ t(J, {
					onClick: d,
					disabled: v,
					children: "Retry upload"
				})] }),
				c === "uploading" && /* @__PURE__ */ t(Ae, {
					label: "Uploading files",
					value: l
				}),
				c === "success" && /* @__PURE__ */ t(U, {
					variant: "small",
					role: "status",
					children: "Files uploaded."
				}),
				y && /* @__PURE__ */ t(U, {
					id: `${f}-error`,
					tone: "inherit",
					className: "c-field-error",
					variant: "small",
					role: "alert",
					children: y
				})
			]
		})
	});
}
function qe({ files: e, onRemove: r, disabled: i }) {
	return /* @__PURE__ */ t("ul", {
		className: "c-file-list",
		"aria-label": "Files",
		children: e.map((e) => /* @__PURE__ */ t("li", { children: /* @__PURE__ */ n(K, {
			gap: 3,
			children: [
				/* @__PURE__ */ t(W, { name: "file" }),
				/* @__PURE__ */ n(G, {
					gap: 1,
					className: "c-file-list__copy",
					children: [/* @__PURE__ */ t(U, {
						variant: "h7",
						children: e.name
					}), e.size !== void 0 && /* @__PURE__ */ n(U, {
						variant: "small",
						tone: "secondary",
						children: [Math.ceil(e.size / 1024), " KB"]
					})]
				}),
				r && /* @__PURE__ */ t(J, {
					iconOnly: !0,
					size: "compact",
					icon: "close",
					"aria-label": `Remove ${e.name}`,
					disabled: i,
					onClick: () => r(e.id)
				})
			]
		}) }, e.id))
	});
}
//#endregion
//#region src/atomic/components/WorkflowSteps.tsx
function Je({ label: e, steps: r, current: i, onChange: a, orientation: o = "horizontal" }) {
	return /* @__PURE__ */ t("nav", {
		className: "c-workflow",
		"aria-label": e,
		"data-orientation": o,
		children: /* @__PURE__ */ t("ol", { children: r.map((e, r) => /* @__PURE__ */ t("li", { children: /* @__PURE__ */ n("button", {
			type: "button",
			className: "c-workflow__step",
			"aria-current": e.id === i ? "step" : void 0,
			disabled: e.disabled,
			onClick: () => a(e.id),
			children: [/* @__PURE__ */ t("span", {
				className: "c-workflow__circle",
				"data-complete": e.complete || void 0,
				children: e.complete ? /* @__PURE__ */ t(W, {
					name: "check",
					size: "small"
				}) : /* @__PURE__ */ t(U, {
					as: "span",
					variant: "h7",
					children: r + 1
				})
			}), /* @__PURE__ */ n("span", {
				className: "c-workflow__copy",
				children: [/* @__PURE__ */ t(U, {
					as: "span",
					variant: "h7",
					children: e.label
				}), e.description && /* @__PURE__ */ t(U, {
					as: "span",
					variant: "small",
					tone: "secondary",
					children: e.description
				})]
			})]
		}) }, e.id)) })
	});
}
//#endregion
//#region src/atomic/components/Table.tsx
function Ye({ label: e, rows: r, rowKey: i, columns: a, sort: o, onSort: s, emptyMessage: c = "No rows to display." }) {
	return /* @__PURE__ */ t(pe, {
		label: `${e} table`,
		maxHeight: "none",
		children: /* @__PURE__ */ n("table", {
			className: "c-table",
			"aria-label": e,
			children: [/* @__PURE__ */ t("thead", { children: /* @__PURE__ */ t("tr", { children: a.map((e) => /* @__PURE__ */ t("th", {
				scope: "col",
				"aria-sort": o?.column === e.id ? o.direction === "asc" ? "ascending" : "descending" : void 0,
				children: e.sortable && s ? /* @__PURE__ */ n("button", {
					type: "button",
					className: "c-table__sort",
					onClick: () => s({
						column: e.id,
						direction: o?.column === e.id && o.direction === "asc" ? "desc" : "asc"
					}),
					children: [/* @__PURE__ */ t(U, {
						as: "span",
						variant: "h7",
						children: e.header
					}), /* @__PURE__ */ t(W, {
						name: o?.column === e.id && o.direction === "asc" ? "arrowUp" : "arrowDown",
						size: "small"
					})]
				}) : /* @__PURE__ */ t(U, {
					as: "span",
					variant: "h7",
					children: e.header
				})
			}, e.id)) }) }), /* @__PURE__ */ n("tbody", { children: [r.map((e) => /* @__PURE__ */ t("tr", { children: a.map((n) => /* @__PURE__ */ t("td", { children: n.render(e) }, n.id)) }, i(e))), !r.length && /* @__PURE__ */ t("tr", { children: /* @__PURE__ */ t("td", {
				colSpan: a.length,
				children: c
			}) })] })]
		})
	});
}
//#endregion
//#region src/atomic/components/Toast.tsx
function Xe({ onDismiss: e, ...n }) {
	return /* @__PURE__ */ t(Pe, {
		...n,
		className: `c-toast ${n.className ?? ""}`,
		announce: !0,
		action: /* @__PURE__ */ t("button", {
			type: "button",
			className: "c-toast__dismiss",
			"aria-label": "Dismiss notification",
			onClick: e,
			children: /* @__PURE__ */ t(W, {
				name: "close",
				size: "small"
			})
		})
	});
}
//#endregion
//#region src/atomic/components/Overlays.tsx
function Ze({ title: e, description: r, trigger: i, children: a, open: o, onOpenChange: s, drawer: c = !1, tone: l = "neutral" }) {
	let u = M();
	return /* @__PURE__ */ n(F.Root, {
		open: o,
		onOpenChange: s,
		children: [/* @__PURE__ */ t(F.Trigger, {
			asChild: !0,
			children: /* @__PURE__ */ t(J, {
				className: c ? "c-drawer-trigger" : "c-dialog-trigger",
				children: i
			})
		}), /* @__PURE__ */ t(F.Portal, { children: /* @__PURE__ */ n(V, {
			className: "c-overlay-root",
			children: [/* @__PURE__ */ t(F.Overlay, { className: "c-backdrop" }), /* @__PURE__ */ t(F.Content, {
				className: c ? "c-modal c-drawer" : "c-modal",
				"aria-describedby": r ? u : void 0,
				children: /* @__PURE__ */ n(G, {
					gap: 4,
					children: [
						/* @__PURE__ */ n("div", {
							className: "c-modal__header",
							children: [/* @__PURE__ */ t(F.Title, {
								asChild: !0,
								children: /* @__PURE__ */ n(H, {
									level: 2,
									variant: "h4",
									children: [
										l !== "neutral" && /* @__PURE__ */ t(W, {
											name: l === "warning" ? "alert" : "check",
											size: "small"
										}),
										" ",
										e
									]
								})
							}), /* @__PURE__ */ t(F.Close, {
								asChild: !0,
								children: /* @__PURE__ */ t(J, {
									iconOnly: !0,
									icon: "close",
									size: "compact",
									"aria-label": "Close dialog"
								})
							})]
						}),
						r && /* @__PURE__ */ t(F.Description, {
							asChild: !0,
							id: u,
							children: /* @__PURE__ */ t(U, {
								tone: "secondary",
								children: r
							})
						}),
						a
					]
				})
			})]
		}) })]
	});
}
function Qe(e) {
	return /* @__PURE__ */ t(Ze, { ...e });
}
function $e(e) {
	return /* @__PURE__ */ t(Ze, {
		...e,
		drawer: !0
	});
}
function et({ label: e, children: r, open: i, onOpenChange: a, disabled: o, variant: s = "default" }) {
	return /* @__PURE__ */ n(L.Root, {
		open: i,
		onOpenChange: a,
		children: [/* @__PURE__ */ t(L.Trigger, {
			asChild: !0,
			children: s === "field" ? /* @__PURE__ */ n("button", {
				type: "button",
				className: "c-text-input c-select-trigger",
				disabled: o,
				children: [e, /* @__PURE__ */ t(W, {
					name: "chevronDown",
					size: "small"
				})]
			}) : /* @__PURE__ */ t(J, {
				className: "c-popover-trigger",
				icon: "chevronDown",
				iconPosition: "end",
				disabled: o,
				children: e
			})
		}), /* @__PURE__ */ t(L.Portal, { children: /* @__PURE__ */ t(V, {
			className: "c-overlay-root",
			children: /* @__PURE__ */ t(L.Content, {
				className: s === "field" ? "c-popup c-dropdown-popup" : "c-popup",
				sideOffset: 8,
				collisionPadding: 16,
				"aria-label": e,
				children: r
			})
		}) })]
	});
}
var tt = {
	copy: "copy",
	duplicate: "copy",
	delete: "delete",
	download: "download",
	edit: "edit",
	settings: "settings"
};
function nt({ label: e, items: r, onSelect: i, disabled: a, iconOnly: o, icon: s = "more", side: c = "bottom" }) {
	return /* @__PURE__ */ n(I.Root, { children: [/* @__PURE__ */ t(I.Trigger, {
		asChild: !0,
		children: o ? /* @__PURE__ */ t(J, {
			className: "c-menu-trigger",
			variant: "quiet",
			iconOnly: !0,
			"aria-label": e,
			icon: s,
			disabled: a
		}) : /* @__PURE__ */ t(J, {
			className: "c-menu-trigger",
			icon: s,
			disabled: a,
			children: e
		})
	}), /* @__PURE__ */ t(I.Portal, { children: /* @__PURE__ */ t(V, {
		className: "c-overlay-root",
		children: /* @__PURE__ */ t(I.Content, {
			side: c,
			className: "c-popup c-menu",
			sideOffset: 8,
			collisionPadding: 16,
			"aria-label": e,
			children: r.map((e) => /* @__PURE__ */ n(I.Item, {
				className: "c-menu__item",
				disabled: e.disabled,
				"data-danger": e.danger || void 0,
				onSelect: () => i(e.id),
				children: [/* @__PURE__ */ t(W, {
					name: e.icon ?? tt[e.id] ?? "more",
					size: "small"
				}), /* @__PURE__ */ t(U, {
					as: "span",
					variant: "small",
					tone: "inherit",
					children: e.label
				})]
			}, e.id))
		})
	}) })] });
}
function rt({ label: e, content: r }) {
	return /* @__PURE__ */ t(B.Provider, {
		delayDuration: 150,
		children: /* @__PURE__ */ n(B.Root, { children: [/* @__PURE__ */ t(B.Trigger, {
			asChild: !0,
			children: /* @__PURE__ */ t(J, {
				className: "c-tooltip-trigger",
				icon: "info",
				size: "compact",
				children: e
			})
		}), /* @__PURE__ */ t(B.Portal, { children: /* @__PURE__ */ t(V, {
			className: "c-overlay-root",
			children: /* @__PURE__ */ t(B.Content, {
				className: "c-tooltip",
				sideOffset: 8,
				collisionPadding: 16,
				children: /* @__PURE__ */ t(U, {
					variant: "small",
					tone: "inherit",
					children: r
				})
			})
		}) })] })
	});
}
//#endregion
//#region src/atomic/components/Tabs.tsx
function it(e) {
	let [r, i] = P("items" in e ? e.items.find((e) => !e.disabled)?.id : void 0);
	if (!("items" in e)) return /* @__PURE__ */ t(Se, { ...e });
	let { label: a, items: o, value: s, onChange: c } = e, l = s ?? r, u = o.findIndex((e) => e.id === l);
	return /* @__PURE__ */ n(z.Root, {
		className: "c-tabs",
		value: l,
		onValueChange: (e) => {
			i(e), c?.(e);
		},
		children: [/* @__PURE__ */ t("div", {
			className: "c-segmented-scroll",
			children: /* @__PURE__ */ n(z.List, {
				className: "c-segmented",
				"aria-label": a,
				style: {
					"--segment-count": Math.max(1, o.length),
					"--segment-index": u
				},
				children: [u >= 0 && /* @__PURE__ */ t("span", {
					className: "c-segmented__indicator",
					"aria-hidden": "true"
				}), o.map((e) => /* @__PURE__ */ t(z.Trigger, {
					value: e.id,
					disabled: e.disabled,
					className: "c-segmented__option",
					children: /* @__PURE__ */ t(U, {
						as: "span",
						variant: "h6",
						tone: "inherit",
						children: e.label
					})
				}, e.id))]
			})
		}), o.map((e) => /* @__PURE__ */ t(z.Content, {
			className: "c-tabs__content",
			value: e.id,
			children: e.content
		}, e.id))]
	});
}
//#endregion
//#region src/atomic/components/Combobox.tsx
function at({ label: e, value: r, onChange: i, options: a, disabled: o, name: s }) {
	let c = M(), [l, u] = P(!1), [d, f] = P(null), [p, m] = P(-1), h = a.filter((e) => e.label.toLowerCase().includes((d ?? "").toLowerCase())), g = (e) => {
		let t = h[e];
		!t || t.disabled || (i(t.value), f(null), u(!1), m(-1));
	};
	return /* @__PURE__ */ n(G, {
		gap: 2,
		className: "c-combobox",
		children: [
			/* @__PURE__ */ t(Q, {
				label: e,
				role: "combobox",
				autoComplete: "off",
				"aria-expanded": l,
				"aria-autocomplete": "list",
				"aria-controls": l ? `${c}-list` : void 0,
				"aria-activedescendant": l && p >= 0 ? `${c}-${p}` : void 0,
				disabled: o,
				value: d ?? a.find((e) => e.value === r)?.label ?? "",
				onFocus: () => u(!0),
				onBlur: () => {
					u(!1), f(null), m(-1);
				},
				onChange: (e) => {
					f(e.target.value), m(-1), u(!0);
				},
				onKeyDown: (e) => {
					if (e.key === "Escape" && (e.preventDefault(), u(!1), f(null), m(-1)), e.key === "ArrowDown" || e.key === "ArrowUp") {
						e.preventDefault(), u(!0);
						let t = h.map((e, t) => e.disabled ? -1 : t).filter((e) => e >= 0), n = t.indexOf(p), r = n < 0 ? e.key === "ArrowDown" ? 0 : t.length - 1 : (n + (e.key === "ArrowDown" ? 1 : -1) + t.length) % t.length;
						m(t[r] ?? -1);
					}
					e.key === "Enter" && l && (e.preventDefault(), g(p));
				}
			}),
			/* @__PURE__ */ t(W, {
				name: "chevronDown",
				size: "small"
			}),
			s && /* @__PURE__ */ t("input", {
				type: "hidden",
				name: s,
				value: r,
				disabled: o
			}),
			l && /* @__PURE__ */ n("ul", {
				id: `${c}-list`,
				role: "listbox",
				"aria-label": e,
				className: "c-combobox__options c-dropdown-popup",
				children: [h.map((e, i) => /* @__PURE__ */ n("li", {
					id: `${c}-${i}`,
					className: "c-dropdown-option",
					role: "option",
					"aria-selected": e.value === r,
					"aria-disabled": e.disabled || void 0,
					"data-active": i === p || void 0,
					onMouseDown: (e) => e.preventDefault(),
					onClick: () => g(i),
					children: [/* @__PURE__ */ t(U, {
						as: "span",
						variant: "body",
						children: e.label
					}), e.value === r && /* @__PURE__ */ t(W, {
						name: "check",
						size: "small"
					})]
				}, e.value)), !h.length && /* @__PURE__ */ t("li", {
					role: "presentation",
					children: /* @__PURE__ */ t(U, {
						variant: "body",
						children: "No matches"
					})
				})]
			})
		]
	});
}
//#endregion
//#region src/atomic/components/MultiSelect.tsx
function ot({ label: e, value: r, onChange: i, options: a, disabled: o, name: s }) {
	return /* @__PURE__ */ n(G, {
		gap: 2,
		className: "c-multiselect",
		children: [
			/* @__PURE__ */ t(U, {
				variant: "h7",
				children: e
			}),
			/* @__PURE__ */ t(et, {
				variant: "field",
				label: `${e} · ${r.length} selected`,
				disabled: o,
				children: /* @__PURE__ */ t(G, {
					gap: 2,
					children: a.map((e) => /* @__PURE__ */ t(he, {
						label: e.label,
						checked: r.includes(e.value),
						disabled: o || e.disabled,
						onChange: (t) => i(t.target.checked ? [...r, e.value] : r.filter((t) => t !== e.value))
					}, e.value))
				})
			}),
			/* @__PURE__ */ t(K, { children: a.filter((e) => r.includes(e.value)).map((e) => {
				let n = !o && !e.disabled ? {
					children: e.label,
					removeLabel: `Remove ${e.label}`,
					onRemove: () => i(r.filter((t) => t !== e.value))
				} : { children: e.label };
				return /* @__PURE__ */ t(xe, {
					tone: "accent",
					...n
				}, e.value);
			}) }),
			s && r.map((e) => /* @__PURE__ */ t("input", {
				type: "hidden",
				name: s,
				value: e,
				disabled: o
			}, e))
		]
	});
}
//#endregion
//#region src/atomic/components/InlineConfirmation.tsx
function st({ label: e, question: r, onConfirm: i, disabled: a, description: o }) {
	let [s, c] = P(!1), [l, u] = P(!1), [d, f] = P(""), p = N(null), m = N(null), h = N(!1);
	ne(() => {
		s ? m.current?.focus() : h.current &&= (p.current?.focus(), !1);
	}, [s]);
	let g = () => {
		h.current = !0, c(!1), f("");
	};
	return /* @__PURE__ */ n(G, {
		gap: 2,
		className: "c-inline-confirmation",
		children: [/* @__PURE__ */ t(K, { children: /* @__PURE__ */ t(J, {
			ref: p,
			onClick: () => c(!0),
			disabled: a || s,
			"aria-expanded": s,
			children: e
		}) }), s && /* @__PURE__ */ t(q, {
			tone: "canvas",
			radius: "small",
			padding: 4,
			children: /* @__PURE__ */ n(G, {
				gap: 2,
				role: "group",
				"aria-label": r,
				onKeyDown: (e) => {
					e.key === "Escape" && !l && (e.preventDefault(), g());
				},
				children: [
					/* @__PURE__ */ n(K, { children: [
						/* @__PURE__ */ t(U, {
							variant: "h6",
							children: r
						}),
						/* @__PURE__ */ t(J, {
							ref: m,
							disabled: l,
							onClick: g,
							children: "Cancel"
						}),
						/* @__PURE__ */ t(J, {
							variant: "danger",
							busy: l,
							onClick: async () => {
								u(!0), f("");
								try {
									await i(), g();
								} catch (e) {
									f(e instanceof Error ? e.message : "Action failed. Try again.");
								} finally {
									u(!1);
								}
							},
							children: "Confirm"
						})
					] }),
					o && /* @__PURE__ */ t(U, {
						variant: "small",
						tone: "secondary",
						children: o
					}),
					d && /* @__PURE__ */ t(U, {
						variant: "small",
						role: "alert",
						children: d
					})
				]
			})
		})]
	});
}
//#endregion
//#region src/atomic/components/NavigationList.tsx
function ct({ label: e, items: r }) {
	return /* @__PURE__ */ t("nav", {
		"aria-label": e,
		children: /* @__PURE__ */ t(G, {
			gap: 1,
			children: r.map((e) => /* @__PURE__ */ n("div", {
				className: "c-navigation-row",
				children: [/* @__PURE__ */ n("a", {
					href: e.href,
					"aria-current": e.current ? "page" : void 0,
					onClick: e.onClick,
					title: e.label,
					children: [e.icon && /* @__PURE__ */ t(W, {
						name: e.icon,
						size: "small"
					}), /* @__PURE__ */ t(U, {
						as: "span",
						variant: "small",
						tone: "inherit",
						children: e.label
					})]
				}), e.trailing]
			}, e.id))
		})
	});
}
//#endregion
//#region src/atomic/components/AttachmentArea.tsx
function lt({ label: r, children: i, actions: a, onFiles: o, disabled: s, accept: c = ".txt,.md,.pdf,.docx", maxSize: l = 10485760 }) {
	let u = M(), d = N(null), [f, p] = P(!1), [m, h] = P("");
	function g(e) {
		if (s || !o) return;
		let t = e.find((e) => e.size > l || !c.split(",").some((t) => {
			let n = t.trim().toLowerCase();
			return n.startsWith(".") ? e.name.toLowerCase().endsWith(n) : n.endsWith("/*") ? e.type.startsWith(n.slice(0, -1)) : e.type === n;
		}));
		if (t) {
			h(t.name + " is too large or has an unsupported file type.");
			return;
		}
		h(""), e.length && o(e);
	}
	return /* @__PURE__ */ t(q, {
		padding: 4,
		role: "group",
		"aria-label": r,
		className: "c-attachment-area",
		"data-dragging": f || void 0,
		onDragOver: (e) => {
			e.preventDefault(), o && !s && p(!0);
		},
		onDragLeave: (e) => {
			e.currentTarget.contains(e.relatedTarget) || p(!1);
		},
		onDrop: (e) => {
			e.preventDefault(), p(!1), g(Array.from(e.dataTransfer.files));
		},
		children: /* @__PURE__ */ n(G, {
			gap: 3,
			children: [
				i,
				/* @__PURE__ */ n(K, {
					className: "c-attachment-area__toolbar",
					children: [o && /* @__PURE__ */ n(e, { children: [/* @__PURE__ */ t("input", {
						ref: d,
						id: u,
						className: "c-attachment-area__picker",
						"aria-label": "Attach files",
						type: "file",
						multiple: !0,
						accept: c,
						disabled: s,
						tabIndex: -1,
						onChange: (e) => {
							g(Array.from(e.target.files ?? [])), e.target.value = "";
						}
					}), /* @__PURE__ */ t(J, {
						iconOnly: !0,
						variant: "quiet",
						icon: "Paperclip",
						"aria-label": "Attach files",
						disabled: s,
						onClick: () => d.current?.click()
					})] }), /* @__PURE__ */ t(K, {
						className: "c-attachment-area__actions",
						children: a
					})]
				}),
				m && /* @__PURE__ */ t(U, {
					role: "alert",
					className: "c-field-error",
					tone: "inherit",
					variant: "small",
					children: m
				})
			]
		})
	});
}
//#endregion
//#region src/atomic/ui-blocks/SidebarPanel.tsx
function ut({ brand: r, primaryAction: i, navigation: a, projects: o, account: s, onProjectAction: c }) {
	let [l, u] = P(!1), [d, f] = P(""), p = N(null), m = N(!1);
	ne(() => {
		!l && m.current && (p.current?.focus(), m.current = !1);
	}, [l]);
	let h = o.filter((e) => e.title.toLowerCase().includes(d.trim().toLowerCase())), g = (e) => e.map((e) => ({
		id: e.id,
		label: e.title,
		href: e.href,
		current: e.current,
		trailing: e.actions?.length ? /* @__PURE__ */ t(nt, {
			label: "Actions for " + e.title,
			iconOnly: !0,
			items: e.actions,
			onSelect: (t) => c?.(e.id, t)
		}) : void 0
	}));
	return /* @__PURE__ */ n(q, {
		as: "aside",
		tone: "canvas",
		radius: "none",
		padding: 4,
		className: "b-sidebar",
		"aria-label": "Sidebar",
		children: [/* @__PURE__ */ n(G, {
			gap: 6,
			children: [
				l ? /* @__PURE__ */ t(He, {
					label: "Search projects",
					autoFocus: !0,
					value: d,
					onChange: f,
					onKeyDown: (e) => {
						e.key === "Escape" && (e.preventDefault(), m.current = !0, f(""), u(!1));
					}
				}) : /* @__PURE__ */ n(K, {
					className: "b-sidebar__header",
					children: [/* @__PURE__ */ t(H, {
						level: 2,
						variant: "h4",
						children: r.label
					}), /* @__PURE__ */ t(J, {
						ref: p,
						iconOnly: !0,
						size: "compact",
						icon: "search",
						"aria-label": "Search projects",
						onClick: () => u(!0)
					})]
				}),
				!l && /* @__PURE__ */ n(e, { children: [/* @__PURE__ */ t(J, {
					variant: "primary",
					icon: i.icon ?? "plus",
					onClick: i.onClick,
					children: i.label
				}), /* @__PURE__ */ t(ct, {
					label: "Workspace navigation",
					items: a
				})] }),
				/* @__PURE__ */ t(pe, {
					label: "Projects",
					maxHeight: "28rem",
					children: /* @__PURE__ */ n(G, {
						gap: 6,
						children: [["Pinned", "Recent projects"].map((e) => {
							let r = h.filter((t) => e === "Pinned" ? t.pinned : !t.pinned);
							return r.length ? /* @__PURE__ */ n(G, {
								gap: 2,
								children: [/* @__PURE__ */ t(H, {
									level: 3,
									variant: "h7",
									children: e
								}), /* @__PURE__ */ t(ct, {
									label: e,
									items: g(r)
								})]
							}, e) : null;
						}), !h.length && /* @__PURE__ */ t(U, {
							variant: "small",
							tone: "secondary",
							children: d ? "No matching projects." : "No projects yet."
						})]
					})
				})
			]
		}), s && /* @__PURE__ */ t(G, {
			gap: 2,
			className: "b-sidebar__account",
			children: /* @__PURE__ */ t(nt, {
				label: s.label,
				icon: "UserRound",
				side: "top",
				items: s.actions,
				onSelect: s.onAction
			})
		})]
	});
}
//#endregion
//#region src/atomic/ui-blocks/PromptInput.tsx
function dt({ value: e, onChange: r, onSubmit: i, files: a = [], onAttach: o, onRemove: s, disabled: c, readOnly: l, busy: u, error: d, label: f = "Prompt", placeholder: p = "Describe what you want to create…", accept: m }) {
	let h = c || l || u, g = !!e.trim() && !h, _ = () => {
		g && i();
	};
	return /* @__PURE__ */ n(Le, {
		label: "AI prompt input",
		"aria-busy": u || void 0,
		onSubmit: (e) => {
			e.preventDefault(), _();
		},
		children: [/* @__PURE__ */ n(lt, {
			label: "Prompt attachments",
			onFiles: l ? void 0 : o,
			disabled: h,
			accept: m,
			actions: !l && /* @__PURE__ */ t(J, {
				type: "submit",
				variant: "primary",
				icon: "arrowUp",
				iconOnly: !0,
				"aria-label": "Send prompt",
				busy: u,
				disabled: !g
			}),
			children: [!!a.length && /* @__PURE__ */ t(K, { children: a.map((e) => s && !h ? /* @__PURE__ */ t(xe, {
				icon: "Paperclip",
				onRemove: () => s(e.id),
				removeLabel: "Remove " + e.name,
				children: e.name
			}, e.id) : /* @__PURE__ */ t(xe, {
				icon: "Paperclip",
				children: e.name
			}, e.id)) }), /* @__PURE__ */ t(ye, {
				label: f,
				hideLabel: !0,
				embedded: !0,
				rows: 5,
				value: e,
				placeholder: p,
				disabled: c || u,
				readOnly: l,
				onChange: (e) => r(e.target.value),
				onKeyDown: (e) => {
					e.key === "Enter" && (e.ctrlKey || e.metaKey) && !e.nativeEvent.isComposing && (e.preventDefault(), _());
				}
			})]
		}), d && /* @__PURE__ */ t(Pe, {
			tone: "danger",
			title: "Could not send prompt",
			description: d
		})]
	});
}
//#endregion
export { Pe as Alert, V as AtomsRoot, lt as AttachmentArea, Ce as Breadcrumbs, J as Button, he as Checkbox, at as Combobox, de as Container, Be as DatePicker, Qe as Dialog, fe as Divider, $e as Drawer, Ge as EmptyState, Ke as FileDropzone, qe as FileList, Le as Form, Re as FormActions, ue as Grid, H as Heading, W as Icon, K as Inline, st as InlineConfirmation, Fe as InlineText, nt as Menu, ot as MultiSelect, ct as NavigationList, Te as NumberStepper, we as Pagination, me as Panel, Ve as PasswordField, et as Popover, Ae as ProgressBar, je as ProgressRing, dt as PromptInput, ge as RadioGroup, De as RangeSlider, Oe as Rating, pe as ScrollArea, He as SearchField, Se as SegmentedControl, be as Select, ut as SidebarPanel, We as Skeleton, Ee as Slider, Ue as Spinner, G as Stack, Ne as StatusBadge, q as Surface, Ye as Table, it as Tabs, xe as Tag, U as Text, Ie as TextAction, ye as TextArea, Q as TextField, Xe as Toast, _e as Toggle, rt as Tooltip, Je as WorkflowSteps, ce as icons, oe as tokenVariables, ie as tokens, ae as typography };
