import type { ReactNode } from 'react';
export type TabItem = {
    value: string;
    label: string;
    disabled?: boolean;
};
export type TabsProps = {
    items: TabItem[];
    value: string;
    onValueChange: (value: string) => void;
    ariaLabel: string;
    idPrefix?: string;
    className?: string;
};
/** Canonical tab interaction. Supply a unique idPrefix for each group and its panels. */
export declare function Tabs(props: TabsProps): import("react").JSX.Element;
/** Source-only bridge for legacy DOM IDs; selection always uses exact values. */
export declare function TabsPrimitive({ items, value, onValueChange, ariaLabel, idPrefix, className, keyForValue }: TabsProps & {
    keyForValue?: (value: string) => string;
}): import("react").JSX.Element;
export type TabPanelProps = {
    value: string;
    activeValue: string;
    idPrefix?: string;
    children: ReactNode;
    className?: string;
};
export declare function TabPanel(props: TabPanelProps): import("react").JSX.Element;
export declare function TabPanelPrimitive({ value, activeValue, idPrefix, children, className, keyForValue }: TabPanelProps & {
    keyForValue?: (value: string) => string;
}): import("react").JSX.Element;
