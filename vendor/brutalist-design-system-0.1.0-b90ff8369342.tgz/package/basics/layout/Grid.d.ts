import type { ComponentProps } from 'react';
import { type Space } from './types';
export type GridProps = ComponentProps<'div'> & {
    gap?: Space;
    minItemWidth?: number;
};
export declare function Grid({ gap, minItemWidth, className, style, ...props }: GridProps): import("react").JSX.Element;
