import type { ComponentProps } from 'react';
import { type Space } from './types';
export type StackProps = ComponentProps<'div'> & {
    gap?: Space;
};
export declare function Stack({ gap, className, style, ...props }: StackProps): import("react").JSX.Element;
