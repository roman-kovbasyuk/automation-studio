export type InlineConfirmationProps = {
    label: string;
    question: string;
    onConfirm: () => void | Promise<void>;
    disabled?: boolean;
    description?: string;
};
export declare function InlineConfirmation({ label, question, onConfirm, disabled, description }: InlineConfirmationProps): import("react").JSX.Element;
