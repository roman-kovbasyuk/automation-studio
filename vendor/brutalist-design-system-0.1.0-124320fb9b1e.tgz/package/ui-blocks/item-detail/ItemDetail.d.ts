import type { ReactNode } from 'react';
import type { SaveResult } from '../../basics/types';
export type DetailItem = {
    id: string;
    revision: string;
    title: string;
    description: string;
};
export type ItemDetailProps = {
    item?: DetailItem;
    loading?: boolean;
    error?: string;
    onRetry?: () => void;
    onSave: (patch: {
        title?: string;
        description?: string;
    }, capturedRevision: string) => Promise<SaveResult>;
    metadata?: ReactNode;
    preview?: ReactNode;
    actions?: ReactNode;
    readOnly?: boolean;
    className?: string;
};
/** A controlled detail block. The caller resolves versions, permissions and persistence. */
export declare function ItemDetail({ item, loading, error, onRetry, onSave, metadata, preview, actions, readOnly, className }: ItemDetailProps): import("react").JSX.Element;
