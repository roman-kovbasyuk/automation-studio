import type { CSSProperties } from 'react';
export type InlineTextProps = {
    label: string;
    value?: string;
    sourceKey?: string;
    onSave: (value: string, sourceKey?: string) => void | {
        ok: boolean;
        message?: string;
    } | Promise<void | {
        ok: boolean;
        message?: string;
    }>;
    onDirty?: (dirty: boolean) => void;
    readOnly?: boolean;
    multiline?: boolean;
    required?: boolean;
    maxLength?: number;
    className?: string;
    style?: CSSProperties;
};
/** A small, keyboard-friendly text editor for a single value. */
export declare function InlineText({ label, value, sourceKey, onSave, onDirty, readOnly, required, maxLength, className, style }: InlineTextProps): import("react").JSX.Element;
