import type { ComponentProps } from 'react';
export type SurfaceProps = ComponentProps<'div'> & {
    tone?: 'canvas' | 'surface';
};
export declare function Surface({ tone, className, ...props }: SurfaceProps): import("react").JSX.Element;
