export type InlineTextProps = {
    label: string;
    value?: string;
    sourceKey?: string;
    onSave: (value: string, sourceKey?: string) => void | {
        ok: boolean;
        message?: string;
    } | Promise<void | {
        ok: boolean;
        message?: string;
    }>;
    onDirty?: (dirty: boolean) => void;
    readOnly?: boolean;
    multiline?: boolean;
    required?: boolean;
    maxLength?: number;
    className?: string;
};
/** A small, keyboard-friendly text editor for a single value. */
export declare function InlineText({ label, value, sourceKey, onSave, onDirty, readOnly, multiline, required, maxLength, className }: InlineTextProps): import("react").JSX.Element;
