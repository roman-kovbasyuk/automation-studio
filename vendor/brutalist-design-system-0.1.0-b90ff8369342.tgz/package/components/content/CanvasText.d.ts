import { type CSSProperties } from 'react';
export type CanvasTextProps = {
    label: string;
    value: string;
    onValueChange: (value: string) => void;
    maxLength?: number;
    required?: boolean;
    readOnly?: boolean;
    placeholder?: string;
    className?: string;
    style?: CSSProperties;
};
/** Native plain-text editing within an artwork slot, without form chrome.
 * The parent owns the value; blur commits and Escape restores the focus snapshot. */
export declare function CanvasText({ label, value, onValueChange, maxLength, required, readOnly, placeholder, className, style }: CanvasTextProps): import("react").JSX.Element;
