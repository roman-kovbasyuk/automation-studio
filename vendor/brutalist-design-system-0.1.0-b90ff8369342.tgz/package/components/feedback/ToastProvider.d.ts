import type { ReactNode } from 'react';
import type { FeedbackTone } from './StatusBadge';
export type ToastInput = {
    title: ReactNode;
    description?: ReactNode;
    tone?: Exclude<FeedbackTone, 'neutral'>;
};
type ToastContextValue = {
    toast: (input: ToastInput) => void;
    dismiss: (id: number) => void;
};
/** Supplies a non-blocking, accessible toast region for an application root. */
export declare function ToastProvider({ children }: {
    children: ReactNode;
}): import("react").JSX.Element;
export declare function useToast(): ToastContextValue;
export {};
