import type { SelectionControlProps, SelectionValue } from './types';
export type ComboboxProps<T extends SelectionValue> = SelectionControlProps<T> & {
    value: T | null;
    onValueChange: (value: T | null) => void;
    clearable?: boolean;
};
/** A controlled, searchable single-value selection field. */
export declare function Combobox<T extends SelectionValue>({ label, options, value, onValueChange, clearable, disabled, placeholder, className, }: ComboboxProps<T>): import("react").JSX.Element;
