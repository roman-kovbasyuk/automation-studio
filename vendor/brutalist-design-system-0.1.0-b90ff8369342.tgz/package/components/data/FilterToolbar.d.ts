import type { ReactNode } from 'react';
export type FilterToolbarProps = {
    query: string;
    onQueryChange: (query: string) => void;
    children?: ReactNode;
    onClear?: () => void;
    resultCount?: number;
    searchLabel?: string;
    className?: string;
};
/** A controlled search and filter composition; callers own filtering and results. */
export declare function FilterToolbar({ query, onQueryChange, children, onClear, resultCount, searchLabel, className }: FilterToolbarProps): import("react").JSX.Element;
