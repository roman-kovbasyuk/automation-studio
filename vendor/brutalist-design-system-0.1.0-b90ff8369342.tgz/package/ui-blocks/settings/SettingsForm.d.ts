import type { SaveResult } from '../../basics/types';
export type SettingsValue = {
    name: string;
    language: string;
    notifications: boolean;
    preferences?: {
        theme: string;
        density: string;
        summary: boolean;
        mentions: boolean;
        replies: boolean;
        sounds: boolean;
    };
};
export type SettingsFormProps = {
    initialValue: SettingsValue;
    onSave(value: SettingsValue): Promise<SaveResult>;
};
export declare function SettingsForm({ initialValue, onSave }: SettingsFormProps): import("react").JSX.Element;
