import { type SliderProps } from './Slider';

export type RangeSliderProps = Omit<SliderProps, 'value' | 'onChange' | 'id' | 'name'> & {
    value: [number, number];
    onChange: (value: [number, number]) => void;
    names?: [string, string];
    lowerLabel?: string;
    upperLabel?: string;
};
/** Two independently labelled native controls preserve accessible keyboard behavior. */
export declare function RangeSlider({ label, value, onChange, min, max, names, lowerLabel, upperLabel, instructions, className, ...props }: RangeSliderProps): import("react").JSX.Element;
