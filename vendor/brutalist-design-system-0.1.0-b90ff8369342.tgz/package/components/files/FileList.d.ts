import type { ReactNode } from 'react';
export type FileListProps = {
    /** Files supplied and owned by the caller. */
    files: readonly File[];
    onRemove?: (index: number) => void;
    emptyMessage?: ReactNode;
    className?: string;
};
/** A presentational file list with a controlled remove callback. */
export declare function FileList({ files, onRemove, emptyMessage, className }: FileListProps): import("react").JSX.Element;
