import type { HTMLAttributes, ReactNode } from 'react';
import { type IconName } from '../atoms';

type Removal = {
    onRemove: () => void;
    removeLabel: string;
} | {
    onRemove?: never;
    removeLabel?: never;
};
export type TagProps = HTMLAttributes<HTMLSpanElement> & Removal & {
    children: ReactNode;
    tone?: 'neutral' | 'accent' | 'success' | 'danger';
    icon?: IconName;
    status?: 'neutral' | 'pending' | 'success' | 'danger';
};
export declare function Tag({ children, tone, icon, status, onRemove, removeLabel, className, ...props }: TagProps): import("react").JSX.Element;
export {};
