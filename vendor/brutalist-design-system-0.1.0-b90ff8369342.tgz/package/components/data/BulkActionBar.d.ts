import type { ReactNode } from 'react';
export type BulkActionBarProps = {
    count: number;
    children?: ReactNode;
    onClear: () => void;
    className?: string;
};
/** A visible selection summary with caller-supplied bulk actions. */
export declare function BulkActionBar({ count, children, onClear, className }: BulkActionBarProps): import("react").JSX.Element;
