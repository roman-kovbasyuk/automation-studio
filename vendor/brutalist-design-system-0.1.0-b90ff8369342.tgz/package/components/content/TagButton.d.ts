import type { ButtonHTMLAttributes, ReactNode } from 'react';
import type { TagTone, TagVariant } from './Tag';
export type TagButtonProps = Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'children'> & {
    children: ReactNode;
    tone?: TagTone;
    variant?: TagVariant;
    dismissible?: boolean;
};
/** An interactive tag-shaped control that shares the canonical Tag treatment. */
export declare function TagButton({ children, tone, variant, dismissible, className, ...props }: TagButtonProps): import("react").JSX.Element;
