import { type ReactNode } from 'react';
export type FileDropzoneProps = {
    /** Visible label and accessible name for the native file input. */
    label: ReactNode;
    /** Called with the newly selected files. The caller owns all file state. */
    onFilesChange: (files: File[]) => void;
    accept?: string;
    multiple?: boolean;
    disabled?: boolean;
    description?: ReactNode;
    chooseLabel?: string;
    className?: string;
    id?: string;
};
/**
 * A controlled local-file picker. It does not upload, validate, or retain files.
 */
export declare function FileDropzone({ label, onFilesChange, accept, multiple, disabled, description, chooseLabel, className, id: providedId, }: FileDropzoneProps): import("react").JSX.Element;
