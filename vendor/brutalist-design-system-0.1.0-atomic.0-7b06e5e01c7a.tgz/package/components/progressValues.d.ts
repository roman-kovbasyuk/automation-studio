export declare function progressValues(value: number, max: number): {
    total: number;
    current: number;
    percent: number;
};
