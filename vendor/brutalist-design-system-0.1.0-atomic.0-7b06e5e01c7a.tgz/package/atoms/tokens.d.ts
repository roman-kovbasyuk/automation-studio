import type { CSSProperties } from 'react';
/** The only value source for the rewrite. Catalog and primitives consume this object. */
export declare const tokens: {
    readonly color: {
        readonly canvas: '#f4f4f0';
        readonly surface: '#ffffff';
        readonly ink: '#000000';
        readonly secondary: '#595959';
        readonly accent: '#79d9ff';
        readonly success: '#23a094';
        readonly danger: '#dc341e';
        readonly editHighlight: 'rgb(0 0 0 / 3%)';
        readonly backdrop: 'rgb(0 0 0 / 35%)';
    };
    readonly space: {
        readonly 0: '0px';
        readonly 1: '4px';
        readonly 2: '8px';
        readonly 3: '12px';
        readonly 4: '16px';
        readonly 6: '24px';
        readonly 8: '32px';
        readonly 12: '48px';
        readonly 16: '64px';
    };
    readonly radius: {
        readonly none: '0px';
        readonly small: '4px';
        readonly large: '20px';
        readonly pill: '999px';
    };
    readonly border: {
        readonly width: '1px';
    };
    readonly size: {
        readonly control: '48px';
        readonly compact: '44px';
        readonly small: '32px';
        readonly choice: '20px';
        readonly marker: '10px';
        readonly switchHeight: '28px';
    };
    readonly icon: {
        readonly small: '16px';
        readonly medium: '20px';
        readonly large: '24px';
        readonly xlarge: '32px';
        readonly display: '48px';
    };
    readonly shadow: {
        readonly none: 'none';
        readonly small: '2px 2px 0 var(--a-color-ink)';
        readonly interactive: '4px 4px 0 var(--a-color-ink)';
        readonly floating: '8px 8px 0 var(--a-color-ink)';
    };
    readonly motion: {
        readonly fast: '150ms';
        readonly disclosure: '200ms';
        readonly ease: 'cubic-bezier(0.4, 0, 0.2, 1)';
        readonly out: 'cubic-bezier(0.22, 1, 0.36, 1)';
        readonly lift: '-2px';
        readonly liftStrong: '-4px';
        readonly spin: '1s';
    };
    readonly state: {
        readonly disabled: '0.45';
    };
    readonly focus: {
        readonly width: '2px';
        readonly offset: '4px';
    };
    readonly layer: {
        readonly base: '0';
        readonly popover: '20';
        readonly modal: '40';
        readonly toast: '60';
    };
    readonly font: {
        readonly family: '"Avenir Next", Avenir, Montserrat, Corbel, "URW Gothic", sans-serif';
    };
};
export declare const typography: {
    readonly h1: {
        readonly size: '48px';
        readonly line: '52px';
        readonly weight: 500;
    };
    readonly h2: {
        readonly size: '32px';
        readonly line: '36px';
        readonly weight: 500;
    };
    readonly h3: {
        readonly size: '24px';
        readonly line: '28px';
        readonly weight: 500;
    };
    readonly h4: {
        readonly size: '20px';
        readonly line: '24px';
        readonly weight: 500;
    };
    readonly h5: {
        readonly size: '18px';
        readonly line: '24px';
        readonly weight: 600;
    };
    readonly h6: {
        readonly size: '16px';
        readonly line: '22px';
        readonly weight: 600;
    };
    readonly h7: {
        readonly size: '14px';
        readonly line: '20px';
        readonly weight: 600;
    };
    readonly leadLarge: {
        readonly size: '24px';
        readonly line: '36px';
        readonly weight: 500;
    };
    readonly leadMedium: {
        readonly size: '20px';
        readonly line: '28px';
        readonly weight: 500;
    };
    readonly body: {
        readonly size: '16px';
        readonly line: '22px';
        readonly weight: 400;
    };
    readonly small: {
        readonly size: '14px';
        readonly line: '20px';
        readonly weight: 400;
    };
};
export type Space = keyof typeof tokens.space;
export type TypeRole = keyof typeof typography;
export type HeadingRole = Extract<TypeRole, `h${number}`>;
export type TextRole = Exclude<TypeRole, HeadingRole>;
export declare const tokenVariables: CSSProperties;
export declare const typeVariables: (role: TypeRole) => CSSProperties;
