export type ProgressProps = {
    value: number;
    max?: number;
    label: string;
    showValue?: boolean;
    className?: string;
};
/** An accessible determinate progress indicator. */
export declare function Progress({ value, max, label, showValue, className }: ProgressProps): import("react").JSX.Element;
