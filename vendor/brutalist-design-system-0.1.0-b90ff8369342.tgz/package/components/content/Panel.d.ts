import { type HTMLAttributes, type ReactNode } from 'react';
export type PanelProps = Omit<HTMLAttributes<HTMLElement>, 'title'> & {
    title: ReactNode;
    description?: ReactNode;
    as?: 'section' | 'div' | 'article';
    children?: ReactNode;
};
/** A neutral wrapper for grouped content with a header and optional subheader. */
export declare function Panel({ title, description, as: Element, children, className, ...props }: PanelProps): import("react").JSX.Element;
