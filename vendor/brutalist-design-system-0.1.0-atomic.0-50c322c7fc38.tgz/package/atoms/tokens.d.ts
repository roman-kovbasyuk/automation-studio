import type { CSSProperties } from 'react';
/** The only value source for the rewrite. Catalog and primitives consume this object. */
export declare const tokens: {
    readonly color: {
        readonly earthy: {
            readonly 0: '#f4f4f0';
            readonly 50: '#efeee8';
            readonly 100: '#e5e3da';
            readonly 200: '#d4d0c3';
            readonly 300: '#bcb6a5';
            readonly 400: '#9f9784';
            readonly 500: '#827966';
            readonly 600: '#685f50';
            readonly 700: '#4f493d';
            readonly 800: '#38342d';
            readonly 900: '#24221e';
            readonly 950: '#151411';
        };
        readonly gray: {
            readonly 0: '#ffffff';
            readonly 50: '#f7f7f7';
            readonly 100: '#eeeeee';
            readonly 200: '#dddddd';
            readonly 300: '#c8c8c8';
            readonly 400: '#adadad';
            readonly 500: '#919191';
            readonly 600: '#737373';
            readonly 700: '#555555';
            readonly 800: '#3b3b3b';
            readonly 900: '#252525';
            readonly 950: '#171717';
        };
        readonly slate: {
            readonly 0: '#f8fafc';
            readonly 50: '#f1f5f9';
            readonly 100: '#e2e8f0';
            readonly 200: '#cbd5e1';
            readonly 300: '#94a3b8';
            readonly 400: '#64748b';
            readonly 500: '#475569';
            readonly 600: '#334155';
            readonly 700: '#1e293b';
            readonly 800: '#0f172a';
            readonly 900: '#020617';
            readonly 950: '#01030a';
        };
        readonly red: {
            readonly 0: '#fff5f5';
            readonly 50: '#ffe3e3';
            readonly 100: '#ffc9c9';
            readonly 200: '#ffa8a8';
            readonly 300: '#ff8787';
            readonly 400: '#ff6b6b';
            readonly 500: '#fa5252';
            readonly 600: '#f03e3e';
            readonly 700: '#e03131';
            readonly 800: '#c92a2a';
            readonly 900: '#b91c1c';
            readonly 950: '#7f1d1d';
        };
        readonly orange: {
            readonly 0: '#fff4e6';
            readonly 50: '#ffe8cc';
            readonly 100: '#ffd8a8';
            readonly 200: '#ffc078';
            readonly 300: '#ffa94d';
            readonly 400: '#ff922b';
            readonly 500: '#fd7e14';
            readonly 600: '#f76707';
            readonly 700: '#e8590c';
            readonly 800: '#d9480f';
            readonly 900: '#c2410c';
            readonly 950: '#7c2d12';
        };
        readonly amber: {
            readonly 0: '#fff8e1';
            readonly 50: '#ffecb3';
            readonly 100: '#ffe082';
            readonly 200: '#ffd54f';
            readonly 300: '#ffca28';
            readonly 400: '#ffb300';
            readonly 500: '#f59f00';
            readonly 600: '#f08c00';
            readonly 700: '#e67700';
            readonly 800: '#d97706';
            readonly 900: '#b45309';
            readonly 950: '#78350f';
        };
        readonly yellow: {
            readonly 0: '#fffde7';
            readonly 50: '#fff9c4';
            readonly 100: '#fff59d';
            readonly 200: '#fff176';
            readonly 300: '#ffee58';
            readonly 400: '#ffeb3b';
            readonly 500: '#fdd835';
            readonly 600: '#fbc02d';
            readonly 700: '#f9a825';
            readonly 800: '#f59e0b';
            readonly 900: '#ca8a04';
            readonly 950: '#713f12';
        };
        readonly green: {
            readonly 0: '#ebfbee';
            readonly 50: '#d3f9d8';
            readonly 100: '#b2f2bb';
            readonly 200: '#8ce99a';
            readonly 300: '#69db7c';
            readonly 400: '#51cf66';
            readonly 500: '#40c057';
            readonly 600: '#37b24d';
            readonly 700: '#2f9e44';
            readonly 800: '#2b8a3e';
            readonly 900: '#237b3b';
            readonly 950: '#14532d';
        };
        readonly teal: {
            readonly 0: '#e6fcf5';
            readonly 50: '#c3fae8';
            readonly 100: '#96f2d7';
            readonly 200: '#63e6be';
            readonly 300: '#38d9a9';
            readonly 400: '#20c997';
            readonly 500: '#12b886';
            readonly 600: '#0ca678';
            readonly 700: '#099268';
            readonly 800: '#087f5b';
            readonly 900: '#067a68';
            readonly 950: '#064e3b';
        };
        readonly cyan: {
            readonly 0: '#e3fafc';
            readonly 50: '#c5f6fa';
            readonly 100: '#99e9f2';
            readonly 200: '#66d9e8';
            readonly 300: '#3bc9db';
            readonly 400: '#22b8cf';
            readonly 500: '#15aabf';
            readonly 600: '#1098ad';
            readonly 700: '#0c8599';
            readonly 800: '#0b7285';
            readonly 900: '#0e7490';
            readonly 950: '#164e63';
        };
        readonly blue: {
            readonly 0: '#f5faff';
            readonly 50: '#e8f3ff';
            readonly 100: '#cfe6ff';
            readonly 200: '#a6d2ff';
            readonly 300: '#72b8ff';
            readonly 400: '#3d98f5';
            readonly 500: '#1677d2';
            readonly 600: '#0d5eac';
            readonly 700: '#0b4a86';
            readonly 800: '#0b3b69';
            readonly 900: '#0b3155';
            readonly 950: '#061d35';
        };
        readonly indigo: {
            readonly 0: '#edf2ff';
            readonly 50: '#dbe4ff';
            readonly 100: '#bac8ff';
            readonly 200: '#91a7ff';
            readonly 300: '#748ffc';
            readonly 400: '#5c7cfa';
            readonly 500: '#4c6ef5';
            readonly 600: '#4263eb';
            readonly 700: '#3b5bdb';
            readonly 800: '#364fc7';
            readonly 900: '#3046a8';
            readonly 950: '#1e2a78';
        };
        readonly violet: {
            readonly 0: '#f3f0ff';
            readonly 50: '#e5dbff';
            readonly 100: '#d0bfff';
            readonly 200: '#b197fc';
            readonly 300: '#9775fa';
            readonly 400: '#845ef7';
            readonly 500: '#7950f2';
            readonly 600: '#7048e8';
            readonly 700: '#6741d9';
            readonly 800: '#5f3dc4';
            readonly 900: '#5235a6';
            readonly 950: '#312e81';
        };
        readonly purple: {
            readonly 0: '#f8f0fc';
            readonly 50: '#f3d9fa';
            readonly 100: '#eebefa';
            readonly 200: '#e599f7';
            readonly 300: '#da77f2';
            readonly 400: '#cc5de8';
            readonly 500: '#be4bdb';
            readonly 600: '#ae3ec9';
            readonly 700: '#9c36b5';
            readonly 800: '#862e9c';
            readonly 900: '#70248f';
            readonly 950: '#581c87';
        };
        readonly pink: {
            readonly 0: '#fff0f6';
            readonly 50: '#ffdeeb';
            readonly 100: '#fcc2d7';
            readonly 200: '#faa2c1';
            readonly 300: '#f783ac';
            readonly 400: '#f06595';
            readonly 500: '#e64980';
            readonly 600: '#d6336c';
            readonly 700: '#c2255c';
            readonly 800: '#a61e4d';
            readonly 900: '#9d174d';
            readonly 950: '#701a40';
        };
        readonly rose: {
            readonly 0: '#fff1f2';
            readonly 50: '#ffe4e6';
            readonly 100: '#fecdd3';
            readonly 200: '#fda4af';
            readonly 300: '#fb7185';
            readonly 400: '#f43f5e';
            readonly 500: '#e11d48';
            readonly 600: '#be123c';
            readonly 700: '#9f1239';
            readonly 800: '#881337';
            readonly 900: '#701a35';
            readonly 950: '#4c0519';
        };
        readonly static: {
            readonly black: '#000000';
            readonly white: '#ffffff';
        };
        readonly canvas: '#f4f4f0';
        readonly surface: '#ffffff';
        readonly ink: '#000000';
        readonly secondary: '#595959';
        readonly accent: '#79d9ff';
        readonly success: '#23a094';
        readonly danger: '#dc341e';
        readonly editHighlight: 'rgb(0 0 0 / 3%)';
        readonly backdrop: 'rgb(0 0 0 / 35%)';
    };
    readonly space: {
        readonly 0: '0px';
        readonly 1: '4px';
        readonly 2: '8px';
        readonly 3: '12px';
        readonly 4: '16px';
        readonly 6: '24px';
        readonly 8: '32px';
        readonly 12: '48px';
        readonly 16: '64px';
    };
    readonly radius: {
        readonly none: '0px';
        readonly small: '4px';
        readonly large: '20px';
        readonly pill: '999px';
    };
    readonly border: {
        readonly width: '1px';
    };
    readonly size: {
        readonly control: '48px';
        readonly compact: '44px';
        readonly small: '32px';
        readonly choice: '20px';
        readonly marker: '10px';
        readonly switchHeight: '28px';
    };
    readonly icon: {
        readonly small: '16px';
        readonly medium: '20px';
        readonly large: '24px';
        readonly xlarge: '32px';
        readonly display: '48px';
    };
    readonly shadow: {
        readonly none: 'none';
        readonly small: '2px 2px 0 var(--a-color-ink)';
        readonly interactive: '4px 4px 0 var(--a-color-ink)';
        readonly floating: '8px 8px 0 var(--a-color-ink)';
    };
    readonly motion: {
        readonly fast: '150ms';
        readonly disclosure: '200ms';
        readonly ease: 'cubic-bezier(0.4, 0, 0.2, 1)';
        readonly out: 'cubic-bezier(0.22, 1, 0.36, 1)';
        readonly lift: '-2px';
        readonly liftStrong: '-4px';
        readonly spin: '1s';
    };
    readonly state: {
        readonly disabled: '0.45';
    };
    readonly focus: {
        readonly width: '2px';
        readonly offset: '4px';
    };
    readonly layer: {
        readonly base: '0';
        readonly popover: '20';
        readonly modal: '40';
        readonly toast: '60';
    };
    readonly font: {
        readonly family: '"Avenir Next", Avenir, Montserrat, Corbel, "URW Gothic", sans-serif';
    };
};
export declare const typography: {
    readonly h1: {
        readonly size: '48px';
        readonly line: '52px';
        readonly weight: 500;
    };
    readonly h2: {
        readonly size: '32px';
        readonly line: '36px';
        readonly weight: 500;
    };
    readonly h3: {
        readonly size: '24px';
        readonly line: '28px';
        readonly weight: 500;
    };
    readonly h4: {
        readonly size: '20px';
        readonly line: '24px';
        readonly weight: 500;
    };
    readonly h5: {
        readonly size: '18px';
        readonly line: '24px';
        readonly weight: 600;
    };
    readonly h6: {
        readonly size: '16px';
        readonly line: '22px';
        readonly weight: 600;
    };
    readonly h7: {
        readonly size: '14px';
        readonly line: '20px';
        readonly weight: 600;
    };
    readonly leadLarge: {
        readonly size: '24px';
        readonly line: '36px';
        readonly weight: 500;
    };
    readonly leadMedium: {
        readonly size: '20px';
        readonly line: '28px';
        readonly weight: 500;
    };
    readonly body: {
        readonly size: '16px';
        readonly line: '22px';
        readonly weight: 400;
    };
    readonly small: {
        readonly size: '14px';
        readonly line: '20px';
        readonly weight: 400;
    };
};
export type Space = keyof typeof tokens.space;
export type TypeRole = keyof typeof typography;
export type HeadingRole = Extract<TypeRole, `h${number}`>;
export type TextRole = Exclude<TypeRole, HeadingRole>;
export declare const tokenVariables: CSSProperties;
export declare const typeVariables: (role: TypeRole) => CSSProperties;
