import type { ReactNode } from 'react';

export type TableSort = {
    column: string;
    direction: 'asc' | 'desc';
};
export type TableColumn<T> = {
    id: string;
    header: string;
    render: (row: T) => ReactNode;
    sortable?: boolean;
};
export type TableProps<T> = {
    label: string;
    rows: readonly T[];
    rowKey: (row: T) => string;
    columns: readonly TableColumn<T>[];
    sort?: TableSort;
    onSort?: (sort: TableSort) => void;
    emptyMessage?: string;
};
export declare function Table<T>({ label, rows, rowKey, columns, sort, onSort, emptyMessage }: TableProps<T>): import("react").JSX.Element;
