import { type ReactNode } from 'react';

export type AttachmentAreaProps = {
    label: string;
    children: ReactNode;
    actions?: ReactNode;
    onFiles?: (files: File[]) => void;
    disabled?: boolean;
    accept?: string;
    maxSize?: number;
};
export declare function AttachmentArea({ label, children, actions, onFiles, disabled, accept, maxSize }: AttachmentAreaProps): import("react").JSX.Element;
