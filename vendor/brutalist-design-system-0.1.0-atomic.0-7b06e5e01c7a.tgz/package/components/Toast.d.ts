import { type AlertProps } from './Alert';
export type ToastProps = Omit<AlertProps, 'announce' | 'action'> & {
    onDismiss: () => void;
};
export declare function Toast({ onDismiss, ...props }: ToastProps): import("react").JSX.Element;
