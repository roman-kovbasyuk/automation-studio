import type { ReactNode } from 'react';
export type AIResultProps = {
    title: ReactNode;
    children?: ReactNode;
    actionLabel?: string;
    onAction?: () => void;
    className?: string;
};
/** A generic result surface; selection and persistence stay with the caller. */
export declare function AIResult({ title, children, actionLabel, onAction, className }: AIResultProps): import("react").JSX.Element;
