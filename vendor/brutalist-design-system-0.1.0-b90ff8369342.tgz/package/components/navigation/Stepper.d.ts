export type Step = {
    label: string;
    description?: string;
    disabled?: boolean;
};
export type StepperProps = {
    steps: Step[];
    activeStep: number;
    ariaLabel?: string;
    className?: string;
};
/** Read-only workflow progress that identifies completed, current, and waiting steps. */
export declare function Stepper({ steps, activeStep, ariaLabel, className }: StepperProps): import("react").JSX.Element;
