import type { ReactNode } from 'react';
export type FeedbackTone = 'neutral' | 'success' | 'warning' | 'danger' | 'info';
export type StatusBadgeProps = {
    children: ReactNode;
    tone?: FeedbackTone;
    className?: string;
};
/** A compact, text-first status indicator. */
export declare function StatusBadge({ children, tone, className }: StatusBadgeProps): import("react").JSX.Element;
