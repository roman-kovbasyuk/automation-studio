import type { ComponentProps } from 'react';
export type ScrollAreaProps = Omit<ComponentProps<'div'>, 'aria-label' | 'role'> & {
    label: string;
};
export declare function ScrollArea({ label, className, tabIndex, ...props }: ScrollAreaProps): import("react").JSX.Element;
