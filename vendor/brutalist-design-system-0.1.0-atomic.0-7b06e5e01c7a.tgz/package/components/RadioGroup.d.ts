import { type ReactNode } from 'react';

export type RadioOption = {
    value: string;
    label: ReactNode;
    disabled?: boolean;
};
export type RadioGroupProps = {
    id?: string;
    name?: string;
    label: ReactNode;
    instructions?: ReactNode;
    error?: ReactNode;
    options: readonly RadioOption[];
    value?: string;
    defaultValue?: string;
    onChange?: (value: string) => void;
    customOption?: {
        value: string;
        label: string;
        text: string;
        onTextChange: (text: string) => void;
        placeholder?: string;
    };
    disabled?: boolean;
    required?: boolean;
    className?: string;
};
export declare function RadioGroup({ id, name, label, instructions, error, options, value, defaultValue, onChange, disabled, required, className, customOption }: RadioGroupProps): import("react").JSX.Element;
