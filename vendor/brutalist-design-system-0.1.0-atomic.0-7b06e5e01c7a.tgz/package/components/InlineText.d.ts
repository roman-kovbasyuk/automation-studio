import { type TypeRole } from '../atoms';

export type InlineTextProps = {
    label: string;
    value: string;
    variant?: TypeRole;
    sourceKey?: string;
    readOnly?: boolean;
    required?: boolean;
    maxLength?: number;
    className?: string;
    onSave: (value: string, sourceKey?: string) => void | {
        ok: boolean;
        message?: string;
    } | Promise<void | {
        ok: boolean;
        message?: string;
    }>;
};
export declare function InlineText({ label, value, variant, sourceKey, readOnly, required, maxLength, onSave, className }: InlineTextProps): import("react").JSX.Element;
