
export type WorkflowStep = {
    id: string;
    label: string;
    description?: string;
    complete?: boolean;
    disabled?: boolean;
};
export type WorkflowStepsProps = {
    label: string;
    steps: readonly WorkflowStep[];
    current: string;
    onChange: (id: string) => void;
    orientation?: 'horizontal' | 'vertical';
};
export declare function WorkflowSteps({ label, steps, current, onChange, orientation }: WorkflowStepsProps): import("react").JSX.Element;
