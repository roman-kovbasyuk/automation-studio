
export type ProgressBarProps = {
    label: string;
    value?: number;
    max?: number;
    showValue?: boolean;
    className?: string;
};
export declare function ProgressBar({ label, value, max, showValue, className }: ProgressBarProps): import("react").JSX.Element;
