import type { ComponentProps } from 'react';
export type DividerProps = ComponentProps<'hr'>;
export declare function Divider({ className, ...props }: DividerProps): import("react").JSX.Element;
