import type { ComponentProps } from 'react';
import { AppButton } from './AppButton';
export declare function TextAction({ children, className, ...props }: ComponentProps<typeof AppButton>): import("react").JSX.Element;
