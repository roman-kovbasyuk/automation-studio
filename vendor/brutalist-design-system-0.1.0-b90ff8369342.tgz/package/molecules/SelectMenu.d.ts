import './select-menu.css';
export type SelectMenuProps = {
    label: string;
    value: string;
    options: (string | {
        label: string;
        icon?: import('react').ComponentType<{
            size?: number;
            'aria-hidden'?: string;
        }>;
        value?: string;
    })[];
    onChange: (value: string) => void;
    triggerLabel?: string;
    triggerId?: string;
    describedBy?: string;
    disabled?: boolean;
};
/**
 * @typedef {{
 *   label: string,
 *   value: string,
 *   options: (string | { label: string, icon?: import('react').ComponentType<{ size?: number, 'aria-hidden'?: string }>, value?: string })[],
 *   onChange: (value: string) => void,
 *   triggerLabel?: string,
 *   triggerId?: string,
 *   describedBy?: string,
 *   disabled?: boolean,
 * }} SelectMenuProps
 */
/** Small, single-selection lists. For native form submission prefer a native select. */
/** @param {SelectMenuProps} props */
export declare function SelectMenu({ label, value, options, onChange, triggerLabel, triggerId, describedBy, disabled, showOptionIcons }: SelectMenuProps): import("react").JSX.Element;
