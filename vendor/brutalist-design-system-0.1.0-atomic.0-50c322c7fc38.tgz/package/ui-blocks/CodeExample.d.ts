import { type ReactNode } from 'react';
import { type HeadingProps } from '../atoms';

export type CodeExampleProps = {
    title: string;
    description?: string;
    filename: string;
    source: string;
    preview?: ReactNode;
    controls?: ReactNode;
    copyable?: boolean;
    headingLevel?: HeadingProps['level'];
    className?: string;
};
/** Canonical documentation example: existing Panel, controls and layout atoms. */
export declare function CodeExample({ title, description, filename, source, preview, controls, copyable, headingLevel, className }: CodeExampleProps): import("react").JSX.Element;
