import type { ReactNode } from 'react';
export type AppLayoutProps = {
    navigation: ReactNode;
    header: ReactNode;
    children: ReactNode;
    inspector?: ReactNode;
    feedback?: ReactNode;
    className?: string;
};
/** A product-neutral application frame composed from caller-owned slots. */
export declare function AppLayout({ navigation, header, children, inspector, feedback, className }: AppLayoutProps): import("react").JSX.Element;
