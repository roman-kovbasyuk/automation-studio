import type { HTMLAttributes } from 'react';
import { type HeadingRole, type TypeRole } from './tokens';
type ElementProps = HTMLAttributes<HTMLElement>;
export declare function AtomsRoot({ className, style, ...props }: HTMLAttributes<HTMLDivElement>): import("react").JSX.Element;
export type HeadingProps = ElementProps & {
    level: 1 | 2 | 3 | 4 | 5 | 6;
    variant?: HeadingRole;
};
export declare function Heading({ level, variant, className, style, ...props }: HeadingProps): import("react").JSX.Element;
export type TextProps = ElementProps & {
    as?: 'p' | 'span' | 'div';
    variant?: TypeRole;
    tone?: 'ink' | 'secondary' | 'inherit';
};
export declare function Text({ as: Tag, variant, tone, className, style, ...props }: TextProps): import("react").JSX.Element;
export {};
