import type { HTMLAttributes } from 'react';
import type { Space, tokens } from './tokens';
type Props = HTMLAttributes<HTMLDivElement>;
type LayoutProps = Props & {
    gap?: Space;
};
export declare function Stack({ gap, className, style, ...props }: LayoutProps): import("react").JSX.Element;
export declare function Inline({ gap, className, style, ...props }: LayoutProps): import("react").JSX.Element;
export declare function Grid({ gap, minItemWidth, className, style, ...props }: LayoutProps & {
    minItemWidth?: string;
}): import("react").JSX.Element;
export declare function Container({ className, style, maxWidth, ...props }: Props & {
    maxWidth?: string;
}): import("react").JSX.Element;
export type SurfaceProps = Props & {
    as?: 'div' | 'section' | 'article' | 'aside';
    padding?: Space;
    radius?: keyof typeof tokens.radius;
    elevation?: keyof typeof tokens.shadow;
    tone?: 'canvas' | 'surface';
};
export declare function Surface({ as: Tag, padding, radius, elevation, tone, className, style, ...props }: SurfaceProps): import("react").JSX.Element;
export declare function Divider(props: HTMLAttributes<HTMLHRElement>): import("react").JSX.Element;
export declare function ScrollArea({ label, className, style, maxHeight, ...props }: Props & {
    label: string;
    maxHeight?: string;
}): import("react").JSX.Element;
export {};
