import { type HTMLAttributes } from 'react';

export type SegmentOption = {
    value: string;
    label: string;
    disabled?: boolean;
};
export type SegmentedControlProps = Omit<HTMLAttributes<HTMLDivElement>, 'onChange' | 'defaultValue'> & {
    label: string;
    options: readonly SegmentOption[];
    size?: 'default' | 'compact';
    value?: string;
    defaultValue?: string;
    onChange?: (value: string) => void;
    name?: string;
    disabled?: boolean;
};
export declare function SegmentedControl({ label, options, size, value, defaultValue, onChange, name, disabled, className, style, ...props }: SegmentedControlProps): import("react").JSX.Element;
