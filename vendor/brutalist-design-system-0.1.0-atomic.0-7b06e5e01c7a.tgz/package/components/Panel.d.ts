import { type ReactNode } from 'react';
import { type HeadingProps, type SurfaceProps } from '../atoms';

export type PanelProps = Omit<SurfaceProps, 'title' | 'padding' | 'radius' | 'elevation' | 'tone'> & {
    title: ReactNode;
    description?: ReactNode;
    headingLevel?: HeadingProps['level'];
    variant?: 'default' | 'split';
    filters?: ReactNode;
};
export declare function Panel({ title, description, headingLevel, variant, filters, as, children, className, ...props }: PanelProps): import("react").JSX.Element;
