import type { InputHTMLAttributes, ReactNode } from 'react';
export type TextFieldProps = Omit<InputHTMLAttributes<HTMLInputElement>, 'id' | 'aria-describedby' | 'aria-invalid'> & {
    id?: string;
    label: ReactNode;
    instructions?: ReactNode;
    error?: ReactNode;
};
/** A labelled native text input with canonical helper and error wiring. */
export declare function TextField({ id: providedId, label, instructions, error, className, ...props }: TextFieldProps): import("react").JSX.Element;
