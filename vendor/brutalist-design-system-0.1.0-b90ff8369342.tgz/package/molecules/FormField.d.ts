import './form-field.css';
export type FormFieldSlot = {
    id: string;
    describedBy?: string;
};
export type FormFieldProps = Omit<import('react').InputHTMLAttributes<HTMLInputElement>, 'children' | 'id'> & {
    label: import('react').ReactNode;
    id?: string;
    hint?: import('react').ReactNode;
    error?: import('react').ReactNode;
    children?: (slot: FormFieldSlot) => import('react').ReactNode;
};
/**
 * @typedef {{ id: string, describedBy?: string }} FormFieldSlot
 * @typedef {Omit<import('react').InputHTMLAttributes<HTMLInputElement>, 'children' | 'id'> & {
 *   label: import('react').ReactNode,
 *   id?: string,
 *   hint?: import('react').ReactNode,
 *   error?: import('react').ReactNode,
 *   children?: (slot: FormFieldSlot) => import('react').ReactNode,
 * }} FormFieldProps
 */
/** Persistent label with canonical helper/error placement, or a shared control slot. */
/** @param {FormFieldProps} props */
export declare function FormField({ label, id: suppliedId, hint, error, children, ...inputProps }: FormFieldProps): import("react").JSX.Element;
