import type { SelectionControlProps, SelectionValue } from './types';
export type MultiSelectProps<T extends SelectionValue> = SelectionControlProps<T> & {
    value: readonly T[];
    onValueChange: (value: T[]) => void;
};
/** A controlled, searchable multi-value selection field. */
export declare function MultiSelect<T extends SelectionValue>({ label, options, value, onValueChange, disabled, placeholder, className, }: MultiSelectProps<T>): import("react").JSX.Element;
