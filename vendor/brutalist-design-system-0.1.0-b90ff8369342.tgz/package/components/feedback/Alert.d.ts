import type { ReactNode } from 'react';
import type { FeedbackTone } from './StatusBadge';
export type AlertProps = {
    title?: ReactNode;
    children?: ReactNode;
    tone?: Exclude<FeedbackTone, 'neutral'>;
    onDismiss?: () => void;
    className?: string;
};
/** A persistent inline message for errors, warnings, and useful context. */
export declare function Alert({ title, children, tone, onDismiss, className }: AlertProps): import("react").JSX.Element;
