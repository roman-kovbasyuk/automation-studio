import { type ReactNode } from 'react';
import { type SegmentedControlProps } from './SegmentedControl';


export type TabItem = {
    id: string;
    label: string;
    content: ReactNode;
    disabled?: boolean;
};
export type TabsProps = {
    label: string;
    items: readonly TabItem[];
    value?: string;
    onChange?: (value: string) => void;
} | SegmentedControlProps;
export declare function Tabs(props: TabsProps): import("react").JSX.Element;
