import type { ReactNode } from 'react';

export type AlertProps = {
    title: string;
    description?: ReactNode;
    tone?: 'neutral' | 'success' | 'danger';
    showIcon?: boolean;
    announce?: boolean;
    className?: string;
    action?: ReactNode;
};
export declare function Alert({ title, description, tone, showIcon, announce, className, action }: AlertProps): import("react").JSX.Element;
