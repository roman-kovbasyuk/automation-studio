import type { SelectOption } from './Select';


export type MultiSelectProps = {
    label: string;
    value: readonly string[];
    onChange: (value: string[]) => void;
    options: readonly SelectOption[];
    disabled?: boolean;
    name?: string;
};
export declare function MultiSelect({ label, value, onChange, options, disabled, name }: MultiSelectProps): import("react").JSX.Element;
