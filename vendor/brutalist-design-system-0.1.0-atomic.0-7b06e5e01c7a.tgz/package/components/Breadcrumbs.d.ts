import type { ReactNode } from 'react';

export type BreadcrumbItem = {
    label: ReactNode;
    href?: string;
};
export type BreadcrumbsProps = {
    items: readonly BreadcrumbItem[];
    label?: string;
    className?: string;
};
export declare function Breadcrumbs({ items, label, className }: BreadcrumbsProps): import("react").JSX.Element;
