import { Fragment as e, jsx as t, jsxs as n } from "react/jsx-runtime";
import { Check as r, LoaderCircle as i, Pencil as a, Plus as o, TriangleAlert as s, X as c } from "lucide-react";
import { createContext as l, useCallback as u, useContext as d, useEffect as f, useId as p, useImperativeHandle as m, useMemo as h, useRef as g, useState as _ } from "react";
import { Dialog as v, DropdownMenu as y, Popover as b, Tooltip as x } from "radix-ui";
//#region src/components/design-system/basics/DesignSystemRoot.tsx
function S({ className: e = "", ...n }) {
	return /* @__PURE__ */ t("div", {
		...n,
		className: `ds-root ${e}`.trim()
	});
}
//#endregion
//#region src/components/design-system/basics/layout/Container.tsx
function C({ maxWidth: e = 1200, className: n = "", style: r, ...i }) {
	return /* @__PURE__ */ t("div", {
		...i,
		className: `ds-container ${n}`.trim(),
		style: {
			...r,
			"--ds-container-max": `${e}px`
		}
	});
}
//#endregion
//#region src/components/design-system/basics/layout/Divider.tsx
function w({ className: e = "", ...n }) {
	return /* @__PURE__ */ t("hr", {
		...n,
		className: `ds-divider ${e}`.trim()
	});
}
//#endregion
//#region src/components/design-system/basics/layout/types.ts
function T(e) {
	return `var(--v2-space-${e ?? 4})`;
}
//#endregion
//#region src/components/design-system/basics/layout/Grid.tsx
function E({ gap: e, minItemWidth: n = 280, className: r = "", style: i, ...a }) {
	return /* @__PURE__ */ t("div", {
		...a,
		className: `ds-grid ${r}`.trim(),
		style: {
			...i,
			"--ds-gap": T(e),
			"--ds-grid-min": `${n}px`
		}
	});
}
//#endregion
//#region src/components/design-system/basics/layout/Inline.tsx
function D({ gap: e, className: n = "", style: r, ...i }) {
	return /* @__PURE__ */ t("div", {
		...i,
		className: `ds-inline ${n}`.trim(),
		style: {
			...r,
			"--ds-gap": T(e)
		}
	});
}
//#endregion
//#region src/components/design-system/basics/layout/ScrollArea.tsx
function O({ label: e, className: n = "", tabIndex: r, ...i }) {
	return /* @__PURE__ */ t("div", {
		...i,
		"aria-label": e,
		className: `ds-scroll-area ${n}`.trim(),
		role: "region",
		tabIndex: r ?? 0
	});
}
//#endregion
//#region src/components/design-system/basics/layout/Stack.tsx
function k({ gap: e, className: n = "", style: r, ...i }) {
	return /* @__PURE__ */ t("div", {
		...i,
		className: `ds-stack ${n}`.trim(),
		style: {
			...r,
			"--ds-gap": T(e)
		}
	});
}
//#endregion
//#region src/components/design-system/basics/layout/Surface.tsx
function A({ tone: e = "surface", className: n = "", ...r }) {
	return /* @__PURE__ */ t("div", {
		...r,
		className: `ds-surface ds-surface--${e} ${n}`.trim()
	});
}
//#endregion
//#region src/components/design-system/components/actions/AppButton.tsx
function j(e) {
	if (e.as === "a") {
		let { children: r, as: a, variant: o = "secondary", size: s = "default", iconOnly: c = !1, busy: l = !1, disabled: u = !1, className: d = "", onClick: f, ...p } = e, m = l || u, h = [
			"ds-button",
			`ds-button--${o === "icon" ? "secondary" : o}`,
			(c || o === "icon") && "ds-button--icon",
			d
		].filter(Boolean).join(" "), g = (e) => {
			if (m) {
				e.preventDefault(), e.stopPropagation();
				return;
			}
			f?.(e);
		};
		return /* @__PURE__ */ n("a", {
			...p,
			className: h,
			"data-size": s,
			"aria-busy": l || void 0,
			"aria-disabled": m || void 0,
			tabIndex: m ? -1 : p.tabIndex,
			onClick: g,
			children: [l && /* @__PURE__ */ t(i, {
				size: 16,
				className: "ds-button__spinner",
				"aria-hidden": "true"
			}), r]
		});
	}
	let { children: r, variant: a = "secondary", size: o = "default", iconOnly: s = !1, busy: c = !1, disabled: l = !1, className: u = "", onClick: d, ...f } = e, p = c || l, m = [
		"ds-button",
		`ds-button--${a === "icon" ? "secondary" : a}`,
		(s || a === "icon") && "ds-button--icon",
		u
	].filter(Boolean).join(" ");
	return /* @__PURE__ */ n("button", {
		...f,
		type: e.type ?? "button",
		className: m,
		"data-size": o,
		"aria-busy": c || void 0,
		disabled: p,
		onClick: d,
		children: [c && /* @__PURE__ */ t(i, {
			size: 16,
			className: "ds-button__spinner",
			"aria-hidden": "true"
		}), r]
	});
}
//#endregion
//#region src/components/design-system/components/actions/TextAction.tsx
function ee({ children: e, className: n = "", ...r }) {
	return /* @__PURE__ */ t(j, {
		...r,
		variant: "quiet",
		size: "compact",
		className: `ds-text-action ${n}`,
		children: e
	});
}
//#endregion
//#region src/components/design-system/components/forms/FieldSupport.tsx
function M(e) {
	let t = p();
	return e ?? `ds-field-${t.replace(/:/g, "")}`;
}
function N(e, t, n) {
	let r = [t ? `${e}-instructions` : void 0, n ? `${e}-error` : void 0].filter(Boolean);
	return r.length ? r.join(" ") : void 0;
}
function P({ id: r, instructions: i, error: a }) {
	return /* @__PURE__ */ n(e, { children: [i && /* @__PURE__ */ t("p", {
		id: `${r}-instructions`,
		className: "ds-field__instructions",
		children: i
	}), a && /* @__PURE__ */ t("p", {
		id: `${r}-error`,
		className: "ds-field__error",
		role: "alert",
		children: a
	})] });
}
//#endregion
//#region src/components/design-system/components/forms/CheckboxField.tsx
function F({ id: e, label: r, instructions: i, error: a, indeterminate: o = !1, ref: s, className: c = "", ...l }) {
	let u = M(e), d = g(null);
	return m(s, () => d.current, []), f(() => {
		d.current && (d.current.indeterminate = o);
	}, [o]), /* @__PURE__ */ n("div", {
		className: `ds-choice-field ${c}`.trim(),
		"data-mixed": o || void 0,
		children: [/* @__PURE__ */ n("label", {
			className: "ds-choice-field__label",
			htmlFor: u,
			children: [/* @__PURE__ */ t("input", {
				...l,
				ref: d,
				id: u,
				type: "checkbox",
				"aria-checked": o ? "mixed" : void 0,
				className: "ds-choice-field__control",
				"aria-describedby": N(u, i, a),
				"aria-invalid": a ? !0 : void 0
			}), /* @__PURE__ */ t("span", { children: r })]
		}), /* @__PURE__ */ t(P, {
			id: u,
			instructions: i,
			error: a
		})]
	});
}
//#endregion
//#region src/components/design-system/components/forms/RadioGroup.tsx
function te({ id: e, name: r, label: i, instructions: a, error: o, options: s, value: c, defaultValue: l, onChange: u, disabled: d = !1, className: f = "" }) {
	let m = M(e), h = p(), g = r ?? `ds-radio-${h.replace(/:/g, "")}`;
	return /* @__PURE__ */ n("fieldset", {
		className: `ds-radio-group ${f}`.trim(),
		"aria-describedby": N(m, a, o),
		children: [
			/* @__PURE__ */ t("legend", {
				className: "ds-field__label",
				children: i
			}),
			/* @__PURE__ */ t("div", {
				className: "ds-radio-group__options",
				role: "radiogroup",
				"aria-label": typeof i == "string" ? i : void 0,
				children: s.map((e) => {
					let r = `${m}-${e.value}`;
					return /* @__PURE__ */ n("label", {
						className: "ds-choice-field__label",
						htmlFor: r,
						children: [/* @__PURE__ */ t("input", {
							id: r,
							className: "ds-choice-field__control",
							type: "radio",
							name: g,
							value: e.value,
							checked: c === void 0 ? void 0 : c === e.value,
							defaultChecked: l === e.value,
							disabled: d || e.disabled,
							"aria-invalid": o ? !0 : void 0,
							onChange: () => u?.(e.value)
						}), /* @__PURE__ */ t("span", { children: e.label })]
					}, e.value);
				})
			}),
			/* @__PURE__ */ t(P, {
				id: m,
				instructions: a,
				error: o
			})
		]
	});
}
//#endregion
//#region src/components/design-system/components/forms/SelectField.tsx
function ne({ id: e, label: r, instructions: i, error: a, options: o, className: s = "", ...c }) {
	let l = M(e);
	return /* @__PURE__ */ n("div", {
		className: `ds-field ${s}`.trim(),
		children: [
			/* @__PURE__ */ t("label", {
				className: "ds-field__label",
				htmlFor: l,
				children: r
			}),
			/* @__PURE__ */ t("select", {
				...c,
				id: l,
				className: "ds-field__control",
				"aria-describedby": N(l, i, a),
				"aria-invalid": a ? !0 : void 0,
				children: o.map((e) => /* @__PURE__ */ t("option", {
					value: e.value,
					disabled: e.disabled,
					children: e.label
				}, e.value))
			}),
			/* @__PURE__ */ t(P, {
				id: l,
				instructions: i,
				error: a
			})
		]
	});
}
//#endregion
//#region src/components/design-system/components/forms/SwitchField.tsx
function re({ id: e, label: r, instructions: i, error: a, onCheckedChange: o, className: s = "", ...c }) {
	let l = M(e);
	return /* @__PURE__ */ n("div", {
		className: `ds-switch-field ${s}`.trim(),
		children: [/* @__PURE__ */ n("label", {
			className: "ds-switch-field__label",
			htmlFor: l,
			children: [
				/* @__PURE__ */ t("input", {
					...c,
					id: l,
					type: "checkbox",
					role: "switch",
					className: "ds-switch-field__control",
					"aria-describedby": N(l, i, a),
					"aria-invalid": a ? !0 : void 0,
					onChange: (e) => o?.(e.currentTarget.checked)
				}),
				/* @__PURE__ */ t("span", {
					className: "ds-switch-field__track",
					"aria-hidden": "true",
					children: /* @__PURE__ */ t("span", { className: "ds-switch-field__thumb" })
				}),
				/* @__PURE__ */ t("span", { children: r })
			]
		}), /* @__PURE__ */ t(P, {
			id: l,
			instructions: i,
			error: a
		})]
	});
}
//#endregion
//#region src/components/design-system/components/forms/TextArea.tsx
function ie({ id: e, label: r, instructions: i, error: a, className: o = "", ...s }) {
	let c = M(e);
	return /* @__PURE__ */ n("div", {
		className: `ds-field ${o}`.trim(),
		children: [
			/* @__PURE__ */ t("label", {
				className: "ds-field__label",
				htmlFor: c,
				children: r
			}),
			/* @__PURE__ */ t("textarea", {
				...s,
				id: c,
				className: "ds-field__control ds-field__control--textarea",
				"aria-describedby": N(c, i, a),
				"aria-invalid": a ? !0 : void 0
			}),
			/* @__PURE__ */ t(P, {
				id: c,
				instructions: i,
				error: a
			})
		]
	});
}
//#endregion
//#region src/components/design-system/components/forms/TextField.tsx
function I({ id: e, label: r, instructions: i, error: a, className: o = "", ...s }) {
	let c = M(e);
	return /* @__PURE__ */ n("div", {
		className: `ds-field ${o}`.trim(),
		children: [
			/* @__PURE__ */ t("label", {
				className: "ds-field__label",
				htmlFor: c,
				children: r
			}),
			/* @__PURE__ */ t("input", {
				...s,
				id: c,
				className: "ds-field__control",
				"aria-describedby": N(c, i, a),
				"aria-invalid": a ? !0 : void 0
			}),
			/* @__PURE__ */ t(P, {
				id: c,
				instructions: i,
				error: a
			})
		]
	});
}
//#endregion
//#region src/components/design-system/components/navigation/Breadcrumbs.tsx
function ae({ items: e, ariaLabel: r = "Breadcrumb", className: i = "" }) {
	return /* @__PURE__ */ t("nav", {
		className: `ds-breadcrumbs ${i}`.trim(),
		"aria-label": r,
		children: /* @__PURE__ */ t("ol", { children: e.map((r, i) => {
			let a = i === e.length - 1;
			return /* @__PURE__ */ n("li", { children: [i > 0 && /* @__PURE__ */ t("span", {
				className: "ds-breadcrumbs__separator",
				"aria-hidden": "true",
				children: "/"
			}), r.href && !a ? /* @__PURE__ */ t("a", {
				href: r.href,
				children: r.label
			}) : /* @__PURE__ */ t("span", {
				"aria-current": a ? "page" : void 0,
				children: r.label
			})] }, i);
		}) })
	});
}
//#endregion
//#region src/components/design-system/components/navigation/Pagination.tsx
function L({ page: e, pageCount: r, onPageChange: i, className: a = "" }) {
	let o = Math.min(Math.max(e, 1), Math.max(r, 1)), s = Array.from({ length: Math.max(r, 0) }, (e, t) => t + 1);
	return /* @__PURE__ */ n("nav", {
		className: `ds-pagination ${a}`.trim(),
		"aria-label": "Pagination",
		children: [
			/* @__PURE__ */ t("button", {
				type: "button",
				"aria-label": "Previous page",
				disabled: o <= 1,
				onClick: () => i(o - 1),
				children: "Previous"
			}),
			/* @__PURE__ */ t("ol", { children: s.map((e) => /* @__PURE__ */ t("li", { children: /* @__PURE__ */ t("button", {
				type: "button",
				"aria-label": `Page ${e}`,
				"aria-current": e === o ? "page" : void 0,
				onClick: () => i(e),
				children: e
			}) }, e)) }),
			/* @__PURE__ */ t("button", {
				type: "button",
				"aria-label": "Next page",
				disabled: o >= r,
				onClick: () => i(o + 1),
				children: "Next"
			})
		]
	});
}
//#endregion
//#region src/components/design-system/components/navigation/SegmentedControl.tsx
function R({ options: e, value: r, onValueChange: i, ariaLabel: a, className: o = "" }) {
	return /* @__PURE__ */ t("div", {
		className: `ds-segmented-control ${o}`.trim(),
		role: "radiogroup",
		"aria-label": a,
		children: e.map((e) => /* @__PURE__ */ n("label", {
			className: "ds-segmented-control__option",
			"data-selected": e.value === r || void 0,
			children: [/* @__PURE__ */ t("input", {
				type: "radio",
				name: a,
				value: e.value,
				checked: e.value === r,
				disabled: e.disabled,
				onChange: () => i(e.value)
			}), /* @__PURE__ */ t("span", { children: e.label })]
		}, e.value))
	});
}
//#endregion
//#region src/components/design-system/components/navigation/Stepper.tsx
function oe({ steps: e, activeStep: r, ariaLabel: i = "Progress", className: a = "" }) {
	return /* @__PURE__ */ t("ol", {
		className: `ds-stepper ${a}`.trim(),
		"aria-label": i,
		children: e.map((e, i) => {
			let a = i < r ? "complete" : i === r ? "current" : e.disabled ? "disabled" : "upcoming";
			return /* @__PURE__ */ n("li", {
				"data-status": a,
				"aria-current": a === "current" ? "step" : void 0,
				children: [/* @__PURE__ */ t("span", {
					className: "ds-stepper__number",
					"aria-hidden": "true",
					children: i + 1
				}), /* @__PURE__ */ n("span", {
					className: "ds-stepper__content",
					children: [/* @__PURE__ */ t("strong", { children: e.label }), e.description && /* @__PURE__ */ t("small", { children: e.description })]
				})]
			}, e.label);
		})
	});
}
//#endregion
//#region src/components/design-system/components/navigation/Tabs.tsx
function z(e, t, n) {
	let r = `${e}-${n(t)}`;
	return {
		tab: `${r}-tab`,
		panel: `${r}-panel`
	};
}
function se(e) {
	return /* @__PURE__ */ t(ce, { ...e });
}
function ce({ items: e, value: n, onValueChange: r, ariaLabel: i, idPrefix: a = "tab", className: o = "", keyForValue: s = encodeURIComponent }) {
	let c = g(/* @__PURE__ */ new Map()), l = e.filter((e) => !e.disabled), u = l.find((e) => e.value === n) ?? l[0];
	function d(e, t) {
		if (![
			"ArrowLeft",
			"ArrowRight",
			"Home",
			"End"
		].includes(e.key) || !l.length) return;
		e.preventDefault();
		let n = l.findIndex((e) => e.value === t), i = e.key === "Home" ? 0 : e.key === "End" ? l.length - 1 : (n + (e.key === "ArrowRight" ? 1 : -1) + l.length) % l.length, a = l[i].value;
		r(a), c.current.get(a)?.focus();
	}
	return /* @__PURE__ */ t("div", {
		className: `v2-pill-tabs ${o}`.trim(),
		role: "tablist",
		"aria-label": i,
		children: e.map((e) => {
			let n = z(a, e.value, s), i = !e.disabled && e.value === u?.value;
			return /* @__PURE__ */ t("button", {
				ref: (t) => {
					t ? c.current.set(e.value, t) : c.current.delete(e.value);
				},
				type: "button",
				role: "tab",
				id: n.tab,
				"aria-controls": n.panel,
				"aria-selected": i,
				disabled: e.disabled,
				tabIndex: i ? 0 : -1,
				onClick: () => r(e.value),
				onKeyDown: (t) => d(t, e.value),
				children: e.label
			}, e.value);
		})
	});
}
function le(e) {
	return /* @__PURE__ */ t(ue, { ...e });
}
function ue({ value: e, activeValue: n, idPrefix: r = "tab", children: i, className: a = "", keyForValue: o = encodeURIComponent }) {
	let s = z(r, e, o);
	return /* @__PURE__ */ t("div", {
		className: a,
		role: "tabpanel",
		id: s.panel,
		"aria-labelledby": s.tab,
		hidden: e !== n,
		tabIndex: 0,
		children: i
	});
}
//#endregion
//#region src/components/design-system/components/overlays/overlays.tsx
function B({ children: e, primitive: n }) {
	return /* @__PURE__ */ t(n, {
		asChild: !0,
		children: typeof e == "string" ? /* @__PURE__ */ t("button", {
			className: "ds-overlay-trigger",
			type: "button",
			children: e
		}) : e
	});
}
function V({ open: e, onOpenChange: r, title: i, description: a, trigger: o, children: s, closeLabel: c = "Close dialog" }) {
	return /* @__PURE__ */ n(v.Root, {
		open: e,
		onOpenChange: r,
		children: [o && /* @__PURE__ */ t(B, {
			primitive: v.Trigger,
			children: o
		}), /* @__PURE__ */ n(v.Portal, { children: [/* @__PURE__ */ t(v.Overlay, { className: "ds-overlay-backdrop" }), /* @__PURE__ */ n(v.Content, {
			className: "ds-dialog",
			"aria-describedby": void 0,
			children: [
				/* @__PURE__ */ n("div", {
					className: "ds-overlay__header",
					children: [/* @__PURE__ */ t(v.Title, {
						className: "ds-overlay__title",
						children: i
					}), /* @__PURE__ */ t(v.Close, {
						className: "ds-overlay__close",
						"aria-label": c,
						children: "×"
					})]
				}),
				a && /* @__PURE__ */ t(v.Description, {
					className: "ds-overlay__description",
					children: a
				}),
				/* @__PURE__ */ t("div", {
					className: "ds-overlay__body",
					children: s
				})
			]
		})] })]
	});
}
function H({ side: e = "right", open: r, onOpenChange: i, title: a, description: o, trigger: s, children: c, closeLabel: l }) {
	return /* @__PURE__ */ n(v.Root, {
		open: r,
		onOpenChange: i,
		children: [s && /* @__PURE__ */ t(B, {
			primitive: v.Trigger,
			children: s
		}), /* @__PURE__ */ n(v.Portal, { children: [/* @__PURE__ */ t(v.Overlay, { className: "ds-overlay-backdrop" }), /* @__PURE__ */ n(v.Content, {
			className: `ds-drawer ds-drawer--${e}`,
			children: [
				/* @__PURE__ */ n("div", {
					className: "ds-overlay__header",
					children: [/* @__PURE__ */ t(v.Title, {
						className: "ds-overlay__title",
						children: a
					}), /* @__PURE__ */ t(v.Close, {
						className: "ds-overlay__close",
						"aria-label": l ?? "Close drawer",
						children: "×"
					})]
				}),
				o && /* @__PURE__ */ t(v.Description, {
					className: "ds-overlay__description",
					children: o
				}),
				/* @__PURE__ */ t("div", {
					className: "ds-overlay__body",
					children: c
				})
			]
		})] })]
	});
}
function U({ open: e, onOpenChange: r, trigger: i, children: a, side: o = "bottom", align: s = "start" }) {
	return /* @__PURE__ */ n(b.Root, {
		open: e,
		onOpenChange: r,
		children: [/* @__PURE__ */ t(B, {
			primitive: b.Trigger,
			children: i
		}), /* @__PURE__ */ t(b.Portal, { children: /* @__PURE__ */ t(b.Content, {
			className: "ds-popover",
			side: o,
			align: s,
			sideOffset: 8,
			children: a
		}) })]
	});
}
function de({ content: e, children: r, open: i, onOpenChange: a, side: o = "top", delayDuration: s = 0 }) {
	return /* @__PURE__ */ t(x.Provider, {
		delayDuration: s,
		children: /* @__PURE__ */ n(x.Root, {
			open: i,
			onOpenChange: a,
			children: [/* @__PURE__ */ t(x.Trigger, {
				asChild: !0,
				children: r
			}), /* @__PURE__ */ t(x.Portal, { children: /* @__PURE__ */ n(x.Content, {
				className: "ds-tooltip",
				side: o,
				sideOffset: 8,
				children: [e, /* @__PURE__ */ t(x.Arrow, { className: "ds-tooltip__arrow" })]
			}) })]
		})
	});
}
function fe({ open: e, onOpenChange: r, trigger: i, items: a, onSelect: o, ariaLabel: s = "Actions" }) {
	return /* @__PURE__ */ n(y.Root, {
		open: e,
		onOpenChange: r,
		children: [/* @__PURE__ */ t(B, {
			primitive: y.Trigger,
			children: i
		}), /* @__PURE__ */ t(y.Portal, { children: /* @__PURE__ */ t(y.Content, {
			className: "ds-menu",
			align: "start",
			sideOffset: 8,
			"aria-label": s,
			children: a.map((e) => /* @__PURE__ */ t(y.Item, {
				className: `ds-menu__item${e.danger ? " ds-menu__item--danger" : ""}`,
				disabled: e.disabled,
				onSelect: () => o(e.id),
				children: e.label
			}, e.id))
		}) })]
	});
}
//#endregion
//#region src/components/design-system/components/selection/Combobox.tsx
function pe({ label: e, options: r, value: i, onValueChange: a, clearable: o = !1, disabled: s = !1, placeholder: c = "Search options", className: l = "" }) {
	let u = p(), d = r.find((e) => e.value === i), [f, m] = _(!1), [g, v] = _(""), y = g.trim().toLocaleLowerCase(), b = h(() => r.filter((e) => String(e.label).toLocaleLowerCase().includes(y)), [r, y]), x = f ? g : d ? String(d.label) : "";
	function S(e, t) {
		t || s || (a(e), v(""), m(!1));
	}
	return /* @__PURE__ */ n("div", {
		className: `ds-selection ${l}`.trim(),
		children: [
			/* @__PURE__ */ t("label", {
				className: "ds-selection__label",
				htmlFor: u,
				children: e
			}),
			/* @__PURE__ */ n("div", {
				className: "ds-selection__control-wrap",
				children: [/* @__PURE__ */ t("input", {
					id: u,
					className: "ds-selection__control",
					type: "text",
					role: "combobox",
					"aria-autocomplete": "list",
					"aria-controls": `${u}-options`,
					"aria-expanded": f,
					"aria-haspopup": "listbox",
					disabled: s,
					placeholder: c,
					value: x,
					onFocus: () => {
						m(!0), v("");
					},
					onChange: (e) => {
						v(e.target.value), m(!0);
					},
					onKeyDown: (e) => {
						e.key === "Escape" && (m(!1), v("")), e.key === "Enter" && b.length === 1 && (e.preventDefault(), S(b[0].value, b[0].disabled));
					}
				}), o && i !== null && !s && /* @__PURE__ */ t("button", {
					className: "ds-selection__clear",
					type: "button",
					"aria-label": `Clear ${e}`,
					onClick: () => {
						a(null), v("");
					},
					children: "×"
				})]
			}),
			f && /* @__PURE__ */ t("ul", {
				id: `${u}-options`,
				className: "ds-selection__options",
				role: "listbox",
				"aria-label": `${e} options`,
				children: b.length > 0 ? b.map((e) => /* @__PURE__ */ t("li", { children: /* @__PURE__ */ t("button", {
					type: "button",
					className: "ds-selection__option",
					role: "option",
					"aria-selected": e.value === i,
					"aria-disabled": e.disabled || void 0,
					disabled: e.disabled || s,
					onMouseDown: (e) => e.preventDefault(),
					onClick: () => S(e.value, e.disabled),
					children: e.label
				}) }, String(e.value))) : /* @__PURE__ */ t("li", {
					className: "ds-selection__empty",
					role: "status",
					children: "No matching options."
				})
			})
		]
	});
}
//#endregion
//#region src/components/design-system/components/selection/MultiSelect.tsx
function me({ label: e, options: r, value: i, onValueChange: a, disabled: o = !1, placeholder: s = "Search options", className: c = "" }) {
	let l = p(), [u, d] = _(!1), [f, m] = _(""), g = f.trim().toLocaleLowerCase(), v = h(() => r.filter((e) => String(e.label).toLocaleLowerCase().includes(g)), [r, g]), y = r.filter((e) => i.includes(e.value)).map((e) => String(e.label));
	function b(e, t) {
		t || o || a(i.includes(e) ? i.filter((t) => t !== e) : [...i, e]);
	}
	return /* @__PURE__ */ n("div", {
		className: `ds-selection ${c}`.trim(),
		children: [
			/* @__PURE__ */ t("label", {
				className: "ds-selection__label",
				htmlFor: l,
				children: e
			}),
			/* @__PURE__ */ t("input", {
				id: l,
				className: "ds-selection__control",
				type: "text",
				role: "combobox",
				"aria-autocomplete": "list",
				"aria-controls": `${l}-options`,
				"aria-expanded": u,
				"aria-haspopup": "listbox",
				disabled: o,
				placeholder: y.length ? y.join(", ") : s,
				value: f,
				onFocus: () => d(!0),
				onChange: (e) => {
					m(e.target.value), d(!0);
				},
				onKeyDown: (e) => {
					e.key === "Escape" && (d(!1), m(""));
				}
			}),
			u && /* @__PURE__ */ t("ul", {
				id: `${l}-options`,
				className: "ds-selection__options",
				role: "listbox",
				"aria-label": `${e} options`,
				"aria-multiselectable": "true",
				children: v.length > 0 ? v.map((e) => /* @__PURE__ */ t("li", { children: /* @__PURE__ */ t("button", {
					type: "button",
					className: "ds-selection__option",
					role: "option",
					"aria-selected": i.includes(e.value),
					"aria-disabled": e.disabled || void 0,
					disabled: e.disabled || o,
					onMouseDown: (e) => e.preventDefault(),
					onClick: () => b(e.value, e.disabled),
					children: e.label
				}) }, String(e.value))) : /* @__PURE__ */ t("li", {
					className: "ds-selection__empty",
					role: "status",
					children: "No matching options."
				})
			})
		]
	});
}
//#endregion
//#region src/components/design-system/components/feedback/Alert.tsx
function he({ title: e, children: r, tone: i = "info", onDismiss: a, className: o = "" }) {
	let s = i === "danger";
	return /* @__PURE__ */ n("div", {
		className: `ds-alert ${o}`.trim(),
		"data-tone": i,
		role: s ? "alert" : "status",
		children: [/* @__PURE__ */ n("div", {
			className: "ds-alert__content",
			children: [e && /* @__PURE__ */ t("strong", {
				className: "ds-alert__title",
				children: e
			}), r && /* @__PURE__ */ t("div", {
				className: "ds-alert__body",
				children: r
			})]
		}), a && /* @__PURE__ */ t("button", {
			type: "button",
			className: "ds-alert__dismiss",
			"aria-label": "Dismiss alert",
			onClick: a,
			children: /* @__PURE__ */ t(c, {
				size: 16,
				"aria-hidden": "true"
			})
		})]
	});
}
//#endregion
//#region src/components/design-system/components/feedback/ErrorState.tsx
function W({ title: e, description: r, actionLabel: i, onAction: a, className: o = "" }) {
	return /* @__PURE__ */ n("section", {
		className: `ds-error-state ${o}`.trim(),
		"aria-labelledby": "ds-error-state-title",
		children: [
			/* @__PURE__ */ t(s, {
				className: "ds-error-state__icon",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ t("h2", {
				id: "ds-error-state-title",
				className: "ds-error-state__title",
				children: e
			}),
			r && /* @__PURE__ */ t("p", {
				className: "ds-error-state__description",
				children: r
			}),
			i && a && /* @__PURE__ */ t(j, {
				variant: "secondary",
				onClick: a,
				children: i
			})
		]
	});
}
//#endregion
//#region src/components/design-system/components/feedback/Progress.tsx
function G({ value: e, max: r = 100, label: i, showValue: a = !0, className: o = "" }) {
	let s = p(), c = Math.max(0, Math.min(e, r)), l = Math.round(c / r * 100);
	return /* @__PURE__ */ n("div", {
		className: `ds-progress ${o}`.trim(),
		children: [/* @__PURE__ */ n("div", {
			className: "ds-progress__header",
			children: [/* @__PURE__ */ t("span", {
				id: s,
				children: i
			}), a && /* @__PURE__ */ n("span", { children: [l, "%"] })]
		}), /* @__PURE__ */ t("div", {
			className: "ds-progress__track",
			role: "progressbar",
			"aria-labelledby": s,
			"aria-valuemin": 0,
			"aria-valuemax": r,
			"aria-valuenow": c,
			children: /* @__PURE__ */ t("span", {
				className: "ds-progress__value",
				style: { width: `${l}%` }
			})
		})]
	});
}
//#endregion
//#region src/components/design-system/components/feedback/Skeleton.tsx
function K({ lines: e = 1, className: n = "" }) {
	return /* @__PURE__ */ t("div", {
		className: `ds-skeleton ${n}`.trim(),
		children: Array.from({ length: Math.max(1, e) }, (e, n) => /* @__PURE__ */ t("span", {
			className: "ds-skeleton__line",
			"aria-hidden": "true"
		}, n))
	});
}
//#endregion
//#region src/components/design-system/components/feedback/StatusBadge.tsx
function q({ children: e, tone: n = "neutral", className: r = "" }) {
	return /* @__PURE__ */ t("span", {
		className: `ds-status-badge ${r}`.trim(),
		"data-tone": n,
		children: e
	});
}
//#endregion
//#region src/components/design-system/components/feedback/ToastProvider.tsx
var J = l(null);
function ge({ children: e }) {
	let [r, i] = _([]), a = u((e) => i((t) => [...t, {
		...e,
		id: Date.now() + t.length
	}]), []), o = u((e) => i((t) => t.filter((t) => t.id !== e)), []), s = h(() => ({
		toast: a,
		dismiss: o
	}), [a, o]);
	return /* @__PURE__ */ n(J.Provider, {
		value: s,
		children: [e, /* @__PURE__ */ t("div", {
			className: "ds-toast-viewport",
			"aria-label": "Notifications",
			"aria-live": "polite",
			children: r.map((e) => /* @__PURE__ */ n("div", {
				className: "ds-toast",
				"data-tone": e.tone ?? "info",
				role: "status",
				children: [/* @__PURE__ */ n("div", { children: [/* @__PURE__ */ t("strong", { children: e.title }), e.description && /* @__PURE__ */ t("div", {
					className: "ds-toast__description",
					children: e.description
				})] }), /* @__PURE__ */ t("button", {
					type: "button",
					className: "ds-toast__dismiss",
					"aria-label": `Dismiss ${String(e.title)}`,
					onClick: () => o(e.id),
					children: /* @__PURE__ */ t(c, {
						size: 16,
						"aria-hidden": "true"
					})
				})]
			}, e.id))
		})]
	});
}
function _e() {
	let e = d(J);
	if (!e) throw Error("useToast must be used inside ToastProvider");
	return e;
}
//#endregion
//#region src/components/design-system/components/files/FileDropzone.tsx
function ve({ label: e, onFilesChange: r, accept: i, multiple: a = !0, disabled: o = !1, description: s = "Drop files here or choose files from your device.", chooseLabel: c = "Choose files", className: l = "", id: u }) {
	let d = p(), f = u ?? d, m = g(null), h = (e) => {
		!o && e && r(Array.from(e));
	};
	return /* @__PURE__ */ n("div", {
		className: `ds-file-dropzone ${l}`.trim(),
		"data-disabled": o || void 0,
		onDragOver: (e) => e.preventDefault(),
		onDrop: (e) => {
			e.preventDefault(), h(e.dataTransfer.files);
		},
		children: [/* @__PURE__ */ t("input", {
			ref: m,
			id: f,
			className: "ds-file-dropzone__input",
			type: "file",
			accept: i,
			multiple: a,
			disabled: o,
			"aria-label": typeof e == "string" ? e : void 0,
			onChange: (e) => {
				h(e.currentTarget.files), e.currentTarget.value = "";
			}
		}), /* @__PURE__ */ n("div", {
			className: "ds-file-dropzone__body",
			children: [
				/* @__PURE__ */ t("strong", {
					className: "ds-file-dropzone__label",
					children: e
				}),
				/* @__PURE__ */ t("p", {
					className: "ds-file-dropzone__description",
					children: s
				}),
				/* @__PURE__ */ t("button", {
					type: "button",
					className: "ds-file-dropzone__choose",
					disabled: o,
					onClick: () => m.current?.click(),
					children: c
				})
			]
		})]
	});
}
//#endregion
//#region src/components/design-system/components/files/FileList.tsx
function ye(e) {
	if (e < 1024) return `${e} B`;
	let t = [
		"KB",
		"MB",
		"GB"
	], n = e / 1024, r = 0;
	for (; n >= 1024 && r < t.length - 1;) n /= 1024, r += 1;
	return `${Math.round(n * 10) / 10} ${t[r]}`;
}
function be({ files: e, onRemove: r, emptyMessage: i = "No files selected.", className: a = "" }) {
	return e.length === 0 ? /* @__PURE__ */ t("p", {
		className: `ds-file-list__empty ${a}`.trim(),
		children: i
	}) : /* @__PURE__ */ t("ul", {
		className: `ds-file-list ${a}`.trim(),
		"aria-label": "Selected files",
		children: e.map((e, i) => /* @__PURE__ */ n("li", {
			className: "ds-file-list__item",
			children: [/* @__PURE__ */ n("span", {
				className: "ds-file-list__details",
				children: [/* @__PURE__ */ t("strong", { children: e.name }), /* @__PURE__ */ t("span", { children: ye(e.size) })]
			}), r && /* @__PURE__ */ t("button", {
				type: "button",
				className: "ds-file-list__remove",
				onClick: () => r(i),
				"aria-label": `Remove ${e.name}`,
				children: "Remove"
			})]
		}, `${e.name}-${e.lastModified}-${i}`))
	});
}
//#endregion
//#region src/components/design-system/components/ai/AITaskStatus.tsx
var xe = {
	queued: "Queued",
	running: "Working",
	succeeded: "Complete",
	failed: "Failed"
};
function Y({ status: e, label: r, progress: i, className: a = "" }) {
	let o = e === "failed" ? "alert" : "status";
	return /* @__PURE__ */ n("section", {
		className: `ds-ai-task-status ${a}`.trim(),
		"data-state": e,
		role: o,
		children: [/* @__PURE__ */ n("div", {
			className: "ds-ai-task-status__summary",
			children: [
				/* @__PURE__ */ t("span", {
					"aria-hidden": "true",
					children: e === "succeeded" ? "✓" : e === "failed" ? "!" : "✦"
				}),
				/* @__PURE__ */ t("span", { children: r }),
				/* @__PURE__ */ t("small", { children: xe[e] })
			]
		}), e === "running" && i !== void 0 && /* @__PURE__ */ t(G, {
			value: i,
			label: r
		})]
	});
}
//#endregion
//#region src/components/design-system/components/ai/AIResult.tsx
function Se({ title: e, children: r, actionLabel: i, onAction: a, className: o = "" }) {
	return /* @__PURE__ */ n("section", {
		className: `ds-ai-result ${o}`.trim(),
		children: [
			/* @__PURE__ */ t("div", {
				className: "ds-ai-result__mark",
				"aria-hidden": "true",
				children: "✦"
			}),
			/* @__PURE__ */ n("div", {
				className: "ds-ai-result__content",
				children: [/* @__PURE__ */ t("h3", { children: e }), r && /* @__PURE__ */ t("div", { children: r })]
			}),
			i && a && /* @__PURE__ */ t("button", {
				type: "button",
				className: "ds-ai-result__action",
				onClick: a,
				children: i
			})
		]
	});
}
//#endregion
//#region src/components/design-system/components/content/ActionCard.tsx
function Ce({ label: e, status: r, actions: i, persistentAction: a, highlighted: o = !1, dismissing: s = !1, exiting: c = !1, children: l, className: u = "", ...d }) {
	return /* @__PURE__ */ n("article", {
		...d,
		"aria-label": d["aria-label"] ?? e,
		className: `ds-action-card ${u}`.trim(),
		"data-highlighted": o || void 0,
		"data-dismissing": s || void 0,
		"data-exiting": c || void 0,
		"aria-hidden": c || d["aria-hidden"],
		inert: c || d.inert,
		children: [/* @__PURE__ */ n("header", {
			className: "ds-action-card__header",
			children: [/* @__PURE__ */ n("div", {
				className: "ds-action-card__meta",
				children: [/* @__PURE__ */ t("span", { children: e }), r]
			}), (i || a) && /* @__PURE__ */ n("div", {
				className: "ds-action-card__controls",
				children: [i && /* @__PURE__ */ t("div", {
					className: "ds-action-card__actions",
					children: i
				}), a]
			})]
		}), /* @__PURE__ */ t("div", {
			className: "ds-action-card__content",
			children: l
		})]
	});
}
//#endregion
//#region src/components/design-system/components/content/CanvasText.tsx
function we({ label: e, value: n, onValueChange: r, maxLength: i, required: a = !1, readOnly: o = !1, placeholder: s, className: c = "", style: l }) {
	let u = g(n);
	return /* @__PURE__ */ t("textarea", {
		className: `ds-canvas-text ${c}`.trim(),
		style: l,
		"aria-label": e,
		"aria-invalid": a && !n.trim() || i !== void 0 && n.length > i || void 0,
		value: n,
		required: a,
		readOnly: o,
		placeholder: s,
		rows: 1,
		spellCheck: !0,
		onFocus: () => {
			u.current = n;
		},
		onChange: (e) => {
			o || r(e.target.value);
		},
		onBlur: (e) => {
			e.currentTarget.scrollTop = 0, e.currentTarget.scrollLeft = 0;
		},
		onKeyDown: (e) => {
			e.key === "Escape" && !e.nativeEvent.isComposing && !o && (e.preventDefault(), r(u.current), e.currentTarget.blur());
		}
	});
}
//#endregion
//#region src/components/design-system/components/content/FactGrid.tsx
function X({ items: e, label: r = "Details", className: i = "", theme: a, density: o = "comfortable" }) {
	return /* @__PURE__ */ t("div", {
		className: `ds-fact-grid-container ${i}`.trim(),
		role: "group",
		"aria-label": r,
		"data-theme": a,
		"data-density": o,
		children: /* @__PURE__ */ t("dl", {
			className: "ds-fact-grid",
			children: e.map(({ id: e, label: r, value: i, emphasis: a }) => /* @__PURE__ */ n("div", {
				"data-emphasis": a || void 0,
				children: [/* @__PURE__ */ t("dt", { children: r }), /* @__PURE__ */ t("dd", { children: i })]
			}, e))
		})
	});
}
//#endregion
//#region src/components/design-system/components/content/InlineText.tsx
function Z({ label: e, value: r = "", sourceKey: i, onSave: o, onDirty: s, readOnly: c = !1, required: l = !1, maxLength: u = 500, className: d = "", style: p }) {
	let [m, h] = _(!1), [v, y] = _(r), [b, x] = _(r), [S, C] = _(!1), [w, T] = _(""), E = g(null), D = g(i), O = g(!1);
	f(() => {
		m || y(r);
	}, [r]);
	let k = () => {
		h(!1), T(""), s?.(!1), requestAnimationFrame(() => E.current?.focus());
	}, A = async () => {
		if (O.current || c) return;
		let t = b.trim();
		if (l && !t) {
			T(`${e} cannot be empty.`);
			return;
		}
		O.current = !0, C(!0), T("");
		try {
			if (t === v) {
				k();
				return;
			}
			let e = D.current === void 0 ? await o(t) : await o(t, D.current);
			if (e?.ok === !1) {
				T(e.message || "Could not save changes.");
				return;
			}
			y(t), k();
		} catch (e) {
			T(e instanceof Error ? e.message : "Could not save changes.");
		} finally {
			O.current = !1, C(!1);
		}
	};
	return m ? /* @__PURE__ */ n("div", {
		className: `ds-inline-text-value ds-inline-text-editor ${d}`.trim(),
		style: p,
		children: [
			/* @__PURE__ */ n("div", {
				className: "ds-inline-text-editor__field",
				children: [/* @__PURE__ */ n("span", {
					className: "ds-inline-text-value__copy ds-inline-text-editor__sizer",
					"aria-hidden": "true",
					children: [b, "​"]
				}), /* @__PURE__ */ t("textarea", {
					autoFocus: !0,
					"aria-label": e,
					value: b,
					maxLength: u,
					rows: 1,
					disabled: S || c,
					onBlur: () => void A(),
					onChange: (e) => x(e.target.value),
					onKeyDown: (e) => {
						e.nativeEvent.isComposing || (e.key === "Escape" && !S && (e.preventDefault(), y(r), k()), e.key === "Enter" && !e.shiftKey && (e.preventDefault(), A()));
					}
				})]
			}),
			w && /* @__PURE__ */ t("p", {
				className: "ds-inline-text-editor__error",
				role: "alert",
				children: w
			}),
			D.current !== i && /* @__PURE__ */ t("p", {
				className: "ds-inline-text-editor__note",
				children: "The saved value changed. Your draft is kept; copy it before canceling to load the latest version."
			})
		]
	}) : c ? /* @__PURE__ */ t("span", {
		className: `ds-inline-text-value ${d}`.trim(),
		style: p,
		children: v || "Not specified"
	}) : /* @__PURE__ */ n("button", {
		ref: E,
		type: "button",
		className: `ds-inline-text-value ${d}`.trim(),
		style: p,
		"aria-label": `Edit ${e.toLowerCase()}`,
		onClick: () => {
			D.current = i, x(v), h(!0), s?.(!0);
		},
		children: [/* @__PURE__ */ n("span", {
			className: "ds-inline-text-value__copy",
			children: [v || "Not specified", "​"]
		}), /* @__PURE__ */ t("span", {
			className: "ds-inline-text-value__edit",
			"aria-hidden": "true",
			children: /* @__PURE__ */ t(a, { size: 14 })
		})]
	});
}
//#endregion
//#region src/components/design-system/components/content/Panel.tsx
function Te({ title: e, description: r, as: i = "section", children: a, className: o = "", ...s }) {
	let c = p();
	return /* @__PURE__ */ n(i, {
		...s,
		className: `ds-panel${a == null ? " ds-panel--empty" : ""} ${o}`.trim(),
		"aria-labelledby": c,
		children: [/* @__PURE__ */ n("header", {
			className: "ds-panel__header",
			children: [/* @__PURE__ */ t("h3", {
				id: c,
				children: e
			}), r && /* @__PURE__ */ t("p", { children: r })]
		}), a && /* @__PURE__ */ t("div", {
			className: "ds-panel__content",
			children: a
		})]
	});
}
//#endregion
//#region src/components/design-system/components/content/SelectionTile.tsx
function Q({ label: e, selected: i = !1, onChange: a, disabled: s = !1, caption: c, children: l, className: u = "", ...d }) {
	return /* @__PURE__ */ n("button", {
		...d,
		type: d.type ?? "button",
		className: `ds-selection-tile ${u}`.trim(),
		"aria-label": `${i ? "Deselect" : "Select"} ${e}`,
		"aria-pressed": i,
		disabled: s,
		onClick: a,
		children: [
			/* @__PURE__ */ t("span", {
				className: "ds-selection-tile__content",
				children: l
			}),
			/* @__PURE__ */ t("span", {
				className: "ds-selection-tile__action",
				"aria-hidden": "true",
				children: t(i ? r : o, { size: 20 })
			}),
			c && /* @__PURE__ */ t("span", {
				className: "ds-selection-tile__caption",
				children: c
			})
		]
	});
}
//#endregion
//#region src/components/design-system/components/content/Tag.tsx
function Ee({ children: e, tone: n = "neutral", variant: r = "filled", className: i = "", ...a }) {
	return /* @__PURE__ */ t("span", {
		...a,
		className: `ds-tag ds-tag--${r} ds-tag--${n} ${i}`.trim(),
		"data-tone": n,
		"data-variant": r,
		children: e
	});
}
//#endregion
//#region src/components/design-system/components/content/TagButton.tsx
function De({ children: e, tone: r = "neutral", variant: i = "filled", dismissible: a = !1, className: o = "", ...s }) {
	return /* @__PURE__ */ n("button", {
		...s,
		className: `ds-tag ds-tag-button ds-tag--${i} ds-tag--${r} ${o}`.trim(),
		"data-tone": r,
		"data-variant": i,
		children: [e, a && /* @__PURE__ */ t(c, {
			className: "ds-tag-button__dismiss",
			"aria-hidden": "true",
			size: 14,
			strokeWidth: 2.5
		})]
	});
}
//#endregion
//#region src/components/design-system/components/data/BulkActionBar.tsx
function Oe({ count: e, children: r, onClear: i, className: a = "" }) {
	return /* @__PURE__ */ n("section", {
		className: `ds-bulk-action-bar ${a}`.trim(),
		"aria-label": "Bulk actions",
		children: [/* @__PURE__ */ n("p", { children: [
			/* @__PURE__ */ t("strong", { children: e }),
			" ",
			e === 1 ? "item selected" : "items selected"
		] }), /* @__PURE__ */ n("div", {
			className: "ds-bulk-action-bar__actions",
			children: [r, /* @__PURE__ */ t("button", {
				type: "button",
				onClick: i,
				children: "Clear selection"
			})]
		})]
	});
}
//#endregion
//#region src/components/design-system/components/data/FilterToolbar.tsx
function ke({ query: e, onQueryChange: r, children: i, onClear: a, resultCount: o, searchLabel: s = "Search results", className: c = "" }) {
	return /* @__PURE__ */ n("section", {
		className: `ds-filter-toolbar ${c}`.trim(),
		"aria-label": "Filters",
		children: [/* @__PURE__ */ n("div", {
			className: "ds-filter-toolbar__controls",
			children: [
				/* @__PURE__ */ n("label", {
					className: "ds-filter-toolbar__search",
					children: [/* @__PURE__ */ t("span", { children: s }), /* @__PURE__ */ t("input", {
						type: "search",
						value: e,
						onChange: (e) => r(e.target.value)
					})]
				}),
				i,
				a && /* @__PURE__ */ t("button", {
					type: "button",
					className: "ds-filter-toolbar__clear",
					onClick: a,
					children: "Clear filters"
				})
			]
		}), o !== void 0 && /* @__PURE__ */ n("p", {
			className: "ds-filter-toolbar__count",
			role: "status",
			children: [
				o,
				" ",
				o === 1 ? "result" : "results"
			]
		})]
	});
}
//#endregion
//#region src/components/design-system/components/data/Table.tsx
function Ae({ checked: e, indeterminate: n, disabled: r, onChange: i }) {
	let a = g(null);
	return f(() => {
		a.current && (a.current.indeterminate = n);
	}, [n]), /* @__PURE__ */ t("input", {
		ref: a,
		type: "checkbox",
		"aria-label": "Select all rows",
		checked: e,
		disabled: r,
		onChange: i
	});
}
function $({ label: e, rows: r, columns: i, getRowId: a, sort: o, onSortChange: s, selectedIds: c, onSelectionChange: l, emptyMessage: u = "No rows to display.", className: d = "" }) {
	let f = c !== void 0 && l !== void 0, p = r.map(a), m = new Set(c), h = p.filter((e) => m.has(e)).length, g = p.length > 0 && h === p.length, _ = h > 0 && !g;
	function v(e) {
		let t = o?.columnId === e && o.direction === "asc" ? "desc" : "asc";
		s?.({
			columnId: e,
			direction: t
		});
	}
	function y() {
		if (!l) return;
		let e = new Set(p);
		if (g) {
			l((c ?? []).filter((t) => !e.has(t)));
			return;
		}
		l([.../* @__PURE__ */ new Set([...c ?? [], ...p])]);
	}
	function b(e) {
		l && l(m.has(e) ? (c ?? []).filter((t) => t !== e) : [...c ?? [], e]);
	}
	return /* @__PURE__ */ t("div", {
		className: `ds-table-scroll ${d}`.trim(),
		children: /* @__PURE__ */ n("table", {
			className: "ds-table",
			"aria-label": e,
			children: [
				/* @__PURE__ */ t("caption", { children: e }),
				/* @__PURE__ */ t("thead", { children: /* @__PURE__ */ n("tr", { children: [f && /* @__PURE__ */ t("th", {
					scope: "col",
					className: "ds-table__selection",
					children: /* @__PURE__ */ t(Ae, {
						checked: g,
						indeterminate: _,
						disabled: p.length === 0,
						onChange: y
					})
				}), i.map((e) => {
					let n = o?.columnId === e.id ? o?.direction === "asc" ? "ascending" : "descending" : e.sortable ? "none" : void 0;
					return /* @__PURE__ */ t("th", {
						scope: "col",
						className: e.className,
						"aria-sort": n,
						children: e.sortable ? /* @__PURE__ */ t("button", {
							type: "button",
							className: "ds-table__sort",
							onClick: () => v(e.id),
							"aria-label": `Sort by ${e.header}`,
							children: e.header
						}) : e.header
					}, e.id);
				})] }) }),
				/* @__PURE__ */ t("tbody", { children: r.length === 0 ? /* @__PURE__ */ t("tr", { children: /* @__PURE__ */ t("td", {
					colSpan: i.length + +!!f,
					className: "ds-table__empty",
					children: u
				}) }) : r.map((e) => {
					let r = a(e);
					return /* @__PURE__ */ n("tr", {
						"data-row-id": r,
						children: [f && /* @__PURE__ */ t("td", {
							className: "ds-table__selection",
							children: /* @__PURE__ */ t("input", {
								type: "checkbox",
								"aria-label": `Select row ${r}`,
								checked: m.has(r),
								onChange: () => b(r)
							})
						}), i.map((n) => /* @__PURE__ */ t("td", {
							className: n.className,
							children: n.cell(e)
						}, n.id))]
					}, r);
				}) })
			]
		})
	});
}
//#endregion
//#region src/components/design-system/ui-blocks/settings/SettingsForm.tsx
function je({ initialValue: e, onSave: r }) {
	let [i, a] = _(e), [o, s] = _(e), [c, l] = _(null), [u, d] = _(!1), f = (e, t) => a((n) => ({
		...n,
		[e]: t
	})), p = i.name.trim().length > 0, m = JSON.stringify(i) !== JSON.stringify(o);
	async function h(e) {
		if (e.preventDefault(), !p || u) return;
		d(!0), l(null);
		let t = await r(i);
		d(!1), t.ok ? s(i) : l(t.message);
	}
	return /* @__PURE__ */ n("form", {
		className: "ds-settings-form",
		onSubmit: h,
		children: [
			/* @__PURE__ */ n("div", {
				className: "ds-settings-form__field",
				children: [/* @__PURE__ */ t("label", {
					htmlFor: "settings-name",
					children: "Workspace name"
				}), /* @__PURE__ */ t("input", {
					id: "settings-name",
					value: i.name,
					onChange: (e) => f("name", e.target.value),
					"aria-invalid": !p || void 0
				})]
			}),
			/* @__PURE__ */ n("div", {
				className: "ds-settings-form__field",
				children: [/* @__PURE__ */ t("label", {
					htmlFor: "settings-language",
					children: "Language"
				}), /* @__PURE__ */ n("select", {
					id: "settings-language",
					value: i.language,
					onChange: (e) => f("language", e.target.value),
					children: [
						/* @__PURE__ */ t("option", { children: "English" }),
						/* @__PURE__ */ t("option", { children: "Deutsch" }),
						/* @__PURE__ */ t("option", { children: "Français" })
					]
				})]
			}),
			/* @__PURE__ */ n("label", {
				className: "ds-settings-form__check",
				children: [/* @__PURE__ */ t("input", {
					type: "checkbox",
					checked: i.notifications,
					onChange: (e) => f("notifications", e.target.checked)
				}), " Notifications"]
			}),
			c && /* @__PURE__ */ t("p", {
				role: "alert",
				children: c
			}),
			/* @__PURE__ */ n("footer", { children: [/* @__PURE__ */ t("button", {
				type: "button",
				onClick: () => {
					a(o), l(null);
				},
				disabled: !m || u,
				children: "Cancel"
			}), /* @__PURE__ */ t("button", {
				type: "submit",
				disabled: !p || !m || u,
				children: u ? "Saving…" : "Save settings"
			})] })
		]
	});
}
//#endregion
//#region src/components/design-system/ui-blocks/ai-workspace/AIWorkspace.tsx
function Me({ prompt: e, onPromptChange: r, state: i, message: a, result: o, attachments: s, onSubmit: c, onCancel: l, onRetry: u, onApply: d, onRevise: f, readOnly: p = !1 }) {
	let m = i === "running" || i === "waiting", h = i === "failed" ? "failed" : i === "ready" ? "succeeded" : i === "running" || i === "waiting" ? "running" : "queued";
	return /* @__PURE__ */ n("section", {
		className: "ds-ai-workspace",
		"aria-label": "AI workspace",
		children: [
			/* @__PURE__ */ n("div", {
				className: "ds-ai-workspace__prompt",
				children: [
					/* @__PURE__ */ t("label", {
						htmlFor: "ai-workspace-prompt",
						children: "Prompt"
					}),
					/* @__PURE__ */ t("textarea", {
						id: "ai-workspace-prompt",
						value: e,
						onChange: (e) => r(e.target.value),
						readOnly: p
					}),
					/* @__PURE__ */ t("div", { children: s }),
					/* @__PURE__ */ t("button", {
						type: "button",
						onClick: c,
						disabled: p || m || !e.trim(),
						children: "Run task"
					})
				]
			}),
			/* @__PURE__ */ t(Y, {
				status: h,
				label: a
			}),
			m && l && /* @__PURE__ */ t("button", {
				type: "button",
				onClick: l,
				children: "Cancel"
			}),
			i === "failed" && u && /* @__PURE__ */ t("button", {
				type: "button",
				onClick: u,
				children: "Retry"
			}),
			o && /* @__PURE__ */ n("section", {
				className: "ds-ai-workspace__result",
				"aria-label": "Result",
				children: [
					/* @__PURE__ */ t("div", { children: o }),
					d && /* @__PURE__ */ t("button", {
						type: "button",
						onClick: d,
						disabled: m,
						children: "Apply"
					}),
					f && /* @__PURE__ */ t("button", {
						type: "button",
						onClick: f,
						disabled: m,
						children: "Revise"
					})
				]
			})
		]
	});
}
//#endregion
//#region src/components/design-system/ui-blocks/app-layout/AppLayout.tsx
function Ne({ navigation: e, header: r, children: i, inspector: a, feedback: o, className: s = "" }) {
	return /* @__PURE__ */ n("div", {
		className: `ds-app-layout ${s}`.trim(),
		children: [
			/* @__PURE__ */ t("aside", {
				className: "ds-app-layout__navigation",
				"aria-label": "Application navigation",
				children: e
			}),
			/* @__PURE__ */ n("div", {
				className: "ds-app-layout__main",
				children: [/* @__PURE__ */ t("header", {
					className: "ds-app-layout__header",
					children: r
				}), /* @__PURE__ */ t("main", {
					className: "ds-app-layout__content",
					children: i
				})]
			}),
			a && /* @__PURE__ */ t("aside", {
				className: "ds-app-layout__inspector",
				"aria-label": "Inspector",
				children: a
			}),
			o && /* @__PURE__ */ t("div", {
				className: "ds-app-layout__feedback",
				children: o
			})
		]
	});
}
//#endregion
//#region src/components/design-system/ui-blocks/item-browser/ItemBrowser.tsx
var Pe = [{
	value: "list",
	label: "List"
}, {
	value: "grid",
	label: "Grid"
}];
function Fe({ items: r, total: i, query: a, onQueryChange: o, page: s, pageCount: c, onPageChange: l, view: u, onViewChange: d, selectedIds: f, onSelectionChange: p, loading: m = !1, error: h, onRetry: g, onOpen: _, bulkActions: v, className: y = "" }) {
	let b = a ? `No items match “${a}”.` : "Your library is empty.", x = new Set(f), S = (e) => p(x.has(e) ? f.filter((t) => t !== e) : [...f, e]);
	return /* @__PURE__ */ n("section", {
		className: `ds-item-browser ${y}`.trim(),
		"aria-label": "Items",
		children: [
			/* @__PURE__ */ n("div", {
				className: "ds-item-browser__toolbar",
				children: [/* @__PURE__ */ t(I, {
					type: "search",
					label: "Search items",
					value: a,
					onChange: (e) => o(e.target.value)
				}), /* @__PURE__ */ t(R, {
					ariaLabel: "View items as",
					options: Pe,
					value: u,
					onValueChange: (e) => d(e)
				})]
			}),
			v && f.length > 0 && /* @__PURE__ */ t("div", {
				className: "ds-item-browser__bulk-actions",
				children: v
			}),
			h && /* @__PURE__ */ t(W, {
				title: h,
				description: r.length ? "Showing the most recently available items." : void 0,
				actionLabel: g ? "Try again" : void 0,
				onAction: g
			}),
			m && r.length === 0 ? /* @__PURE__ */ t("p", {
				className: "ds-item-browser__message",
				role: "status",
				children: "Loading items…"
			}) : r.length === 0 ? /* @__PURE__ */ t("p", {
				className: "ds-item-browser__message",
				children: b
			}) : u === "list" ? /* @__PURE__ */ t($, {
				label: "Items",
				rows: r,
				getRowId: (e) => e.id,
				selectedIds: f,
				onSelectionChange: p,
				columns: [
					{
						id: "title",
						header: "Title",
						cell: (r) => /* @__PURE__ */ n(e, { children: [/* @__PURE__ */ t("strong", { children: r.title }), r.description && /* @__PURE__ */ t("span", {
							className: "ds-item-browser__description",
							children: r.description
						})] })
					},
					{
						id: "status",
						header: "Status",
						cell: (e) => e.status ?? "—"
					},
					{
						id: "open",
						header: "Open",
						cell: (e) => /* @__PURE__ */ t(j, {
							size: "compact",
							variant: "quiet",
							onClick: () => _(e.id),
							children: "Open"
						})
					}
				]
			}) : /* @__PURE__ */ t("div", {
				className: "ds-item-browser__grid",
				children: r.map((e) => /* @__PURE__ */ n("div", {
					className: "ds-item-browser__grid-item",
					children: [/* @__PURE__ */ n(Q, {
						label: e.title,
						selected: x.has(e.id),
						onChange: () => S(e.id),
						caption: e.status,
						children: [/* @__PURE__ */ t("strong", { children: e.title }), e.description && /* @__PURE__ */ t("span", { children: e.description })]
					}), /* @__PURE__ */ n(j, {
						size: "compact",
						variant: "quiet",
						onClick: () => _(e.id),
						children: ["Open ", e.title]
					})]
				}, e.id))
			}),
			/* @__PURE__ */ n("footer", {
				className: "ds-item-browser__footer",
				children: [/* @__PURE__ */ n("span", { children: [
					i,
					" ",
					i === 1 ? "item" : "items"
				] }), /* @__PURE__ */ t(L, {
					page: s,
					pageCount: c,
					onPageChange: l
				})]
			})
		]
	});
}
//#endregion
//#region src/components/design-system/ui-blocks/item-detail/ItemDetail.tsx
function Ie({ item: e, onSave: r, metadata: i, preview: a, actions: o, readOnly: s = !1, className: c = "" }) {
	let l = g(e.revision);
	return /* @__PURE__ */ n("article", {
		className: `ds-item-detail ${c}`.trim(),
		"aria-labelledby": `item-detail-${e.id}`,
		children: [
			/* @__PURE__ */ n("header", {
				className: "ds-item-detail__header",
				children: [/* @__PURE__ */ n("div", { children: [/* @__PURE__ */ t("p", {
					className: "ds-item-detail__eyebrow",
					children: "Item detail"
				}), /* @__PURE__ */ t("h1", {
					id: `item-detail-${e.id}`,
					children: e.title
				})] }), o && /* @__PURE__ */ t("div", {
					className: "ds-item-detail__actions",
					children: o
				})]
			}),
			/* @__PURE__ */ n("section", {
				className: "ds-item-detail__body",
				"aria-label": "Item content",
				children: [/* @__PURE__ */ n("div", {
					className: "ds-item-detail__copy",
					children: [/* @__PURE__ */ t(Z, {
						label: "Title",
						value: e.title,
						onSave: async (e) => {
							let t = await r({ title: e }, l.current);
							if (!t.ok) throw Error(t.message);
						},
						readOnly: s,
						required: !0
					}), /* @__PURE__ */ t(Z, {
						label: "Description",
						value: e.description,
						onSave: async (e) => {
							let t = await r({ description: e }, l.current);
							if (!t.ok) throw Error(t.message);
						},
						readOnly: s,
						multiline: !0
					})]
				}), a && /* @__PURE__ */ t("section", {
					className: "ds-item-detail__preview",
					"aria-label": "Preview",
					children: a
				})]
			}),
			/* @__PURE__ */ n("aside", {
				className: "ds-item-detail__metadata",
				"aria-label": "Item metadata",
				children: [/* @__PURE__ */ t(X, {
					label: "Item facts",
					items: [{
						id: "revision",
						label: "Revision",
						value: e.revision
					}]
				}), i]
			})
		]
	});
}
function Le({ item: e, loading: r = !1, error: i, onRetry: a, onSave: o, metadata: s, preview: c, actions: l, readOnly: u, className: d = "" }) {
	return r ? /* @__PURE__ */ n("section", {
		className: `ds-item-detail ds-item-detail--loading ${d}`.trim(),
		"aria-label": "Loading item",
		children: [/* @__PURE__ */ t("p", {
			role: "status",
			children: "Loading item…"
		}), /* @__PURE__ */ t(K, { lines: 4 })]
	}) : i ? /* @__PURE__ */ t(W, {
		title: i,
		actionLabel: a ? "Try again" : void 0,
		onAction: a,
		className: d
	}) : e ? /* @__PURE__ */ t(Ie, {
		item: e,
		onSave: o,
		metadata: s,
		preview: c,
		actions: l,
		readOnly: u,
		className: d
	}, e.id) : /* @__PURE__ */ t("section", {
		className: `ds-item-detail ds-item-detail--empty ${d}`.trim(),
		children: /* @__PURE__ */ t("p", { children: "No item selected." })
	});
}
//#endregion
export { Se as AIResult, Y as AITaskStatus, Me as AIWorkspace, Ce as ActionCard, he as Alert, j as AppButton, Ne as AppLayout, ae as Breadcrumbs, Oe as BulkActionBar, we as CanvasText, F as CheckboxField, pe as Combobox, C as Container, S as DesignSystemRoot, V as Dialog, w as Divider, H as Drawer, W as ErrorState, X as FactGrid, ve as FileDropzone, be as FileList, ke as FilterToolbar, E as Grid, D as Inline, Z as InlineText, Fe as ItemBrowser, Le as ItemDetail, fe as Menu, me as MultiSelect, L as Pagination, Te as Panel, U as Popover, G as Progress, te as RadioGroup, O as ScrollArea, R as SegmentedControl, ne as SelectField, Q as SelectionTile, je as SettingsForm, K as Skeleton, k as Stack, q as StatusBadge, oe as Stepper, A as Surface, re as SwitchField, le as TabPanel, $ as Table, se as Tabs, Ee as Tag, De as TagButton, ee as TextAction, ie as TextArea, I as TextField, ge as ToastProvider, de as Tooltip, _e as useToast };
