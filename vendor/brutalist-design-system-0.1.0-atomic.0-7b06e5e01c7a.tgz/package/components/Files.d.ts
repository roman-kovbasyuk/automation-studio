
export type FileDropzoneProps = {
    label: string;
    onFiles: (files: File[]) => void;
    accept?: string;
    multiple?: boolean;
    maxSize?: number;
    disabled?: boolean;
    state?: 'idle' | 'uploading' | 'success' | 'error';
    progress?: number;
    error?: string;
    onRetry?: () => void;
};
export declare function FileDropzone({ label, onFiles, accept, multiple, maxSize, disabled, state, progress, error: externalError, onRetry }: FileDropzoneProps): import("react").JSX.Element;
export type FileItem = {
    id: string;
    name: string;
    size?: number;
};
export type FileListProps = {
    files: readonly FileItem[];
    onRemove?: (id: string) => void;
    disabled?: boolean;
};
export declare function FileList({ files, onRemove, disabled }: FileListProps): import("react").JSX.Element;
