import { type IconName } from '../atoms';
import { type MenuItem, type NavigationItem } from '../components';

export type SidebarPanelProps = {
    brand: {
        label: string;
    };
    primaryAction: {
        label: string;
        icon?: IconName;
        onClick: () => void;
    };
    navigation: readonly NavigationItem[];
    projects: readonly {
        id: string;
        title: string;
        href: string;
        pinned?: boolean;
        current?: boolean;
        actions?: readonly MenuItem[];
    }[];
    account?: {
        label: string;
        actions: readonly MenuItem[];
        onAction: (id: string) => void;
    };
    onProjectAction?: (projectId: string, actionId: string) => void;
};
export declare function SidebarPanel({ brand, primaryAction, navigation, projects, account, onProjectAction }: SidebarPanelProps): import("react").JSX.Element;
