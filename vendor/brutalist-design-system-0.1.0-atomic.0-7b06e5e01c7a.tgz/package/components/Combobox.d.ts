import type { SelectOption } from './Select';


export type ComboboxProps = {
    label: string;
    value: string;
    onChange: (value: string) => void;
    options: readonly SelectOption[];
    disabled?: boolean;
    name?: string;
};
export declare function Combobox({ label, value, onChange, options, disabled, name }: ComboboxProps): import("react").JSX.Element;
