import { type InputHTMLAttributes, type ReactNode } from 'react';


export type ToggleProps = Omit<InputHTMLAttributes<HTMLInputElement>, 'type' | 'role'> & {
    label: ReactNode;
    instructions?: ReactNode;
    error?: ReactNode;
};
export declare function Toggle({ label, instructions, error, id, checked, defaultChecked, className, 'aria-describedby': external, 'aria-invalid': invalid, ...props }: ToggleProps): import("react").JSX.Element;
