import type { ReactNode } from 'react';
import { type IconName } from '../atoms';

export type NavigationItem = {
    id: string;
    label: string;
    href?: string;
    icon?: IconName;
    current?: boolean;
    trailing?: ReactNode;
    onClick?: () => void;
    status?: string;
};
export type NavigationListProps = {
    label: string;
    items: readonly NavigationItem[];
};
export declare function NavigationList({ label, items }: NavigationListProps): import("react").JSX.Element;
