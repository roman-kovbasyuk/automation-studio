import { type HTMLAttributes, type LabelHTMLAttributes, type ReactNode } from 'react';
import { type IconName } from '../atoms';
import { type ButtonProps } from './Button';
import { type MenuItem } from './Overlays';

export type ButtonGroupProps = HTMLAttributes<HTMLDivElement> & {
    children: ReactNode;
    attached?: boolean;
};
export declare function ButtonGroup({ children, attached, className, ...props }: ButtonGroupProps): import("react").JSX.Element;
export type CompactButtonProps = ButtonProps;
export declare function CompactButton(props: CompactButtonProps): import("react").JSX.Element;
export type FancyButtonProps = ButtonProps & {
    subtitle?: string;
};
export declare function FancyButton({ children, subtitle, className, ...props }: FancyButtonProps): import("react").JSX.Element;
export type AvatarProps = HTMLAttributes<HTMLSpanElement> & {
    name: string;
    src?: string;
    size?: 'small' | 'medium' | 'large';
    status?: 'online' | 'offline' | 'busy';
};
export declare function Avatar({ name, src, size, status, className, ...props }: AvatarProps): import("react").JSX.Element;
export type AvatarGroupProps = {
    label: string;
    items: readonly Pick<AvatarProps, 'name' | 'src' | 'status'>[];
    max?: number;
    size?: AvatarProps['size'];
};
export declare function AvatarGroup({ label, items, max, size }: AvatarGroupProps): import("react").JSX.Element;
export declare function AvatarGroupCompact(props: AvatarGroupProps): import("react").JSX.Element;
export type BadgeProps = HTMLAttributes<HTMLSpanElement> & {
    children: ReactNode;
    tone?: 'neutral' | 'accent' | 'success' | 'danger' | 'warning';
    icon?: IconName;
};
export declare function Badge({ children, tone, icon, className, ...props }: BadgeProps): import("react").JSX.Element;
export type BannerProps = HTMLAttributes<HTMLElement> & {
    title: string;
    description?: string;
    tone?: 'neutral' | 'accent' | 'success' | 'danger' | 'warning';
    action?: ReactNode;
    onDismiss?: () => void;
};
export declare function Banner({ title, description, tone, action, onDismiss, className, ...props }: BannerProps): import("react").JSX.Element;
export type KbdProps = HTMLAttributes<HTMLElement> & {
    children: ReactNode;
};
export declare function Kbd({ children, className, ...props }: KbdProps): import("react").JSX.Element;
export type NotificationProps = BannerProps & {
    actions?: ReactNode;
};
export declare function Notification({ actions, action, className, ...props }: NotificationProps): import("react").JSX.Element;
export type ColorPickerProps = {
    label: string;
    value?: string;
    onChange?: (value: string) => void;
    presets?: readonly string[];
};
export declare function ColorPicker({ label, value, onChange, presets }: ColorPickerProps): import("react").JSX.Element;
export type DigitInputProps = {
    label: string;
    length?: number;
    value?: string;
    onChange?: (value: string) => void;
    disabled?: boolean;
    error?: string;
};
export declare function DigitInput({ label, length, value, onChange, disabled, error }: DigitInputProps): import("react").JSX.Element;
export type HintProps = HTMLAttributes<HTMLParagraphElement> & {
    children: ReactNode;
    tone?: 'secondary' | 'danger';
};
export declare function Hint({ children, tone, className, ...props }: HintProps): import("react").JSX.Element;
export type LabelProps = LabelHTMLAttributes<HTMLLabelElement> & {
    children: ReactNode;
    required?: boolean;
    hint?: ReactNode;
};
export declare function Label({ children, required, hint, className, ...props }: LabelProps): import("react").JSX.Element;
export type AccordionItem = {
    id: string;
    title: string;
    content: ReactNode;
    defaultOpen?: boolean;
};
export type AccordionProps = {
    label: string;
    items: readonly AccordionItem[];
    multiple?: boolean;
    className?: string;
};
export declare function Accordion({ label, items, multiple, className }: AccordionProps): import("react").JSX.Element;
export type TabMenuVerticalItem = {
    id: string;
    label: string;
    content: ReactNode;
};
export type TabMenuVerticalProps = {
    label: string;
    items: readonly TabMenuVerticalItem[];
    value?: string;
    onChange?: (value: string) => void;
};
export declare function TabMenuVertical({ label, items, value, onChange }: TabMenuVerticalProps): import("react").JSX.Element;
export type DotStepperProps = {
    label: string;
    steps: readonly string[];
    current?: number;
    onChange?: (index: number) => void;
};
export declare function DotStepper({ label, steps, current, onChange }: DotStepperProps): import("react").JSX.Element;
export type VerticalStepperProps = {
    label: string;
    steps: readonly {
        id: string;
        label: string;
        description?: string;
        complete?: boolean;
    }[];
    current?: string;
    onChange?: (id: string) => void;
};
export declare function VerticalStepper({ label, steps, current, onChange }: VerticalStepperProps): import("react").JSX.Element;
export type CommandMenuProps = {
    label: string;
    items: readonly MenuItem[];
    onSelect: (id: string) => void;
    placeholder?: string;
};
export declare function CommandMenu({ label, items, onSelect, placeholder }: CommandMenuProps): import("react").JSX.Element;
