export type SegmentedOption = {
    value: string;
    label: string;
    disabled?: boolean;
};
export type SegmentedControlProps = {
    options: SegmentedOption[];
    value: string;
    onValueChange: (value: string) => void;
    ariaLabel: string;
    className?: string;
};
/** A compact native-radio choice for mutually exclusive visual modes. */
export declare function SegmentedControl({ options, value, onValueChange, ariaLabel, className }: SegmentedControlProps): import("react").JSX.Element;
