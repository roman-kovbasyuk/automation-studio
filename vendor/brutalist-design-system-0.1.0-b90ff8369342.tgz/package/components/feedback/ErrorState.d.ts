import type { ReactNode } from 'react';
export type ErrorStateProps = {
    title: ReactNode;
    description?: ReactNode;
    actionLabel?: string;
    onAction?: () => void;
    className?: string;
};
/** A contained recovery state for a failed section or empty content region. */
export declare function ErrorState({ title, description, actionLabel, onAction, className }: ErrorStateProps): import("react").JSX.Element;
