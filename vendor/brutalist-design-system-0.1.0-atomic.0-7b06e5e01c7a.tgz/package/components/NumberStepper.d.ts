import { type ReactNode } from 'react';

export type NumberStepperProps = {
    label: string;
    value: number;
    onChange: (value: number) => void;
    min?: number;
    max?: number;
    step?: number;
    name?: string;
    id?: string;
    disabled?: boolean;
    instructions?: ReactNode;
    className?: string;
};
export declare function NumberStepper({ label, value, onChange, min, max, step, name, id, disabled, instructions, className }: NumberStepperProps): import("react").JSX.Element;
