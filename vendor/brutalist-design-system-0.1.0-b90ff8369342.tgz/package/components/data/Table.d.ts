import type { ReactNode } from 'react';
export type Column<T> = {
    id: string;
    header: string;
    cell: (row: T) => ReactNode;
    sortable?: boolean;
    className?: string;
};
export type Sort = {
    columnId: string;
    direction: 'asc' | 'desc';
};
export type TableProps<T> = {
    label: string;
    rows: readonly T[];
    columns: readonly Column<T>[];
    getRowId: (row: T) => string;
    sort?: Sort;
    onSortChange?: (sort: Sort) => void;
    selectedIds?: readonly string[];
    onSelectionChange?: (ids: string[]) => void;
    emptyMessage?: ReactNode;
    className?: string;
};
/** A semantic, caller-controlled table for ordinary bounded result sets. */
export declare function Table<T>({ label, rows, columns, getRowId, sort, onSortChange, selectedIds, onSelectionChange, emptyMessage, className, }: TableProps<T>): import("react").JSX.Element;
