import type { FormHTMLAttributes, ReactNode } from 'react';
export type FormProps = FormHTMLAttributes<HTMLFormElement> & {
    label: string;
};
export declare function Form({ label, children, className, ...props }: FormProps): import("react").JSX.Element;
export type FormActionsProps = {
    onCancel?: () => void;
    submitLabel?: string;
    cancelLabel?: string;
    busy?: boolean;
    disabled?: boolean;
    message?: ReactNode;
};
export declare function FormActions({ onCancel, submitLabel, cancelLabel, busy, disabled, message }: FormActionsProps): import("react").JSX.Element;
