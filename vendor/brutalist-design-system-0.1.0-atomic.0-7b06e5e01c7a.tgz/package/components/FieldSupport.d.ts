import type { ReactNode } from 'react';
export declare const hasContent: (value: ReactNode) => boolean;
export declare const supportIds: (id: string, instructions?: ReactNode, error?: ReactNode, external?: string) => string | undefined;
export declare function FieldSupport({ id, instructions, error }: {
    id: string;
    instructions?: ReactNode;
    error?: ReactNode;
}): import("react").JSX.Element;
