import type { ReactNode } from 'react';
export type Item = {
    id: string;
    title: string;
    description?: string;
    status?: string;
};
export type ItemBrowserProps = {
    items: readonly Item[];
    total: number;
    query: string;
    onQueryChange: (query: string) => void;
    page: number;
    pageCount: number;
    onPageChange: (page: number) => void;
    view: 'list' | 'grid';
    onViewChange: (view: 'list' | 'grid') => void;
    selectedIds: readonly string[];
    onSelectionChange: (ids: string[]) => void;
    loading?: boolean;
    error?: string;
    onRetry?: () => void;
    onOpen: (id: string) => void;
    bulkActions?: ReactNode;
    className?: string;
};
/** A controlled library browser. Filtering, loading and mutations remain caller-owned. */
export declare function ItemBrowser({ items, total, query, onQueryChange, page, pageCount, onPageChange, view, onViewChange, selectedIds, onSelectionChange, loading, error, onRetry, onOpen, bulkActions, className }: ItemBrowserProps): import("react").JSX.Element;
