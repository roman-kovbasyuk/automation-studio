import type { ReactNode } from 'react';

export type AlertTone = 'neutral' | 'success' | 'danger' | 'warning' | 'info' | 'feature';
export type AlertVariant = 'filled' | 'light' | 'lighter' | 'stroke';
export type AlertSize = 'small' | 'large';
export type AlertProps = {
    title: string;
    description?: ReactNode;
    tone?: AlertTone;
    variant?: AlertVariant;
    size?: AlertSize;
    showIcon?: boolean;
    announce?: boolean;
    className?: string;
    action?: ReactNode;
};
export declare function Alert({ title, description, tone, variant, size, showIcon, announce, className, action }: AlertProps): import("react").JSX.Element;
