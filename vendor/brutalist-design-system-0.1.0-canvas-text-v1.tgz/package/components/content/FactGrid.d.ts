import type { ReactNode } from 'react';
export type FactGridItem = {
    id: string;
    label: ReactNode;
    value: ReactNode;
    emphasis?: boolean;
};
export type FactGridProps = {
    items: FactGridItem[];
    label?: string;
    className?: string;
};
/** A responsive definition list for compact, labelled facts. */
export declare function FactGrid({ items, label, className }: FactGridProps): import("react").JSX.Element;
