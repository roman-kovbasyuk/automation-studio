import { type InputHTMLAttributes, type ReactNode } from 'react';

export type TextFieldProps = Omit<InputHTMLAttributes<HTMLInputElement>, 'type'> & {
    type?: 'text' | 'email' | 'password' | 'search' | 'url' | 'tel' | 'date' | 'time' | 'number' | 'color';
    label: ReactNode;
    instructions?: ReactNode;
    error?: ReactNode;
    width?: 'full' | 'content';
    trailing?: ReactNode;
};
export declare function TextField({ label, instructions, error, id, className, type, width, trailing, onChange, 'aria-describedby': external, 'aria-invalid': invalid, ...props }: TextFieldProps): import("react").JSX.Element;
