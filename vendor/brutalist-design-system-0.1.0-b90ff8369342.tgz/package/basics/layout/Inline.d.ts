import type { ComponentProps } from 'react';
import { type Space } from './types';
export type InlineProps = ComponentProps<'div'> & {
    gap?: Space;
};
export declare function Inline({ gap, className, style, ...props }: InlineProps): import("react").JSX.Element;
