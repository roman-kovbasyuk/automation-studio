import type { ButtonHTMLAttributes, ReactNode } from 'react';
export type SelectionTileProps = Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'children' | 'onChange'> & {
    label: string;
    selected?: boolean;
    onChange?: () => void;
    caption?: ReactNode;
    children: ReactNode;
};
/** A pressable visual-choice tile. It owns only its single selection callback. */
export declare function SelectionTile({ label, selected, onChange, disabled, caption, children, className, ...props }: SelectionTileProps): import("react").JSX.Element;
