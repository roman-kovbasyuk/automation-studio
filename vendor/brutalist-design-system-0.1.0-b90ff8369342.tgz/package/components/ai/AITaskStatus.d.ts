export type AITaskState = 'queued' | 'running' | 'succeeded' | 'failed';
export type AITaskStatusProps = {
    status: AITaskState;
    label: string;
    progress?: number;
    className?: string;
};
/** Communicates caller-owned asynchronous work without executing or polling it. */
export declare function AITaskStatus({ status, label, progress, className }: AITaskStatusProps): import("react").JSX.Element;
