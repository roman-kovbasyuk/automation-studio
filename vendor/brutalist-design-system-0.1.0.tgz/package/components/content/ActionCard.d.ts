import type { HTMLAttributes, ReactNode } from 'react';
export type ActionCardProps = HTMLAttributes<HTMLElement> & {
    /** A short label that identifies the card to assistive technology. */
    label: string;
    status?: ReactNode;
    actions?: ReactNode;
    persistentAction?: ReactNode;
    highlighted?: boolean;
    children: ReactNode;
};
/** A neutral content surface with optional persistent and revealed actions. */
export declare function ActionCard({ label, status, actions, persistentAction, highlighted, children, className, ...props }: ActionCardProps): import("react").JSX.Element;
