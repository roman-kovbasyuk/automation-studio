import { type ReactNode } from 'react';
import { type IconName } from '../atoms';

export type DialogProps = {
    tone?: 'neutral' | 'warning' | 'confirmation';
    title: string;
    description?: string;
    trigger: string;
    children: ReactNode;
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
};
export declare function Dialog(props: DialogProps): import("react").JSX.Element;
export type DrawerProps = DialogProps;
export declare function Drawer(props: DrawerProps): import("react").JSX.Element;
export type PopoverProps = {
    label: string;
    children: ReactNode;
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
    disabled?: boolean;
    variant?: 'default' | 'field';
};
export declare function Popover({ label, children, open, onOpenChange, disabled, variant }: PopoverProps): import("react").JSX.Element;
export type MenuItem = {
    id: string;
    label: string;
    icon?: IconName;
    disabled?: boolean;
    danger?: boolean;
};
export type MenuProps = {
    iconOnly?: boolean;
    icon?: IconName;
    side?: 'top' | 'bottom';
    label: string;
    items: readonly MenuItem[];
    onSelect: (id: string) => void;
    disabled?: boolean;
};
export declare function Menu({ label, items, onSelect, disabled, iconOnly, icon, side }: MenuProps): import("react").JSX.Element;
export type TooltipProps = {
    label: string;
    content: string;
};
export declare function Tooltip({ label, content }: TooltipProps): import("react").JSX.Element;
