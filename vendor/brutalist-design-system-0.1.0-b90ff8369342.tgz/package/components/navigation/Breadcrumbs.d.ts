import type { ReactNode } from 'react';
export type BreadcrumbItem = {
    label: ReactNode;
    href?: string;
};
export type BreadcrumbsProps = {
    items: BreadcrumbItem[];
    ariaLabel?: string;
    className?: string;
};
/** A location trail whose final item identifies the current page. */
export declare function Breadcrumbs({ items, ariaLabel, className }: BreadcrumbsProps): import("react").JSX.Element;
