import type { ReactNode } from 'react';
export type FactGridItem = {
    id: string;
    label: ReactNode;
    value: ReactNode;
    emphasis?: boolean;
};
export type FactGridProps = {
    items: FactGridItem[];
    label?: string;
    className?: string;
    theme?: 'light' | 'dark' | 'system';
    density?: 'comfortable' | 'compact';
};
/** A responsive definition list for compact, labelled facts. */
export declare function FactGrid({ items, label, className, theme, density }: FactGridProps): import("react").JSX.Element;
