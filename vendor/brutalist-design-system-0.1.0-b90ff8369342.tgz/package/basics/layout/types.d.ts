export type Space = 1 | 2 | 3 | 4 | 6 | 8 | 12 | 16;
export declare function spaceVariable(space: Space | undefined): string;
