import { type ReactNode } from 'react';

export type SliderProps = {
    label: string;
    value: number;
    onChange: (value: number) => void;
    min?: number;
    max?: number;
    step?: number;
    name?: string;
    id?: string;
    disabled?: boolean;
    instructions?: ReactNode;
    formatValue?: (value: number) => string;
    className?: string;
};
export declare function Slider({ label, value, onChange, min, max, step, name, id, disabled, instructions, formatValue, className }: SliderProps): import("react").JSX.Element;
