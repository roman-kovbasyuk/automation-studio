import type { HTMLAttributes, ReactNode } from 'react';
export type TagTone = 'neutral' | 'accent' | 'success' | 'warning' | 'danger' | 'info';
export type TagVariant = 'filled' | 'outline';
export type TagProps = Omit<HTMLAttributes<HTMLSpanElement>, 'children'> & {
    children: ReactNode;
    tone?: TagTone;
    variant?: TagVariant;
};
/** A compact, display-only label with explicit visual and semantic tone. */
export declare function Tag({ children, tone, variant, className, ...props }: TagProps): import("react").JSX.Element;
