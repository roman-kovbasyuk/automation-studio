import type { AnchorHTMLAttributes, ButtonHTMLAttributes, ReactNode } from 'react';

export type TextActionProps = (({
    href: string;
} & AnchorHTMLAttributes<HTMLAnchorElement>) | ({
    href?: never;
} & ButtonHTMLAttributes<HTMLButtonElement>)) & {
    children: ReactNode;
    disabled?: boolean;
};
export declare function TextAction({ children, disabled, className, ...props }: TextActionProps): import("react").JSX.Element;
