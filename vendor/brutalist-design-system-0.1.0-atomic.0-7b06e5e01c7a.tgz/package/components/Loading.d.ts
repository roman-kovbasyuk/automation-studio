import type { ReactNode } from 'react';

export type SpinnerProps = {
    label: string;
};
export declare function Spinner({ label }: SpinnerProps): import("react").JSX.Element;
export type SkeletonProps = {
    label?: string;
    lines?: number;
};
export declare function Skeleton({ label, lines }: SkeletonProps): import("react").JSX.Element;
export type EmptyStateProps = {
    title: string;
    description?: string;
    action?: ReactNode;
};
export declare function EmptyState({ title, description, action }: EmptyStateProps): import("react").JSX.Element;
