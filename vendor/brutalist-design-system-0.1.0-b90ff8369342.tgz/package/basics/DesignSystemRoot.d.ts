import type { ComponentProps } from 'react';
export declare function DesignSystemRoot({ className, ...props }: ComponentProps<'div'>): import("react").JSX.Element;
