import { type ChangeEvent } from 'react';
import type { TextFieldProps } from './TextField';



export type DatePickerProps = Omit<TextFieldProps, 'type' | 'value' | 'defaultValue' | 'min' | 'max' | 'onChange'> & {
    value?: string;
    defaultValue?: string;
    min?: string;
    max?: string;
    onChange?: (event: ChangeEvent<HTMLInputElement>) => void;
    onValueChange?: (value: string) => void;
};
export declare function DatePicker({ label, value, defaultValue, min, max, onChange, onValueChange, disabled, readOnly, required, name, id, instructions, error, className }: DatePickerProps): import("react").JSX.Element;
