import type { AnchorHTMLAttributes, ButtonHTMLAttributes, MouseEvent, ReactNode, Ref } from 'react';
type SharedProps = {
    children: ReactNode;
    variant?: 'primary' | 'secondary' | 'danger' | 'quiet' | 'icon';
    size?: 'default' | 'compact' | 'small';
    iconOnly?: boolean;
    busy?: boolean;
    showBusyIndicator?: boolean;
    disabled?: boolean;
    className?: string;
    ref?: Ref<HTMLButtonElement | HTMLAnchorElement>;
};
type ButtonProps = SharedProps & Omit<ButtonHTMLAttributes<HTMLButtonElement>, keyof SharedProps | 'disabled'> & {
    as?: 'button';
};
type AnchorProps = SharedProps & Omit<AnchorHTMLAttributes<HTMLAnchorElement>, keyof SharedProps | 'onClick'> & {
    as: 'a';
    onClick?: (event: MouseEvent<HTMLAnchorElement>) => void;
};
export type AppButtonProps = ButtonProps | AnchorProps;
/** A tactile action button with consistent pending and disabled behavior. */
export declare function AppButton(props: AppButtonProps): import("react").JSX.Element;
export {};
