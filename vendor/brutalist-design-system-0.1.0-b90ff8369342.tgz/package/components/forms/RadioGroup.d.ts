import type { ReactNode } from 'react';
export type RadioOption = {
    value: string;
    label: ReactNode;
    disabled?: boolean;
};
export type RadioGroupProps = {
    id?: string;
    name?: string;
    label: ReactNode;
    instructions?: ReactNode;
    error?: ReactNode;
    options: RadioOption[];
    value?: string;
    defaultValue?: string;
    onChange?: (value: string) => void;
    disabled?: boolean;
    className?: string;
};
/** A native radio group that shares one visible label and support copy. */
export declare function RadioGroup({ id: providedId, name: providedName, label, instructions, error, options, value, defaultValue, onChange, disabled, className }: RadioGroupProps): import("react").JSX.Element;
