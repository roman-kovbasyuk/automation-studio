import type { ReactNode } from 'react';
type FieldSupportProps = {
    id: string;
    instructions?: ReactNode;
    error?: ReactNode;
};
export type FieldMeta = {
    id?: string;
    instructions?: ReactNode;
    error?: ReactNode;
};
export declare function useFieldId(providedId?: string): string;
export declare function describedBy(id: string, instructions?: ReactNode, error?: ReactNode): string | undefined;
export declare function FieldSupport({ id, instructions, error }: FieldSupportProps): import("react").JSX.Element;
export {};
