
export type PaginationProps = {
    page: number;
    pageCount: number;
    onPageChange: (page: number) => void;
    disabled?: boolean;
    label?: string;
    className?: string;
};
export declare function Pagination({ page, pageCount, onPageChange, disabled, label, className }: PaginationProps): import("react").JSX.Element;
