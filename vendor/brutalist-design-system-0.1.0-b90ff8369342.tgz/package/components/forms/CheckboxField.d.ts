import type { InputHTMLAttributes, ReactNode, Ref } from 'react';
export type CheckboxFieldProps = Omit<InputHTMLAttributes<HTMLInputElement>, 'id' | 'type' | 'aria-describedby' | 'aria-invalid'> & {
    id?: string;
    label: ReactNode;
    instructions?: ReactNode;
    error?: ReactNode;
    indeterminate?: boolean;
    ref?: Ref<HTMLInputElement>;
};
/** A labelled native checkbox. Its whole label is a click target. */
export declare function CheckboxField({ id: providedId, label, instructions, error, indeterminate, ref, className, ...props }: CheckboxFieldProps): import("react").JSX.Element;
