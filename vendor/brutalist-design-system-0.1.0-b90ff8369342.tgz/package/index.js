import { Fragment as e, jsx as t, jsxs as n } from "react/jsx-runtime";
import { Check as r, ChevronDown as i, LoaderCircle as a, MoreHorizontal as o, Pencil as s, Plus as c, Search as l, TriangleAlert as u, UserRound as d, X as f } from "lucide-react";
import { createContext as p, useCallback as m, useContext as h, useEffect as g, useId as _, useImperativeHandle as v, useMemo as y, useRef as b, useState as x } from "react";
import { Dialog as S, DropdownMenu as C, Popover as w, Tooltip as T } from "radix-ui";
//#region src/components/design-system/basics/DesignSystemRoot.tsx
function E({ className: e = "", ...n }) {
	return /* @__PURE__ */ t("div", {
		...n,
		className: `ds-root ${e}`.trim()
	});
}
//#endregion
//#region src/components/design-system/basics/layout/Container.tsx
function D({ maxWidth: e = 1200, className: n = "", style: r, ...i }) {
	return /* @__PURE__ */ t("div", {
		...i,
		className: `ds-container ${n}`.trim(),
		style: {
			...r,
			"--ds-container-max": `${e}px`
		}
	});
}
//#endregion
//#region src/components/design-system/basics/layout/Divider.tsx
function O({ className: e = "", ...n }) {
	return /* @__PURE__ */ t("hr", {
		...n,
		className: `ds-divider ${e}`.trim()
	});
}
//#endregion
//#region src/components/design-system/basics/layout/types.ts
function k(e) {
	return `var(--v2-space-${e ?? 4})`;
}
//#endregion
//#region src/components/design-system/basics/layout/Grid.tsx
function A({ gap: e, minItemWidth: n = 280, className: r = "", style: i, ...a }) {
	return /* @__PURE__ */ t("div", {
		...a,
		className: `ds-grid ${r}`.trim(),
		style: {
			...i,
			"--ds-gap": k(e),
			"--ds-grid-min": `${n}px`
		}
	});
}
//#endregion
//#region src/components/design-system/basics/layout/Inline.tsx
function j({ gap: e, className: n = "", style: r, ...i }) {
	return /* @__PURE__ */ t("div", {
		...i,
		className: `ds-inline ${n}`.trim(),
		style: {
			...r,
			"--ds-gap": k(e)
		}
	});
}
//#endregion
//#region src/components/design-system/basics/layout/ScrollArea.tsx
function ee({ label: e, className: n = "", tabIndex: r, ...i }) {
	return /* @__PURE__ */ t("div", {
		...i,
		"aria-label": e,
		className: `ds-scroll-area ${n}`.trim(),
		role: "region",
		tabIndex: r ?? 0
	});
}
//#endregion
//#region src/components/design-system/basics/layout/Stack.tsx
function M({ gap: e, className: n = "", style: r, ...i }) {
	return /* @__PURE__ */ t("div", {
		...i,
		className: `ds-stack ${n}`.trim(),
		style: {
			...r,
			"--ds-gap": k(e)
		}
	});
}
//#endregion
//#region src/components/design-system/basics/layout/Surface.tsx
function te({ tone: e = "surface", className: n = "", ...r }) {
	return /* @__PURE__ */ t("div", {
		...r,
		className: `ds-surface ds-surface--${e} ${n}`.trim()
	});
}
//#endregion
//#region src/components/design-system/components/actions/AppButton.tsx
function N(e) {
	if (e.as === "a") {
		let { children: r, as: i, variant: o = "secondary", size: s = "default", iconOnly: c = !1, busy: l = !1, showBusyIndicator: u = !0, disabled: d = !1, className: f = "", ref: p, onClick: m, ...h } = e, g = l || d, _ = [
			"ds-button",
			`ds-button--${o === "icon" ? "secondary" : o}`,
			(c || o === "icon") && "ds-button--icon",
			f
		].filter(Boolean).join(" "), v = (e) => {
			if (g) {
				e.preventDefault(), e.stopPropagation();
				return;
			}
			m?.(e);
		};
		return /* @__PURE__ */ n("a", {
			...h,
			ref: p,
			className: _,
			"data-size": s,
			"aria-busy": l || void 0,
			"aria-disabled": g || void 0,
			tabIndex: g ? -1 : h.tabIndex,
			onClick: v,
			children: [l && u && /* @__PURE__ */ t(a, {
				size: 16,
				className: "ds-button__spinner",
				"aria-hidden": "true"
			}), r]
		});
	}
	let { children: r, variant: i = "secondary", size: o = "default", iconOnly: s = !1, busy: c = !1, showBusyIndicator: l = !0, disabled: u = !1, className: d = "", ref: f, onClick: p, ...m } = e, h = c || u, g = [
		"ds-button",
		`ds-button--${i === "icon" ? "secondary" : i}`,
		(s || i === "icon") && "ds-button--icon",
		d
	].filter(Boolean).join(" ");
	return /* @__PURE__ */ n("button", {
		...m,
		ref: f,
		type: e.type ?? "button",
		className: g,
		"data-size": o,
		"aria-busy": c || void 0,
		disabled: h,
		onClick: p,
		children: [c && l && /* @__PURE__ */ t(a, {
			size: 16,
			className: "ds-button__spinner",
			"aria-hidden": "true"
		}), r]
	});
}
//#endregion
//#region src/components/design-system/components/actions/TextAction.tsx
function ne({ children: e, className: n = "", ...r }) {
	return /* @__PURE__ */ t(N, {
		...r,
		variant: "quiet",
		size: "compact",
		className: `ds-text-action ${n}`,
		children: e
	});
}
//#endregion
//#region src/components/design-system/components/forms/Form.tsx
function P({ className: e = "", ...n }) {
	return /* @__PURE__ */ t("form", {
		...n,
		className: `ds-form ${e}`.trim()
	});
}
function re({ title: e, description: r, children: i, elevated: a = !1, unstyled: o = !1, className: s = "", ...c }) {
	let l = _();
	return /* @__PURE__ */ n("fieldset", {
		...c,
		className: `ds-form-section${a ? " ds-form-section--elevated" : ""}${o ? " ds-form-section--unstyled" : ""} ${s}`.trim(),
		"aria-describedby": [c["aria-describedby"], r ? l : void 0].filter(Boolean).join(" ") || void 0,
		children: [/* @__PURE__ */ t("legend", {
			className: "ds-form-section__title",
			children: e
		}), /* @__PURE__ */ n(M, {
			gap: 4,
			children: [r && /* @__PURE__ */ t("p", {
				className: "ds-form-section__description",
				id: l,
				children: r
			}), i]
		})]
	});
}
function F({ children: e, className: n = "", ...r }) {
	return /* @__PURE__ */ t("footer", {
		...r,
		className: `ds-form-actions ${n}`.trim(),
		children: /* @__PURE__ */ t(j, {
			gap: 2,
			className: "ds-form-actions__controls",
			children: e
		})
	});
}
//#endregion
//#region src/components/design-system/components/forms/FieldSupport.tsx
function I(e) {
	let t = _();
	return e ?? `ds-field-${t.replace(/:/g, "")}`;
}
function L(e, t, n) {
	let r = [t ? `${e}-instructions` : void 0, n ? `${e}-error` : void 0].filter(Boolean);
	return r.length ? r.join(" ") : void 0;
}
function R({ id: r, instructions: i, error: a }) {
	return /* @__PURE__ */ n(e, { children: [i && /* @__PURE__ */ t("p", {
		id: `${r}-instructions`,
		className: "ds-field__instructions",
		children: i
	}), a && /* @__PURE__ */ t("p", {
		id: `${r}-error`,
		className: "ds-field__error",
		role: "alert",
		children: a
	})] });
}
//#endregion
//#region src/components/design-system/components/forms/CheckboxField.tsx
function z({ id: e, label: r, instructions: i, error: a, indeterminate: o = !1, ref: s, className: c = "", ...l }) {
	let u = I(e), d = b(null);
	return v(s, () => d.current, []), g(() => {
		d.current && (d.current.indeterminate = o);
	}, [o]), /* @__PURE__ */ n("div", {
		className: `ds-choice-field ${c}`.trim(),
		"data-mixed": o || void 0,
		children: [/* @__PURE__ */ n("label", {
			className: "ds-choice-field__label",
			htmlFor: u,
			children: [/* @__PURE__ */ t("input", {
				...l,
				ref: d,
				id: u,
				type: "checkbox",
				"aria-checked": o ? "mixed" : void 0,
				className: "ds-choice-field__control",
				"aria-describedby": L(u, i, a),
				"aria-invalid": a ? !0 : void 0
			}), /* @__PURE__ */ t("span", { children: r })]
		}), /* @__PURE__ */ t(R, {
			id: u,
			instructions: i,
			error: a
		})]
	});
}
//#endregion
//#region src/components/design-system/components/forms/RadioGroup.tsx
function ie({ id: e, name: r, label: i, instructions: a, error: o, options: s, value: c, defaultValue: l, onChange: u, disabled: d = !1, className: f = "" }) {
	let p = I(e), m = _(), h = r ?? `ds-radio-${m.replace(/:/g, "")}`;
	return /* @__PURE__ */ n("fieldset", {
		className: `ds-radio-group ${f}`.trim(),
		"aria-describedby": L(p, a, o),
		children: [
			/* @__PURE__ */ t("legend", {
				className: "ds-field__label",
				children: i
			}),
			/* @__PURE__ */ t("div", {
				className: "ds-radio-group__options",
				role: "radiogroup",
				"aria-label": typeof i == "string" ? i : void 0,
				children: s.map((e) => {
					let r = `${p}-${e.value}`;
					return /* @__PURE__ */ n("label", {
						className: "ds-choice-field__label",
						htmlFor: r,
						children: [/* @__PURE__ */ t("input", {
							id: r,
							className: "ds-choice-field__control",
							type: "radio",
							name: h,
							value: e.value,
							checked: c === void 0 ? void 0 : c === e.value,
							defaultChecked: l === e.value,
							disabled: d || e.disabled,
							"aria-invalid": o ? !0 : void 0,
							onChange: () => u?.(e.value)
						}), /* @__PURE__ */ t("span", { children: e.label })]
					}, e.value);
				})
			}),
			/* @__PURE__ */ t(R, {
				id: p,
				instructions: a,
				error: o
			})
		]
	});
}
//#endregion
//#region src/components/design-system/components/forms/SelectField.tsx
function ae({ id: e, label: r, instructions: i, error: a, options: o, className: s = "", ...c }) {
	let l = I(e);
	return /* @__PURE__ */ n("div", {
		className: `ds-field ${s}`.trim(),
		children: [
			/* @__PURE__ */ t("label", {
				className: "ds-field__label",
				htmlFor: l,
				children: r
			}),
			/* @__PURE__ */ t("select", {
				...c,
				id: l,
				className: "ds-field__control",
				"aria-describedby": L(l, i, a),
				"aria-invalid": a ? !0 : void 0,
				children: o.map((e) => /* @__PURE__ */ t("option", {
					value: e.value,
					disabled: e.disabled,
					children: e.label
				}, e.value))
			}),
			/* @__PURE__ */ t(R, {
				id: l,
				instructions: i,
				error: a
			})
		]
	});
}
//#endregion
//#region src/components/design-system/components/forms/SwitchField.tsx
function B({ id: e, label: r, instructions: i, error: a, onCheckedChange: o, className: s = "", ...c }) {
	let l = I(e);
	return /* @__PURE__ */ n("div", {
		className: `ds-switch-field ${s}`.trim(),
		children: [/* @__PURE__ */ n("label", {
			className: "ds-switch-field__label",
			htmlFor: l,
			children: [
				/* @__PURE__ */ t("input", {
					...c,
					id: l,
					type: "checkbox",
					role: "switch",
					className: "ds-switch-field__control",
					"aria-describedby": L(l, i, a),
					"aria-invalid": a ? !0 : void 0,
					onChange: (e) => o?.(e.currentTarget.checked)
				}),
				/* @__PURE__ */ t("span", {
					className: "ds-switch-field__track",
					"aria-hidden": "true",
					children: /* @__PURE__ */ t("span", { className: "ds-switch-field__thumb" })
				}),
				/* @__PURE__ */ t("span", { children: r })
			]
		}), /* @__PURE__ */ t(R, {
			id: l,
			instructions: i,
			error: a
		})]
	});
}
//#endregion
//#region src/components/design-system/components/forms/TextArea.tsx
function oe({ id: e, label: r, instructions: i, error: a, className: o = "", ...s }) {
	let c = I(e);
	return /* @__PURE__ */ n("div", {
		className: `ds-field ${o}`.trim(),
		children: [
			/* @__PURE__ */ t("label", {
				className: "ds-field__label",
				htmlFor: c,
				children: r
			}),
			/* @__PURE__ */ t("textarea", {
				...s,
				id: c,
				className: "ds-field__control ds-field__control--textarea",
				"aria-describedby": L(c, i, a),
				"aria-invalid": a ? !0 : void 0
			}),
			/* @__PURE__ */ t(R, {
				id: c,
				instructions: i,
				error: a
			})
		]
	});
}
//#endregion
//#region src/components/design-system/components/forms/TextField.tsx
function V({ id: e, label: r, instructions: i, error: a, className: o = "", ...s }) {
	let c = I(e);
	return /* @__PURE__ */ n("div", {
		className: `ds-field ${o}`.trim(),
		children: [
			/* @__PURE__ */ t("label", {
				className: "ds-field__label",
				htmlFor: c,
				children: r
			}),
			/* @__PURE__ */ t("input", {
				...s,
				id: c,
				className: "ds-field__control",
				"aria-describedby": L(c, i, a),
				"aria-invalid": a ? !0 : void 0
			}),
			/* @__PURE__ */ t(R, {
				id: c,
				instructions: i,
				error: a
			})
		]
	});
}
//#endregion
//#region src/components/design-system/components/navigation/Breadcrumbs.tsx
function se({ items: e, ariaLabel: r = "Breadcrumb", className: i = "" }) {
	return /* @__PURE__ */ t("nav", {
		className: `ds-breadcrumbs ${i}`.trim(),
		"aria-label": r,
		children: /* @__PURE__ */ t("ol", { children: e.map((r, i) => {
			let a = i === e.length - 1;
			return /* @__PURE__ */ n("li", { children: [i > 0 && /* @__PURE__ */ t("span", {
				className: "ds-breadcrumbs__separator",
				"aria-hidden": "true",
				children: "/"
			}), r.href && !a ? /* @__PURE__ */ t("a", {
				href: r.href,
				children: r.label
			}) : /* @__PURE__ */ t("span", {
				"aria-current": a ? "page" : void 0,
				children: r.label
			})] }, i);
		}) })
	});
}
//#endregion
//#region src/components/design-system/components/navigation/Pagination.tsx
function ce({ page: e, pageCount: r, onPageChange: i, className: a = "" }) {
	let o = Math.min(Math.max(e, 1), Math.max(r, 1)), s = Array.from({ length: Math.max(r, 0) }, (e, t) => t + 1);
	return /* @__PURE__ */ n("nav", {
		className: `ds-pagination ${a}`.trim(),
		"aria-label": "Pagination",
		children: [
			/* @__PURE__ */ t("button", {
				type: "button",
				"aria-label": "Previous page",
				disabled: o <= 1,
				onClick: () => i(o - 1),
				children: "Previous"
			}),
			/* @__PURE__ */ t("ol", { children: s.map((e) => /* @__PURE__ */ t("li", { children: /* @__PURE__ */ t("button", {
				type: "button",
				"aria-label": `Page ${e}`,
				"aria-current": e === o ? "page" : void 0,
				onClick: () => i(e),
				children: e
			}) }, e)) }),
			/* @__PURE__ */ t("button", {
				type: "button",
				"aria-label": "Next page",
				disabled: o >= r,
				onClick: () => i(o + 1),
				children: "Next"
			})
		]
	});
}
//#endregion
//#region src/components/design-system/components/navigation/SegmentedControl.tsx
function le({ options: e, value: r, onValueChange: i, ariaLabel: a, className: o = "" }) {
	return /* @__PURE__ */ t("div", {
		className: `ds-segmented-control ${o}`.trim(),
		role: "radiogroup",
		"aria-label": a,
		children: e.map((e) => /* @__PURE__ */ n("label", {
			className: "ds-segmented-control__option",
			"data-selected": e.value === r || void 0,
			children: [/* @__PURE__ */ t("input", {
				type: "radio",
				name: a,
				value: e.value,
				checked: e.value === r,
				disabled: e.disabled,
				onChange: () => i(e.value)
			}), /* @__PURE__ */ t("span", { children: e.label })]
		}, e.value))
	});
}
//#endregion
//#region src/components/design-system/components/navigation/Stepper.tsx
function ue({ steps: e, activeStep: r, ariaLabel: i = "Progress", className: a = "" }) {
	return /* @__PURE__ */ t("ol", {
		className: `ds-stepper ${a}`.trim(),
		"aria-label": i,
		children: e.map((e, i) => {
			let a = i < r ? "complete" : i === r ? "current" : e.disabled ? "disabled" : "upcoming";
			return /* @__PURE__ */ n("li", {
				"data-status": a,
				"aria-current": a === "current" ? "step" : void 0,
				children: [/* @__PURE__ */ t("span", {
					className: "ds-stepper__number",
					"aria-hidden": "true",
					children: i + 1
				}), /* @__PURE__ */ n("span", {
					className: "ds-stepper__content",
					children: [/* @__PURE__ */ t("strong", { children: e.label }), e.description && /* @__PURE__ */ t("small", { children: e.description })]
				})]
			}, e.label);
		})
	});
}
//#endregion
//#region src/components/design-system/components/navigation/Tabs.tsx
function H(e, t, n) {
	let r = `${e}-${n(t)}`;
	return {
		tab: `${r}-tab`,
		panel: `${r}-panel`
	};
}
function de(e) {
	return /* @__PURE__ */ t(fe, { ...e });
}
function fe({ items: e, value: n, onValueChange: r, ariaLabel: i, idPrefix: a = "tab", className: o = "", keyForValue: s = encodeURIComponent }) {
	let c = b(/* @__PURE__ */ new Map()), l = e.filter((e) => !e.disabled), u = l.find((e) => e.value === n) ?? l[0];
	function d(e, t) {
		if (![
			"ArrowLeft",
			"ArrowRight",
			"Home",
			"End"
		].includes(e.key) || !l.length) return;
		e.preventDefault();
		let n = l.findIndex((e) => e.value === t), i = e.key === "Home" ? 0 : e.key === "End" ? l.length - 1 : (n + (e.key === "ArrowRight" ? 1 : -1) + l.length) % l.length, a = l[i].value;
		r(a), c.current.get(a)?.focus();
	}
	return /* @__PURE__ */ t("div", {
		className: `v2-pill-tabs ${o}`.trim(),
		role: "tablist",
		"aria-label": i,
		children: e.map((e) => {
			let n = H(a, e.value, s), i = !e.disabled && e.value === u?.value;
			return /* @__PURE__ */ t("button", {
				ref: (t) => {
					t ? c.current.set(e.value, t) : c.current.delete(e.value);
				},
				type: "button",
				role: "tab",
				id: n.tab,
				"aria-controls": n.panel,
				"aria-selected": i,
				disabled: e.disabled,
				tabIndex: i ? 0 : -1,
				onClick: () => r(e.value),
				onKeyDown: (t) => d(t, e.value),
				children: e.label
			}, e.value);
		})
	});
}
function pe(e) {
	return /* @__PURE__ */ t(me, { ...e });
}
function me({ value: e, activeValue: n, idPrefix: r = "tab", children: i, className: a = "", keyForValue: o = encodeURIComponent }) {
	let s = H(r, e, o);
	return /* @__PURE__ */ t("div", {
		className: a,
		role: "tabpanel",
		id: s.panel,
		"aria-labelledby": s.tab,
		hidden: e !== n,
		tabIndex: 0,
		children: i
	});
}
//#endregion
//#region src/components/design-system/components/overlays/overlays.tsx
function U({ children: e, primitive: n }) {
	return /* @__PURE__ */ t(n, {
		asChild: !0,
		children: typeof e == "string" ? /* @__PURE__ */ t("button", {
			className: "ds-overlay-trigger",
			type: "button",
			children: e
		}) : e
	});
}
function he({ open: e, onOpenChange: r, title: i, description: a, trigger: o, children: s, closeLabel: c = "Close dialog" }) {
	return /* @__PURE__ */ n(S.Root, {
		open: e,
		onOpenChange: r,
		children: [o && /* @__PURE__ */ t(U, {
			primitive: S.Trigger,
			children: o
		}), /* @__PURE__ */ n(S.Portal, { children: [/* @__PURE__ */ t(S.Overlay, { className: "ds-overlay-backdrop" }), /* @__PURE__ */ n(S.Content, {
			className: "ds-dialog",
			"aria-describedby": void 0,
			children: [
				/* @__PURE__ */ n("div", {
					className: "ds-overlay__header",
					children: [/* @__PURE__ */ t(S.Title, {
						className: "ds-overlay__title",
						children: i
					}), /* @__PURE__ */ t(S.Close, {
						className: "ds-overlay__close",
						"aria-label": c,
						children: "×"
					})]
				}),
				a && /* @__PURE__ */ t(S.Description, {
					className: "ds-overlay__description",
					children: a
				}),
				/* @__PURE__ */ t("div", {
					className: "ds-overlay__body",
					children: s
				})
			]
		})] })]
	});
}
function ge({ side: e = "right", open: r, onOpenChange: i, title: a, description: o, trigger: s, children: c, closeLabel: l }) {
	return /* @__PURE__ */ n(S.Root, {
		open: r,
		onOpenChange: i,
		children: [s && /* @__PURE__ */ t(U, {
			primitive: S.Trigger,
			children: s
		}), /* @__PURE__ */ n(S.Portal, { children: [/* @__PURE__ */ t(S.Overlay, { className: "ds-overlay-backdrop" }), /* @__PURE__ */ n(S.Content, {
			className: `ds-drawer ds-drawer--${e}`,
			children: [
				/* @__PURE__ */ n("div", {
					className: "ds-overlay__header",
					children: [/* @__PURE__ */ t(S.Title, {
						className: "ds-overlay__title",
						children: a
					}), /* @__PURE__ */ t(S.Close, {
						className: "ds-overlay__close",
						"aria-label": l ?? "Close drawer",
						children: "×"
					})]
				}),
				o && /* @__PURE__ */ t(S.Description, {
					className: "ds-overlay__description",
					children: o
				}),
				/* @__PURE__ */ t("div", {
					className: "ds-overlay__body",
					children: c
				})
			]
		})] })]
	});
}
function _e({ open: e, onOpenChange: r, trigger: i, children: a, side: o = "bottom", align: s = "start" }) {
	return /* @__PURE__ */ n(w.Root, {
		open: e,
		onOpenChange: r,
		children: [/* @__PURE__ */ t(U, {
			primitive: w.Trigger,
			children: i
		}), /* @__PURE__ */ t(w.Portal, { children: /* @__PURE__ */ t(w.Content, {
			className: "ds-popover",
			side: o,
			align: s,
			sideOffset: 8,
			children: a
		}) })]
	});
}
function ve({ content: e, children: r, open: i, onOpenChange: a, side: o = "top", delayDuration: s = 0 }) {
	return /* @__PURE__ */ t(T.Provider, {
		delayDuration: s,
		children: /* @__PURE__ */ n(T.Root, {
			open: i,
			onOpenChange: a,
			children: [/* @__PURE__ */ t(T.Trigger, {
				asChild: !0,
				children: r
			}), /* @__PURE__ */ t(T.Portal, { children: /* @__PURE__ */ n(T.Content, {
				className: "ds-tooltip",
				side: o,
				sideOffset: 8,
				children: [e, /* @__PURE__ */ t(T.Arrow, { className: "ds-tooltip__arrow" })]
			}) })]
		})
	});
}
function W({ open: e, onOpenChange: r, trigger: i, items: a, onSelect: o, ariaLabel: s = "Actions", side: c = "bottom", align: l = "start", className: u = "" }) {
	return /* @__PURE__ */ n(C.Root, {
		open: e,
		onOpenChange: r,
		children: [/* @__PURE__ */ t(U, {
			primitive: C.Trigger,
			children: i
		}), /* @__PURE__ */ t(C.Portal, { children: /* @__PURE__ */ t(C.Content, {
			className: `ds-menu ${u}`.trim(),
			align: l,
			side: c,
			sideOffset: 8,
			"aria-label": s,
			children: a.map((e) => /* @__PURE__ */ n(C.Item, {
				className: `ds-menu__item${e.danger ? " ds-menu__item--danger" : ""}${e.icon ? " ds-menu__item--with-icon" : ""}`,
				disabled: e.disabled,
				onSelect: () => o(e.id),
				children: [e.icon && /* @__PURE__ */ t("span", {
					className: "ds-menu__icon",
					"aria-hidden": "true",
					children: e.icon
				}), /* @__PURE__ */ t("span", { children: e.label })]
			}, e.id))
		}) })]
	});
}
//#endregion
//#region src/components/design-system/components/selection/Combobox.tsx
function ye({ label: e, options: r, value: i, onValueChange: a, clearable: o = !1, disabled: s = !1, placeholder: c = "Search options", className: l = "" }) {
	let u = _(), d = r.find((e) => e.value === i), [f, p] = x(!1), [m, h] = x(""), g = m.trim().toLocaleLowerCase(), v = y(() => r.filter((e) => String(e.label).toLocaleLowerCase().includes(g)), [r, g]), b = f ? m : d ? String(d.label) : "";
	function S(e, t) {
		t || s || (a(e), h(""), p(!1));
	}
	return /* @__PURE__ */ n("div", {
		className: `ds-selection ${l}`.trim(),
		children: [
			/* @__PURE__ */ t("label", {
				className: "ds-selection__label",
				htmlFor: u,
				children: e
			}),
			/* @__PURE__ */ n("div", {
				className: "ds-selection__control-wrap",
				children: [/* @__PURE__ */ t("input", {
					id: u,
					className: "ds-selection__control",
					type: "text",
					role: "combobox",
					"aria-autocomplete": "list",
					"aria-controls": `${u}-options`,
					"aria-expanded": f,
					"aria-haspopup": "listbox",
					disabled: s,
					placeholder: c,
					value: b,
					onFocus: () => {
						p(!0), h("");
					},
					onChange: (e) => {
						h(e.target.value), p(!0);
					},
					onKeyDown: (e) => {
						e.key === "Escape" && (p(!1), h("")), e.key === "Enter" && v.length === 1 && (e.preventDefault(), S(v[0].value, v[0].disabled));
					}
				}), o && i !== null && !s && /* @__PURE__ */ t("button", {
					className: "ds-selection__clear",
					type: "button",
					"aria-label": `Clear ${e}`,
					onClick: () => {
						a(null), h("");
					},
					children: "×"
				})]
			}),
			f && /* @__PURE__ */ t("ul", {
				id: `${u}-options`,
				className: "ds-selection__options",
				role: "listbox",
				"aria-label": `${e} options`,
				children: v.length > 0 ? v.map((e) => /* @__PURE__ */ t("li", { children: /* @__PURE__ */ t("button", {
					type: "button",
					className: "ds-selection__option",
					role: "option",
					"aria-selected": e.value === i,
					"aria-disabled": e.disabled || void 0,
					disabled: e.disabled || s,
					onMouseDown: (e) => e.preventDefault(),
					onClick: () => S(e.value, e.disabled),
					children: e.label
				}) }, String(e.value))) : /* @__PURE__ */ t("li", {
					className: "ds-selection__empty",
					role: "status",
					children: "No matching options."
				})
			})
		]
	});
}
//#endregion
//#region src/components/design-system/components/selection/MultiSelect.tsx
function be({ label: e, options: r, value: i, onValueChange: a, disabled: o = !1, placeholder: s = "Search options", className: c = "" }) {
	let l = _(), [u, d] = x(!1), [f, p] = x(""), m = f.trim().toLocaleLowerCase(), h = y(() => r.filter((e) => String(e.label).toLocaleLowerCase().includes(m)), [r, m]), g = r.filter((e) => i.includes(e.value)).map((e) => String(e.label));
	function v(e, t) {
		t || o || a(i.includes(e) ? i.filter((t) => t !== e) : [...i, e]);
	}
	return /* @__PURE__ */ n("div", {
		className: `ds-selection ${c}`.trim(),
		children: [
			/* @__PURE__ */ t("label", {
				className: "ds-selection__label",
				htmlFor: l,
				children: e
			}),
			/* @__PURE__ */ t("input", {
				id: l,
				className: "ds-selection__control",
				type: "text",
				role: "combobox",
				"aria-autocomplete": "list",
				"aria-controls": `${l}-options`,
				"aria-expanded": u,
				"aria-haspopup": "listbox",
				disabled: o,
				placeholder: g.length ? g.join(", ") : s,
				value: f,
				onFocus: () => d(!0),
				onChange: (e) => {
					p(e.target.value), d(!0);
				},
				onKeyDown: (e) => {
					e.key === "Escape" && (d(!1), p(""));
				}
			}),
			u && /* @__PURE__ */ t("ul", {
				id: `${l}-options`,
				className: "ds-selection__options",
				role: "listbox",
				"aria-label": `${e} options`,
				"aria-multiselectable": "true",
				children: h.length > 0 ? h.map((e) => /* @__PURE__ */ t("li", { children: /* @__PURE__ */ t("button", {
					type: "button",
					className: "ds-selection__option",
					role: "option",
					"aria-selected": i.includes(e.value),
					"aria-disabled": e.disabled || void 0,
					disabled: e.disabled || o,
					onMouseDown: (e) => e.preventDefault(),
					onClick: () => v(e.value, e.disabled),
					children: e.label
				}) }, String(e.value))) : /* @__PURE__ */ t("li", {
					className: "ds-selection__empty",
					role: "status",
					children: "No matching options."
				})
			})
		]
	});
}
//#endregion
//#region src/components/design-system/components/feedback/Alert.tsx
function G({ title: e, children: r, tone: i = "info", onDismiss: a, className: o = "" }) {
	let s = i === "danger";
	return /* @__PURE__ */ n("div", {
		className: `ds-alert ${o}`.trim(),
		"data-tone": i,
		role: s ? "alert" : "status",
		children: [/* @__PURE__ */ n("div", {
			className: "ds-alert__content",
			children: [e && /* @__PURE__ */ t("strong", {
				className: "ds-alert__title",
				children: e
			}), r && /* @__PURE__ */ t("div", {
				className: "ds-alert__body",
				children: r
			})]
		}), a && /* @__PURE__ */ t("button", {
			type: "button",
			className: "ds-alert__dismiss",
			"aria-label": "Dismiss alert",
			onClick: a,
			children: /* @__PURE__ */ t(f, {
				size: 16,
				"aria-hidden": "true"
			})
		})]
	});
}
//#endregion
//#region src/components/design-system/components/feedback/ErrorState.tsx
function xe({ title: e, description: r, actionLabel: i, onAction: a, className: o = "" }) {
	return /* @__PURE__ */ n("section", {
		className: `ds-error-state ${o}`.trim(),
		"aria-labelledby": "ds-error-state-title",
		children: [
			/* @__PURE__ */ t(u, {
				className: "ds-error-state__icon",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ t("h2", {
				id: "ds-error-state-title",
				className: "ds-error-state__title",
				children: e
			}),
			r && /* @__PURE__ */ t("p", {
				className: "ds-error-state__description",
				children: r
			}),
			i && a && /* @__PURE__ */ t(N, {
				variant: "secondary",
				onClick: a,
				children: i
			})
		]
	});
}
//#endregion
//#region src/components/design-system/components/feedback/Progress.tsx
function K({ value: e, max: r = 100, label: i, showValue: a = !0, className: o = "" }) {
	let s = _(), c = Math.max(0, Math.min(e, r)), l = Math.round(c / r * 100);
	return /* @__PURE__ */ n("div", {
		className: `ds-progress ${o}`.trim(),
		children: [/* @__PURE__ */ n("div", {
			className: "ds-progress__header",
			children: [/* @__PURE__ */ t("span", {
				id: s,
				children: i
			}), a && /* @__PURE__ */ n("span", { children: [l, "%"] })]
		}), /* @__PURE__ */ t("div", {
			className: "ds-progress__track",
			role: "progressbar",
			"aria-labelledby": s,
			"aria-valuemin": 0,
			"aria-valuemax": r,
			"aria-valuenow": c,
			children: /* @__PURE__ */ t("span", {
				className: "ds-progress__value",
				style: { width: `${l}%` }
			})
		})]
	});
}
//#endregion
//#region src/components/design-system/components/feedback/Skeleton.tsx
function Se({ lines: e = 1, className: n = "" }) {
	return /* @__PURE__ */ t("div", {
		className: `ds-skeleton ${n}`.trim(),
		children: Array.from({ length: Math.max(1, e) }, (e, n) => /* @__PURE__ */ t("span", {
			className: "ds-skeleton__line",
			"aria-hidden": "true"
		}, n))
	});
}
//#endregion
//#region src/components/design-system/components/feedback/StatusBadge.tsx
function Ce({ children: e, tone: n = "neutral", className: r = "" }) {
	return /* @__PURE__ */ t("span", {
		className: `ds-status-badge ${r}`.trim(),
		"data-tone": n,
		children: e
	});
}
//#endregion
//#region src/components/design-system/components/feedback/ToastProvider.tsx
var q = p(null);
function we({ children: e }) {
	let [r, i] = x([]), a = m((e) => i((t) => [...t, {
		...e,
		id: Date.now() + t.length
	}]), []), o = m((e) => i((t) => t.filter((t) => t.id !== e)), []), s = y(() => ({
		toast: a,
		dismiss: o
	}), [a, o]);
	return /* @__PURE__ */ n(q.Provider, {
		value: s,
		children: [e, /* @__PURE__ */ t("div", {
			className: "ds-toast-viewport",
			"aria-label": "Notifications",
			"aria-live": "polite",
			children: r.map((e) => /* @__PURE__ */ n("div", {
				className: "ds-toast",
				"data-tone": e.tone ?? "info",
				role: "status",
				children: [/* @__PURE__ */ n("div", { children: [/* @__PURE__ */ t("strong", { children: e.title }), e.description && /* @__PURE__ */ t("div", {
					className: "ds-toast__description",
					children: e.description
				})] }), /* @__PURE__ */ t("button", {
					type: "button",
					className: "ds-toast__dismiss",
					"aria-label": `Dismiss ${String(e.title)}`,
					onClick: () => o(e.id),
					children: /* @__PURE__ */ t(f, {
						size: 16,
						"aria-hidden": "true"
					})
				})]
			}, e.id))
		})]
	});
}
function Te() {
	let e = h(q);
	if (!e) throw Error("useToast must be used inside ToastProvider");
	return e;
}
//#endregion
//#region src/components/design-system/components/files/FileDropzone.tsx
function Ee({ label: e, onFilesChange: r, accept: i, multiple: a = !0, disabled: o = !1, description: s = "Drop files here or choose files from your device.", chooseLabel: c = "Choose files", className: l = "", id: u }) {
	let d = _(), f = u ?? d, p = b(null), m = (e) => {
		!o && e && r(Array.from(e));
	};
	return /* @__PURE__ */ n("div", {
		className: `ds-file-dropzone ${l}`.trim(),
		"data-disabled": o || void 0,
		onDragOver: (e) => e.preventDefault(),
		onDrop: (e) => {
			e.preventDefault(), m(e.dataTransfer.files);
		},
		children: [/* @__PURE__ */ t("input", {
			ref: p,
			id: f,
			className: "ds-file-dropzone__input",
			type: "file",
			accept: i,
			multiple: a,
			disabled: o,
			"aria-label": typeof e == "string" ? e : void 0,
			onChange: (e) => {
				m(e.currentTarget.files), e.currentTarget.value = "";
			}
		}), /* @__PURE__ */ n("div", {
			className: "ds-file-dropzone__body",
			children: [
				/* @__PURE__ */ t("strong", {
					className: "ds-file-dropzone__label",
					children: e
				}),
				/* @__PURE__ */ t("p", {
					className: "ds-file-dropzone__description",
					children: s
				}),
				/* @__PURE__ */ t("button", {
					type: "button",
					className: "ds-file-dropzone__choose",
					disabled: o,
					onClick: () => p.current?.click(),
					children: c
				})
			]
		})]
	});
}
//#endregion
//#region src/components/design-system/components/files/FileList.tsx
function De(e) {
	if (e < 1024) return `${e} B`;
	let t = [
		"KB",
		"MB",
		"GB"
	], n = e / 1024, r = 0;
	for (; n >= 1024 && r < t.length - 1;) n /= 1024, r += 1;
	return `${Math.round(n * 10) / 10} ${t[r]}`;
}
function Oe({ files: e, onRemove: r, emptyMessage: i = "No files selected.", className: a = "" }) {
	return e.length === 0 ? /* @__PURE__ */ t("p", {
		className: `ds-file-list__empty ${a}`.trim(),
		children: i
	}) : /* @__PURE__ */ t("ul", {
		className: `ds-file-list ${a}`.trim(),
		"aria-label": "Selected files",
		children: e.map((e, i) => /* @__PURE__ */ n("li", {
			className: "ds-file-list__item",
			children: [/* @__PURE__ */ n("span", {
				className: "ds-file-list__details",
				children: [/* @__PURE__ */ t("strong", { children: e.name }), /* @__PURE__ */ t("span", { children: De(e.size) })]
			}), r && /* @__PURE__ */ t("button", {
				type: "button",
				className: "ds-file-list__remove",
				onClick: () => r(i),
				"aria-label": `Remove ${e.name}`,
				children: "Remove"
			})]
		}, `${e.name}-${e.lastModified}-${i}`))
	});
}
//#endregion
//#region src/components/design-system/components/ai/AITaskStatus.tsx
var ke = {
	queued: "Queued",
	running: "Working",
	succeeded: "Complete",
	failed: "Failed"
};
function Ae({ status: e, label: r, progress: i, className: a = "" }) {
	let o = e === "failed" ? "alert" : "status";
	return /* @__PURE__ */ n("section", {
		className: `ds-ai-task-status ${a}`.trim(),
		"data-state": e,
		role: o,
		children: [/* @__PURE__ */ n("div", {
			className: "ds-ai-task-status__summary",
			children: [
				/* @__PURE__ */ t("span", {
					"aria-hidden": "true",
					children: e === "succeeded" ? "✓" : e === "failed" ? "!" : "✦"
				}),
				/* @__PURE__ */ t("span", { children: r }),
				/* @__PURE__ */ t("small", { children: ke[e] })
			]
		}), e === "running" && i !== void 0 && /* @__PURE__ */ t(K, {
			value: i,
			label: r
		})]
	});
}
//#endregion
//#region src/components/design-system/components/ai/AIResult.tsx
function je({ title: e, children: r, actionLabel: i, onAction: a, className: o = "" }) {
	return /* @__PURE__ */ n("section", {
		className: `ds-ai-result ${o}`.trim(),
		children: [
			/* @__PURE__ */ t("div", {
				className: "ds-ai-result__mark",
				"aria-hidden": "true",
				children: "✦"
			}),
			/* @__PURE__ */ n("div", {
				className: "ds-ai-result__content",
				children: [/* @__PURE__ */ t("h3", { children: e }), r && /* @__PURE__ */ t("div", { children: r })]
			}),
			i && a && /* @__PURE__ */ t("button", {
				type: "button",
				className: "ds-ai-result__action",
				onClick: a,
				children: i
			})
		]
	});
}
//#endregion
//#region src/components/design-system/components/content/ActionCard.tsx
function Me({ label: e, status: r, actions: i, persistentAction: a, highlighted: o = !1, dismissing: s = !1, exiting: c = !1, children: l, className: u = "", ...d }) {
	return /* @__PURE__ */ n("article", {
		...d,
		"aria-label": d["aria-label"] ?? e,
		className: `ds-action-card ${u}`.trim(),
		"data-highlighted": o || void 0,
		"data-dismissing": s || void 0,
		"data-exiting": c || void 0,
		"aria-hidden": c || d["aria-hidden"],
		inert: c || d.inert,
		children: [/* @__PURE__ */ n("header", {
			className: "ds-action-card__header",
			children: [/* @__PURE__ */ n("div", {
				className: "ds-action-card__meta",
				children: [/* @__PURE__ */ t("span", { children: e }), r]
			}), (i || a) && /* @__PURE__ */ n("div", {
				className: "ds-action-card__controls",
				children: [i && /* @__PURE__ */ t("div", {
					className: "ds-action-card__actions",
					children: i
				}), a]
			})]
		}), /* @__PURE__ */ t("div", {
			className: "ds-action-card__content",
			children: l
		})]
	});
}
//#endregion
//#region src/components/design-system/components/content/CanvasText.tsx
function Ne({ label: e, value: n, onValueChange: r, maxLength: i, required: a = !1, readOnly: o = !1, placeholder: s, className: c = "", style: l }) {
	let u = b(n);
	return /* @__PURE__ */ t("textarea", {
		className: `ds-canvas-text ${c}`.trim(),
		style: l,
		"aria-label": e,
		"aria-invalid": a && !n.trim() || i !== void 0 && n.length > i || void 0,
		value: n,
		required: a,
		readOnly: o,
		placeholder: s,
		rows: 1,
		spellCheck: !0,
		onFocus: () => {
			u.current = n;
		},
		onChange: (e) => {
			o || r(e.target.value);
		},
		onBlur: (e) => {
			e.currentTarget.scrollTop = 0, e.currentTarget.scrollLeft = 0;
		},
		onKeyDown: (e) => {
			e.key === "Escape" && !e.nativeEvent.isComposing && !o && (e.preventDefault(), r(u.current), e.currentTarget.blur());
		}
	});
}
//#endregion
//#region src/components/design-system/components/content/FactGrid.tsx
function J({ items: e, label: r = "Details", className: i = "", theme: a, density: o = "comfortable" }) {
	return /* @__PURE__ */ t("div", {
		className: `ds-fact-grid-container ${i}`.trim(),
		role: "group",
		"aria-label": r,
		"data-theme": a,
		"data-density": o,
		children: /* @__PURE__ */ t("dl", {
			className: "ds-fact-grid",
			children: e.map(({ id: e, label: r, value: i, emphasis: a }) => /* @__PURE__ */ n("div", {
				"data-emphasis": a || void 0,
				children: [/* @__PURE__ */ t("dt", { children: r }), /* @__PURE__ */ t("dd", { children: i })]
			}, e))
		})
	});
}
//#endregion
//#region src/components/design-system/components/content/InlineText.tsx
function Pe({ label: e, value: r = "", sourceKey: i, onSave: a, onDirty: o, readOnly: c = !1, required: l = !1, maxLength: u = 500, className: d = "", style: f }) {
	let [p, m] = x(!1), [h, _] = x(r), [v, y] = x(r), [S, C] = x(!1), [w, T] = x(""), E = b(null), D = b(i), O = b(!1);
	g(() => {
		p || _(r);
	}, [r]);
	let k = () => {
		m(!1), T(""), o?.(!1), requestAnimationFrame(() => E.current?.focus());
	}, A = async () => {
		if (O.current || c) return;
		let t = v.trim();
		if (l && !t) {
			T(`${e} cannot be empty.`);
			return;
		}
		O.current = !0, C(!0), T("");
		try {
			if (t === h) {
				k();
				return;
			}
			let e = D.current === void 0 ? await a(t) : await a(t, D.current);
			if (e?.ok === !1) {
				T(e.message || "Could not save changes.");
				return;
			}
			_(t), k();
		} catch (e) {
			T(e instanceof Error ? e.message : "Could not save changes.");
		} finally {
			O.current = !1, C(!1);
		}
	};
	return p ? /* @__PURE__ */ n("div", {
		className: `ds-inline-text-value ds-inline-text-editor ${d}`.trim(),
		style: f,
		children: [
			/* @__PURE__ */ n("div", {
				className: "ds-inline-text-editor__field",
				children: [/* @__PURE__ */ n("span", {
					className: "ds-inline-text-value__copy ds-inline-text-editor__sizer",
					"aria-hidden": "true",
					children: [v, "​"]
				}), /* @__PURE__ */ t("textarea", {
					autoFocus: !0,
					"aria-label": e,
					value: v,
					maxLength: u,
					rows: 1,
					disabled: S || c,
					onBlur: () => void A(),
					onChange: (e) => y(e.target.value),
					onKeyDown: (e) => {
						e.nativeEvent.isComposing || (e.key === "Escape" && !S && (e.preventDefault(), _(r), k()), e.key === "Enter" && !e.shiftKey && (e.preventDefault(), A()));
					}
				})]
			}),
			w && /* @__PURE__ */ t("p", {
				className: "ds-inline-text-editor__error",
				role: "alert",
				children: w
			}),
			D.current !== i && /* @__PURE__ */ t("p", {
				className: "ds-inline-text-editor__note",
				children: "The saved value changed. Your draft is kept; copy it before canceling to load the latest version."
			})
		]
	}) : c ? /* @__PURE__ */ t("span", {
		className: `ds-inline-text-value ${d}`.trim(),
		style: f,
		children: h || "Not specified"
	}) : /* @__PURE__ */ n("button", {
		ref: E,
		type: "button",
		className: `ds-inline-text-value ${d}`.trim(),
		style: f,
		"aria-label": `Edit ${e.toLowerCase()}`,
		onClick: () => {
			D.current = i, y(h), m(!0), o?.(!0);
		},
		children: [/* @__PURE__ */ n("span", {
			className: "ds-inline-text-value__copy",
			children: [h || "Not specified", "​"]
		}), /* @__PURE__ */ t("span", {
			className: "ds-inline-text-value__edit",
			"aria-hidden": "true",
			children: /* @__PURE__ */ t(s, { size: 14 })
		})]
	});
}
//#endregion
//#region src/components/design-system/components/content/Panel.tsx
function Y({ title: e, description: r, as: i = "section", children: a, className: o = "", ...s }) {
	let c = _();
	return /* @__PURE__ */ t(i, {
		...s,
		className: `ds-panel${a == null ? " ds-panel--empty" : ""} ${o}`.trim(),
		"aria-labelledby": c,
		children: /* @__PURE__ */ n("div", {
			className: "ds-panel__content",
			children: [/* @__PURE__ */ n("header", {
				className: "ds-panel__header",
				children: [/* @__PURE__ */ t("h3", {
					id: c,
					children: e
				}), r && /* @__PURE__ */ t("p", { children: r })]
			}), a]
		})
	});
}
//#endregion
//#region src/components/design-system/components/content/SelectionTile.tsx
function Fe({ label: e, selected: i = !1, onChange: a, disabled: o = !1, caption: s, children: l, className: u = "", ...d }) {
	return /* @__PURE__ */ n("button", {
		...d,
		type: d.type ?? "button",
		className: `ds-selection-tile ${u}`.trim(),
		"aria-label": `${i ? "Deselect" : "Select"} ${e}`,
		"aria-pressed": i,
		disabled: o,
		onClick: a,
		children: [
			/* @__PURE__ */ t("span", {
				className: "ds-selection-tile__content",
				children: l
			}),
			/* @__PURE__ */ t("span", {
				className: "ds-selection-tile__action",
				"aria-hidden": "true",
				children: t(i ? r : c, { size: 20 })
			}),
			s && /* @__PURE__ */ t("span", {
				className: "ds-selection-tile__caption",
				children: s
			})
		]
	});
}
//#endregion
//#region src/components/design-system/components/content/Tag.tsx
function Ie({ children: e, tone: n = "neutral", variant: r = "filled", className: i = "", ...a }) {
	return /* @__PURE__ */ t("span", {
		...a,
		className: `ds-tag ds-tag--${r} ds-tag--${n} ${i}`.trim(),
		"data-tone": n,
		"data-variant": r,
		children: e
	});
}
//#endregion
//#region src/components/design-system/components/content/TagButton.tsx
function Le({ children: e, tone: r = "neutral", variant: i = "filled", dismissible: a = !1, className: o = "", ...s }) {
	return /* @__PURE__ */ n("button", {
		...s,
		className: `ds-tag ds-tag-button ds-tag--${i} ds-tag--${r} ${o}`.trim(),
		"data-tone": r,
		"data-variant": i,
		children: [e, a && /* @__PURE__ */ t(f, {
			className: "ds-tag-button__dismiss",
			"aria-hidden": "true",
			size: 14,
			strokeWidth: 2.5
		})]
	});
}
//#endregion
//#region src/components/design-system/components/data/BulkActionBar.tsx
function Re({ count: e, children: r, onClear: i, className: a = "" }) {
	return /* @__PURE__ */ n("section", {
		className: `ds-bulk-action-bar ${a}`.trim(),
		"aria-label": "Bulk actions",
		children: [/* @__PURE__ */ n("p", { children: [
			/* @__PURE__ */ t("strong", { children: e }),
			" ",
			e === 1 ? "item selected" : "items selected"
		] }), /* @__PURE__ */ n("div", {
			className: "ds-bulk-action-bar__actions",
			children: [r, /* @__PURE__ */ t("button", {
				type: "button",
				onClick: i,
				children: "Clear selection"
			})]
		})]
	});
}
//#endregion
//#region src/components/design-system/components/data/FilterToolbar.tsx
function ze({ query: e, onQueryChange: r, children: i, onClear: a, resultCount: o, searchLabel: s = "Search results", className: c = "" }) {
	return /* @__PURE__ */ n("section", {
		className: `ds-filter-toolbar ${c}`.trim(),
		"aria-label": "Filters",
		children: [/* @__PURE__ */ n("div", {
			className: "ds-filter-toolbar__controls",
			children: [
				/* @__PURE__ */ n("label", {
					className: "ds-filter-toolbar__search",
					children: [/* @__PURE__ */ t("span", { children: s }), /* @__PURE__ */ t("input", {
						type: "search",
						value: e,
						onChange: (e) => r(e.target.value)
					})]
				}),
				i,
				a && /* @__PURE__ */ t("button", {
					type: "button",
					className: "ds-filter-toolbar__clear",
					onClick: a,
					children: "Clear filters"
				})
			]
		}), o !== void 0 && /* @__PURE__ */ n("p", {
			className: "ds-filter-toolbar__count",
			role: "status",
			children: [
				o,
				" ",
				o === 1 ? "result" : "results"
			]
		})]
	});
}
//#endregion
//#region src/components/design-system/components/data/Table.tsx
function Be({ checked: e, indeterminate: n, disabled: r, onChange: i }) {
	let a = b(null);
	return g(() => {
		a.current && (a.current.indeterminate = n);
	}, [n]), /* @__PURE__ */ t("input", {
		ref: a,
		type: "checkbox",
		"aria-label": "Select all rows",
		checked: e,
		disabled: r,
		onChange: i
	});
}
function Ve({ label: e, rows: r, columns: i, getRowId: a, sort: o, onSortChange: s, selectedIds: c, onSelectionChange: l, emptyMessage: u = "No rows to display.", className: d = "" }) {
	let f = c !== void 0 && l !== void 0, p = r.map(a), m = new Set(c), h = p.filter((e) => m.has(e)).length, g = p.length > 0 && h === p.length, _ = h > 0 && !g;
	function v(e) {
		let t = o?.columnId === e && o.direction === "asc" ? "desc" : "asc";
		s?.({
			columnId: e,
			direction: t
		});
	}
	function y() {
		if (!l) return;
		let e = new Set(p);
		if (g) {
			l((c ?? []).filter((t) => !e.has(t)));
			return;
		}
		l([.../* @__PURE__ */ new Set([...c ?? [], ...p])]);
	}
	function b(e) {
		l && l(m.has(e) ? (c ?? []).filter((t) => t !== e) : [...c ?? [], e]);
	}
	return /* @__PURE__ */ t("div", {
		className: `ds-table-scroll ${d}`.trim(),
		children: /* @__PURE__ */ n("table", {
			className: "ds-table",
			"aria-label": e,
			children: [
				/* @__PURE__ */ t("caption", { children: e }),
				/* @__PURE__ */ t("thead", { children: /* @__PURE__ */ n("tr", { children: [f && /* @__PURE__ */ t("th", {
					scope: "col",
					className: "ds-table__selection",
					children: /* @__PURE__ */ t(Be, {
						checked: g,
						indeterminate: _,
						disabled: p.length === 0,
						onChange: y
					})
				}), i.map((e) => {
					let n = o?.columnId === e.id ? o?.direction === "asc" ? "ascending" : "descending" : e.sortable ? "none" : void 0;
					return /* @__PURE__ */ t("th", {
						scope: "col",
						className: e.className,
						"aria-sort": n,
						children: e.sortable ? /* @__PURE__ */ t("button", {
							type: "button",
							className: "ds-table__sort",
							onClick: () => v(e.id),
							"aria-label": `Sort by ${e.header}`,
							children: e.header
						}) : e.header
					}, e.id);
				})] }) }),
				/* @__PURE__ */ t("tbody", { children: r.length === 0 ? /* @__PURE__ */ t("tr", { children: /* @__PURE__ */ t("td", {
					colSpan: i.length + +!!f,
					className: "ds-table__empty",
					children: u
				}) }) : r.map((e) => {
					let r = a(e);
					return /* @__PURE__ */ n("tr", {
						"data-row-id": r,
						children: [f && /* @__PURE__ */ t("td", {
							className: "ds-table__selection",
							children: /* @__PURE__ */ t("input", {
								type: "checkbox",
								"aria-label": `Select row ${r}`,
								checked: m.has(r),
								onChange: () => b(r)
							})
						}), i.map((n) => /* @__PURE__ */ t("td", {
							className: n.className,
							children: n.cell(e)
						}, n.id))]
					}, r);
				}) })
			]
		})
	});
}
//#endregion
//#region src/components/design-system/molecules/FormField.jsx
function X({ label: e, id: r, hint: i, error: a, children: o, ...s }) {
	let c = _(), l = r ?? c, u = a || i;
	return /* @__PURE__ */ n("div", {
		className: "v2-form-field",
		children: [
			/* @__PURE__ */ t("label", {
				htmlFor: l,
				children: e
			}),
			o ? o({
				id: l,
				describedBy: u ? `${l}-description` : void 0
			}) : /* @__PURE__ */ t("input", {
				...s,
				id: l,
				"aria-invalid": a ? !0 : void 0,
				"aria-describedby": u ? `${l}-description` : void 0
			}),
			u && /* @__PURE__ */ t("p", {
				id: `${l}-description`,
				className: "v2-form-field__note",
				"data-error": !!a,
				role: a ? "alert" : void 0,
				children: u
			})
		]
	});
}
//#endregion
//#region src/components/design-system/molecules/SelectMenu.jsx
function Z({ label: e, value: a, options: o, onChange: s, triggerLabel: c, triggerId: l, describedBy: u, disabled: d = !1, showOptionIcons: f = !0 }) {
	let [p, m] = x(!1), h = b(null), v = b(null), y = _();
	g(() => {
		d && m(!1);
	}, [d]), g(() => {
		if (!p) return;
		let e = (e) => {
			h.current?.contains(e.target) || m(!1);
		};
		return document.addEventListener("pointerdown", e), (h.current?.querySelector("[aria-selected=\"true\"]") ?? h.current?.querySelector("[role=\"option\"]"))?.focus(), () => document.removeEventListener("pointerdown", e);
	}, [p]);
	let S = o.map((e) => typeof e == "string" ? {
		label: e,
		value: e
	} : {
		value: e.value ?? e.label,
		...e
	});
	return /* @__PURE__ */ n("div", {
		className: "v2-menu-select",
		ref: h,
		onBlur: (e) => {
			e.currentTarget.contains(e.relatedTarget) || m(!1);
		},
		children: [/* @__PURE__ */ n("button", {
			id: l,
			disabled: d,
			ref: v,
			className: "v2-select-trigger v2-interactive-control",
			type: "button",
			"aria-label": c || `${e}: ${a}`,
			"aria-describedby": u,
			"aria-haspopup": "listbox",
			"aria-expanded": p,
			"aria-controls": y,
			onClick: () => m(!p),
			onKeyDown: (e) => {
				["ArrowDown", "ArrowUp"].includes(e.key) && (e.preventDefault(), m(!0));
			},
			children: [a, /* @__PURE__ */ t(i, {
				size: 16,
				"aria-hidden": "true"
			})]
		}), p && /* @__PURE__ */ t("div", {
			id: y,
			role: "listbox",
			"aria-label": e,
			className: "v2-floating-listbox",
			onKeyDown: (e) => {
				let t = [...e.currentTarget.querySelectorAll("[role=\"option\"]")], n = t.indexOf(document.activeElement);
				e.key === "Escape" && (e.preventDefault(), m(!1), v.current?.focus()), [
					"ArrowDown",
					"ArrowUp",
					"Home",
					"End"
				].includes(e.key) && (e.preventDefault(), t[e.key === "Home" ? 0 : e.key === "End" ? t.length - 1 : (n + (e.key === "ArrowDown" ? 1 : -1) + t.length) % t.length]?.focus());
			},
			children: S.map((e) => {
				let i = e.icon, o = a === e.value;
				return /* @__PURE__ */ n("button", {
					type: "button",
					role: "option",
					"aria-selected": o,
					tabIndex: o ? 0 : -1,
					className: "v2-listbox-option v2-interactive-control",
					onClick: () => {
						s(e.value), m(!1), v.current?.focus();
					},
					children: [/* @__PURE__ */ n("span", {
						className: "v2-listbox-option__label",
						children: [f && i && /* @__PURE__ */ t(i, {
							size: 16,
							"aria-hidden": "true"
						}), e.label]
					}), o && /* @__PURE__ */ t(r, {
						size: 16,
						"aria-hidden": "true"
					})]
				}, e.value);
			})
		})]
	});
}
//#endregion
//#region src/components/design-system/ui-blocks/settings/SettingsForm.tsx
function He({ initialValue: r, onSave: i }) {
	let [a, o] = x(r), [s, c] = x(r), [l, u] = x(null), [d, f] = x(!1), p = (e, t) => o((n) => ({
		...n,
		[e]: t
	})), m = a.name.trim().length > 0, h = JSON.stringify(a) !== JSON.stringify(s);
	async function g(e) {
		if (e.preventDefault(), !(!m || !h || d)) {
			f(!0), u(null);
			try {
				let e = await i(a);
				e.ok ? (c(a), u("Settings saved.")) : u(e.message);
			} catch {
				u("Could not save settings. Try again.");
			} finally {
				f(!1);
			}
		}
	}
	let _ = a.preferences, v = (e) => {
		_ && p("preferences", {
			..._,
			...e
		});
	};
	return /* @__PURE__ */ n(P, {
		className: "ds-settings-form",
		"aria-label": "Workspace settings",
		onSubmit: g,
		children: [
			/* @__PURE__ */ n(Y, {
				title: "Workspace",
				description: "Set your workspace name and preferred language.",
				children: [/* @__PURE__ */ t(V, {
					label: "Workspace name",
					value: a.name,
					disabled: d,
					onChange: (e) => p("name", e.target.value),
					error: m ? void 0 : "Enter a workspace name."
				}), /* @__PURE__ */ t(X, {
					label: "Language",
					children: ({ id: e, describedBy: n }) => /* @__PURE__ */ t(Z, {
						label: "Language",
						triggerId: e,
						describedBy: n,
						value: a.language,
						disabled: d,
						options: [
							"English",
							"Deutsch",
							"Français",
							"日本語"
						],
						onChange: (e) => p("language", e)
					})
				})]
			}),
			_ && /* @__PURE__ */ n(Y, {
				title: "Appearance",
				description: "Choose how your workspace looks and feels.",
				children: [
					/* @__PURE__ */ t(X, {
						label: "Appearance",
						hint: "Theme preview only; this does not change the application theme.",
						children: ({ id: e, describedBy: n }) => /* @__PURE__ */ t(Z, {
							label: "Appearance",
							triggerId: e,
							describedBy: n,
							value: _.theme,
							disabled: d,
							options: [
								"System",
								"Light",
								"Dark"
							],
							onChange: (e) => v({ theme: e })
						})
					}),
					/* @__PURE__ */ t(X, {
						label: "Density",
						children: ({ id: e, describedBy: n }) => /* @__PURE__ */ t(Z, {
							label: "Density",
							triggerId: e,
							describedBy: n,
							value: _.density,
							disabled: d,
							options: ["Comfortable", "Compact"],
							onChange: (e) => v({ density: e })
						})
					}),
					/* @__PURE__ */ t(J, {
						label: "Preferences preview",
						theme: _.theme === "Dark" ? "dark" : _.theme === "Light" ? "light" : "system",
						density: _.density === "Compact" ? "compact" : "comfortable",
						items: [{
							id: "campaign",
							label: "Campaign",
							value: "Oslo launch"
						}, {
							id: "review",
							label: "Review",
							value: "Ready for feedback"
						}]
					})
				]
			}),
			/* @__PURE__ */ n(Y, {
				title: "Notifications",
				description: "Choose which updates you receive.",
				children: [/* @__PURE__ */ t(z, {
					label: "Notifications",
					checked: a.notifications,
					disabled: d,
					onChange: (e) => p("notifications", e.target.checked)
				}), _ && /* @__PURE__ */ n(e, { children: [[
					["summary", "Weekly summary"],
					["mentions", "Mentions"],
					["replies", "Comment replies"]
				].map(([e, n]) => /* @__PURE__ */ t(B, {
					label: n,
					checked: _[e],
					disabled: d,
					onCheckedChange: (t) => v({ [e]: t })
				}, e)), /* @__PURE__ */ t(z, {
					label: "Play notification sounds",
					checked: _.sounds,
					disabled: d,
					onChange: (e) => v({ sounds: e.target.checked })
				})] })]
			}),
			l && /* @__PURE__ */ t(G, {
				tone: l === "Settings saved." ? "success" : "danger",
				children: l
			}),
			/* @__PURE__ */ n(F, { children: [/* @__PURE__ */ t(N, {
				onClick: () => {
					o(s), u(null);
				},
				disabled: !h || d,
				children: "Cancel"
			}), /* @__PURE__ */ t(N, {
				variant: "primary",
				type: "submit",
				disabled: !m || !h,
				busy: d,
				children: d ? "Saving…" : "Save settings"
			})] })
		]
	});
}
//#endregion
//#region src/components/design-system/components/shell/SidebarPanel.tsx
function Q({ brand: e, searchOpen: r, query: i, placeholder: a, onSearchOpen: o, onSearchClose: s, onQueryChange: c }) {
	let u = b(null), d = b(!1);
	return g(() => {
		r ? u.current?.querySelector("input")?.focus({ preventScroll: !0 }) : d.current &&= (u.current?.querySelector("button")?.focus({ preventScroll: !0 }), !1);
	}, [r]), /* @__PURE__ */ n("header", {
		className: "ds-sidebar-panel__header",
		"data-search-open": r || void 0,
		children: [/* @__PURE__ */ t("a", {
			className: "ds-sidebar-panel__brand",
			href: e.href ?? "#",
			hidden: r,
			children: /* @__PURE__ */ t("span", { children: e.label })
		}), /* @__PURE__ */ t("div", {
			ref: u,
			className: "ds-sidebar-panel__search-mode",
			children: r ? /* @__PURE__ */ t(V, {
				className: "ds-sidebar-panel__search-field",
				label: /* @__PURE__ */ t("span", {
					className: "ds-sidebar-panel__search-label",
					children: a
				}),
				placeholder: a,
				type: "search",
				value: i,
				onChange: (e) => c(e.target.value),
				onBlur: () => {
					i.trim() || s();
				},
				onKeyDown: (e) => {
					e.key === "Escape" && (e.preventDefault(), e.stopPropagation(), d.current = !0, s());
				}
			}) : /* @__PURE__ */ t(N, {
				variant: "icon",
				size: "small",
				iconOnly: !0,
				"aria-label": "Search campaigns",
				"aria-expanded": !1,
				onClick: o,
				children: /* @__PURE__ */ t(l, {
					size: 18,
					"aria-hidden": "true"
				})
			})
		})]
	});
}
function $({ items: e }) {
	return /* @__PURE__ */ t("nav", {
		className: "ds-sidebar-panel__navigation",
		"aria-label": "Workspace navigation",
		children: e.map((e) => /* @__PURE__ */ n("a", {
			href: e.href,
			"aria-current": e.current ? "page" : void 0,
			onClick: e.onClick,
			children: [e.icon && /* @__PURE__ */ t("span", {
				className: "ds-sidebar-panel__item-icon",
				"aria-hidden": "true",
				children: e.icon
			}), /* @__PURE__ */ t("span", { children: e.label })]
		}, e.id))
	});
}
function Ue({ project: e, onSelect: n }) {
	let [r, i] = x(!1);
	return e.actions?.length ? /* @__PURE__ */ t(W, {
		open: r,
		onOpenChange: i,
		className: "ds-menu--sidebar-panel",
		ariaLabel: `${e.title} actions`,
		trigger: /* @__PURE__ */ t(N, {
			className: "ds-sidebar-panel__project-actions",
			variant: "icon",
			size: "small",
			iconOnly: !0,
			"aria-label": `Actions for ${e.title}`,
			children: /* @__PURE__ */ t(o, {
				size: 18,
				"aria-hidden": "true"
			})
		}),
		items: e.actions,
		onSelect: (e) => {
			n?.(e), i(!1);
		}
	}) : null;
}
function We({ project: e, onAction: r }) {
	return /* @__PURE__ */ n("li", {
		className: "ds-sidebar-panel__project-row",
		"data-pinned": e.pinned || void 0,
		children: [/* @__PURE__ */ t("div", {
			className: "ds-sidebar-panel__project-title",
			children: e.href ? /* @__PURE__ */ t("a", {
				href: e.href,
				title: e.title,
				children: e.title
			}) : /* @__PURE__ */ t("span", {
				title: e.title,
				children: e.title
			})
		}), /* @__PURE__ */ t(Ue, {
			project: e,
			onSelect: r
		})]
	});
}
function Ge({ projects: e, onAction: r, emptyMessage: i = "No recent projects." }) {
	let a = _(), o = e.filter((e) => e.pinned), s = e.filter((e) => !e.pinned), c = (e) => /* @__PURE__ */ t("ul", { children: e.map((e) => /* @__PURE__ */ t(We, {
		project: e,
		onAction: (t) => r?.(e.id, t)
	}, e.id)) });
	return /* @__PURE__ */ n("section", {
		className: "ds-sidebar-panel__projects",
		"aria-labelledby": a,
		children: [o.length > 0 && /* @__PURE__ */ n("div", {
			className: "ds-sidebar-panel__project-group",
			children: [/* @__PURE__ */ t("h6", { children: "Pinned" }), c(o)]
		}), /* @__PURE__ */ n("div", {
			className: "ds-sidebar-panel__project-group",
			children: [/* @__PURE__ */ t("h6", {
				id: a,
				children: "Recent projects"
			}), s.length ? c(s) : !o.length && /* @__PURE__ */ t("p", {
				className: "ds-sidebar-panel__empty",
				children: i
			})]
		})]
	});
}
function Ke({ account: e }) {
	let [r, a] = x(!1);
	return e.actions?.length ? /* @__PURE__ */ t(W, {
		open: r,
		onOpenChange: a,
		side: "top",
		className: "ds-menu--sidebar-panel",
		ariaLabel: `${e.label} account actions`,
		trigger: /* @__PURE__ */ n(N, {
			variant: "quiet",
			size: "default",
			className: "ds-sidebar-panel__account-trigger",
			"aria-label": e.label,
			children: [
				/* @__PURE__ */ t("span", {
					className: "ds-sidebar-panel__account-avatar",
					"aria-hidden": "true",
					children: e.icon ?? /* @__PURE__ */ t(d, { size: 18 })
				}),
				/* @__PURE__ */ t("span", {
					className: "ds-sidebar-panel__account-name",
					title: e.label,
					children: e.label
				}),
				/* @__PURE__ */ t(i, {
					className: "ds-sidebar-panel__account-chevron",
					size: 16,
					"aria-hidden": "true"
				})
			]
		}),
		items: e.actions,
		onSelect: (t) => {
			e.onAction?.(t), a(!1);
		}
	}) : /* @__PURE__ */ n("span", {
		className: "ds-sidebar-panel__account-label",
		children: [e.icon && /* @__PURE__ */ t("span", {
			"aria-hidden": "true",
			children: e.icon
		}), e.label]
	});
}
function qe({ brand: e, primaryAction: r, navigation: i, projects: a, search: o, account: s, onProjectAction: c, className: l = "" }) {
	let [u, d] = x(!1), [f, p] = x(""), m = o?.query ?? f, h = y(() => {
		let e = m.trim().toLowerCase();
		return e ? a.filter((t) => t.title.toLowerCase().includes(e)) : a;
	}, [a, m]);
	function g(e) {
		p(e), o?.onQueryChange?.(e);
	}
	function _() {
		g(""), d(!1);
	}
	return /* @__PURE__ */ n("aside", {
		className: `ds-sidebar-panel ${l}`.trim(),
		"aria-label": "Sidebar",
		children: [
			/* @__PURE__ */ t(Q, {
				brand: e,
				searchOpen: u,
				query: m,
				placeholder: o?.placeholder ?? "Search projects",
				onSearchOpen: () => d(!0),
				onSearchClose: _,
				onQueryChange: g
			}),
			!u && /* @__PURE__ */ n(N, {
				className: "ds-sidebar-panel__primary",
				variant: "primary",
				onClick: r.onClick,
				children: [r.icon && /* @__PURE__ */ t("span", {
					"aria-hidden": "true",
					children: r.icon
				}), r.label]
			}),
			/* @__PURE__ */ n("div", {
				className: "ds-sidebar-panel__body",
				"data-search-open": u || void 0,
				children: [!u && /* @__PURE__ */ t($, { items: i }), /* @__PURE__ */ t(Ge, {
					projects: u ? h : a,
					onAction: c,
					emptyMessage: m ? "No matching projects." : void 0
				})]
			}),
			s && /* @__PURE__ */ t("footer", {
				className: "ds-sidebar-panel__footer",
				children: /* @__PURE__ */ t(Ke, { account: s })
			})
		]
	});
}
//#endregion
export { je as AIResult, Ae as AITaskStatus, Me as ActionCard, G as Alert, N as AppButton, se as Breadcrumbs, Re as BulkActionBar, Ne as CanvasText, z as CheckboxField, ye as Combobox, D as Container, E as DesignSystemRoot, he as Dialog, O as Divider, ge as Drawer, xe as ErrorState, J as FactGrid, Ee as FileDropzone, Oe as FileList, ze as FilterToolbar, P as Form, F as FormActions, re as FormSection, A as Grid, j as Inline, Pe as InlineText, W as Menu, be as MultiSelect, ce as Pagination, Y as Panel, _e as Popover, K as Progress, ie as RadioGroup, ee as ScrollArea, le as SegmentedControl, ae as SelectField, Fe as SelectionTile, He as SettingsForm, Ke as SidebarAccountMenu, Ue as SidebarContextMenu, Q as SidebarHeader, $ as SidebarNavigation, qe as SidebarPanel, We as SidebarProjectRow, Ge as SidebarProjects, Se as Skeleton, M as Stack, Ce as StatusBadge, ue as Stepper, te as Surface, B as SwitchField, pe as TabPanel, Ve as Table, de as Tabs, Ie as Tag, Le as TagButton, ne as TextAction, oe as TextArea, V as TextField, we as ToastProvider, ve as Tooltip, Te as useToast };
