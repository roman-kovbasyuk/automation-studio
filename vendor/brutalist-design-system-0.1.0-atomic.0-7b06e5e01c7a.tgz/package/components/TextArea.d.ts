import { type ReactNode, type TextareaHTMLAttributes } from 'react';

export type TextAreaProps = TextareaHTMLAttributes<HTMLTextAreaElement> & {
    label: ReactNode;
    embedded?: boolean;
    hideLabel?: boolean;
    instructions?: ReactNode;
    error?: ReactNode;
};
export declare function TextArea({ label, embedded, hideLabel, instructions, error, id, rows, className, onInput, 'aria-describedby': external, 'aria-invalid': invalid, ...props }: TextAreaProps): import("react").JSX.Element;
