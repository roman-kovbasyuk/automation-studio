import { type TextFieldProps } from './TextField';
export type PasswordFieldProps = Omit<TextFieldProps, 'type' | 'label'> & {
    label: string;
};
export declare function PasswordField({ label, ...props }: PasswordFieldProps): import("react").JSX.Element;
export type SearchFieldProps = Omit<TextFieldProps, 'type' | 'label' | 'value' | 'onChange' | 'defaultValue'> & {
    label: string;
    value: string;
    onChange: (value: string) => void;
};
export declare function SearchField({ label, value, onChange, ...props }: SearchFieldProps): import("react").JSX.Element;
export { DatePicker, type DatePickerProps } from './DatePicker';
