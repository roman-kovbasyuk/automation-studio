import { type FileItem } from '../components';
export type PromptInputProps = {
    value: string;
    onChange: (value: string) => void;
    onSubmit: () => void;
    files?: readonly FileItem[];
    onAttach?: (files: File[]) => void;
    onRemove?: (id: string) => void;
    disabled?: boolean;
    readOnly?: boolean;
    busy?: boolean;
    error?: string;
    label?: string;
    placeholder?: string;
    accept?: string;
};
export declare function PromptInput({ value, onChange, onSubmit, files, onAttach, onRemove, disabled, readOnly, busy, error, label, placeholder, accept }: PromptInputProps): import("react").JSX.Element;
