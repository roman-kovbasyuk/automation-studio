import { type InputHTMLAttributes, type ReactNode } from 'react';

export type CheckboxProps = Omit<InputHTMLAttributes<HTMLInputElement>, 'type'> & {
    label: ReactNode;
    instructions?: ReactNode;
    error?: ReactNode;
    indeterminate?: boolean;
};
export declare function Checkbox({ label, instructions, error, indeterminate, id, checked, defaultChecked, className, 'aria-describedby': external, 'aria-invalid': invalid, ...props }: CheckboxProps): import("react").JSX.Element;
