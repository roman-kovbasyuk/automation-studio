import type { ReactNode } from 'react';
export type TaskState = 'idle' | 'running' | 'waiting' | 'partial' | 'ready' | 'cancelled' | 'failed';
export type AIWorkspaceProps = {
    prompt: string;
    onPromptChange(value: string): void;
    state: TaskState;
    message: string;
    result?: ReactNode;
    attachments?: ReactNode;
    onSubmit(): void;
    onCancel?(): void;
    onRetry?(): void;
    onApply?(): void;
    onRevise?(): void;
    readOnly?: boolean;
};
export declare function AIWorkspace({ prompt, onPromptChange, state, message, result, attachments, onSubmit, onCancel, onRetry, onApply, onRevise, readOnly }: AIWorkspaceProps): import("react").JSX.Element;
